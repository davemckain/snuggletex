/* $Id: JAXPDefaultXMLFactory.java 58 2008-08-03 19:29:15Z dmckain $
 *
 * Copyright (c) 2003 - 2008 University of Edinburgh.
 * All Rights Reserved
 */
package uk.ac.ed.ph.commons.xml;

import uk.ac.ed.ph.commons.util.StringUtilities;

import java.io.StringReader;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.TransformerFactoryConfigurationError;
import javax.xml.transform.dom.DOMResult;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.sax.SAXResult;
import javax.xml.transform.sax.SAXSource;
import javax.xml.transform.sax.SAXTransformerFactory;
import javax.xml.transform.sax.TransformerHandler;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
import org.xml.sax.SAXNotRecognizedException;
import org.xml.sax.SAXNotSupportedException;
import org.xml.sax.XMLReader;
import org.xml.sax.helpers.DefaultHandler;

/**
 * Default implementation of {@link XMLFactory} that uses the usual JAXP factory lookup mechanisms
 * to determine what to do.
 * <p>
 * It also includes support for correctly configuring {@link XMLReader}s to be used with
 * a {@link TransformerHandler}, which is one particularly grey area of JAXP.
 * <p>
 * This class includes a {@link #main(String[])} method that can be run to show what would
 * result given the current JAXP factory and ClassPath configuration.
 * <p>
 * This is a singleton - get at it via {@link #getInstance()}.
 *
 * @author David McKain
 * @version $Revision: 58 $
 */
public final class JAXPDefaultXMLFactory implements XMLFactory {

    private static final Log log = LogFactory.getLog(JAXPDefaultXMLFactory.class);
    
    /** Name of the System property that determines which XSLT TransformerFactory to use */
    public static final String TRANSFORMER_FACTORY_PROPERTY = "javax.xml.transform.TransformerFactory";

    /** Name of the System property that determines which SAX Parser Factory to use */
    public static final String SAX_PARSER_FACTORY_PROPERTY = "javax.xml.parsers.SAXParserFactory";
    
    /** 
     * Value of Saxon 8 FeatureKeys#VERSION_WARNING. This has been looked up and
     * pasted in here to avoid a compile-time dependency on Saxon 8.
     */ 
    public static final String SAXON_VERSION_WARNING_FEATURE_KEY = "http://saxon.sf.net/feature/version-warning";
    
    /**
     * Names of the SAX Features that need to be configured in
     * {@link #createNSAwareXMLReaderForTransformerHandler(boolean)}
     */
    public static final String[] SAX_FEATURES_FOR_TRANSFORMERHANDLER = {
        SAXFeatures.NAMESPACES,
        SAXFeatures.NAMESPACE_PREFIXES,
        SAXFeatures.XMLNS_URIS
    };

    
    //-----------------------------------------------------------
    
    /** Singleton instance */
    private static final JAXPDefaultXMLFactory singletonInstance;
    
    static {
        singletonInstance = new JAXPDefaultXMLFactory();
    }
    
    public static JAXPDefaultXMLFactory getInstance() {
        return singletonInstance;
    }
    
    private JAXPDefaultXMLFactory() {
    }
    
    //-----------------------------------------------------------
    
    /** Last {@link XMLReaderConfiguration} constructed in {@link #createNSAwareXMLReaderForTransformerHandler(boolean)} */
    private XMLReaderConfiguration lastPipelineXMLReaderConfiguration;
    
    public SAXParser createNSAwareSAXParser(boolean wantValidating) {
        SAXParserFactory parserFactory = SAXParserFactory.newInstance();
        parserFactory.setNamespaceAware(true);
        parserFactory.setValidating(wantValidating);
        try {
            return parserFactory.newSAXParser();
        }
        catch (Exception e) {
            throw new JAXPConfigurationException("No suitable SAXParser available; please install and/or fix your CLASSPATH", e);
        }
    }
    
    public XMLReader createNSAwareXMLReader(boolean wantValidating) {
        SAXParser parser = createNSAwareSAXParser(wantValidating);
        try {
            return parser.getXMLReader();
        }
        catch (SAXException e) {
            throw new JAXPConfigurationException("Could not get XMLReader from SAXParser", e);
        }
    }
    
    public XMLReader createNSAwareXMLReaderForTransformerHandler(boolean wantValidating) {
        /* Create an XMLReader and SAXTransformerFactory */
        XMLReader result = createNSAwareXMLReader(wantValidating);
        SAXTransformerFactory transformerFactory = createSAXTransformerFactory();
        
        /* See if we have a configuration for this. If so, use it. If not, create a configuration.
         * Since most people won't be changing these factories on the hoof, only one configuration
         * is stored at a time.
         */
        if (lastPipelineXMLReaderConfiguration==null
                || !lastPipelineXMLReaderConfiguration.xmlReaderClass.equals(result.getClass())
                || !lastPipelineXMLReaderConfiguration.transformerFactoryClass.equals(transformerFactory.getClass())) {
            /* Create new configuration */
            lastPipelineXMLReaderConfiguration = createConfiguration(result, transformerFactory);
        }
        /* Now apply configuration to the XMLReader */
        configureXMLReader(result, lastPipelineXMLReaderConfiguration);
        
        /* That's it! */
        return result;
    }
    
    /**
     * Works out the appropriate configuration for the SAXParser by creating a
     * dummy transform and analysing the results from that. This will
     * update the state maintained in this class.
     *
     * @throws JAXPConfigurationException if no configuration can be obtained.
     */
    private XMLReaderConfiguration createConfiguration(final XMLReader xmlReader, final SAXTransformerFactory transformerFactory) {
        try {
            SAXSource source = new SAXSource(xmlReader, new InputSource(new StringReader("<x/>")));
            SAXResult result = new SAXResult(new DefaultHandler());
            transformerFactory.newTransformer().transform(source, result);

            XMLReaderConfiguration config = new XMLReaderConfiguration(xmlReader.getClass(), transformerFactory.getClass());
            Map<String,Boolean> saxFeatureMap = config.saxFeatureMap;
            for (String saxFeature : SAX_FEATURES_FOR_TRANSFORMERHANDLER) {
                try {
                    Boolean value = xmlReader.getFeature(saxFeature);
                    log.debug("Found feature " + saxFeature + " => " + value);
                    saxFeatureMap.put(saxFeature, value);
                }
                catch (SAXNotSupportedException e) {
                    /* Can't do anything with this feature */
                    log.debug("Feature " + saxFeature + " is not supported");
                }
                catch (SAXNotRecognizedException e) {
                    /* Feature not supported so ignore */
                    log.debug("Feature " + saxFeature + " is not recognised");
                }
            }
            return config;
        }
        catch (Exception e) {
            throw new JAXPConfigurationException("Cannot configure suitable XMLReader", e);
        }
    }
    
    /**
     * Configures the given {@link XMLReader} using the given {@link XMLReaderConfiguration} as a template
     * for the features required.
     *
     * @throws JAXPConfigurationException if configuration failed configured.
     */
    private void configureXMLReader(XMLReader reader, XMLReaderConfiguration configuration) {
        try {
            for (Entry<String,Boolean> saxFeatureEntry : configuration.saxFeatureMap.entrySet()) {
                reader.setFeature(saxFeatureEntry.getKey(), saxFeatureEntry.getValue().booleanValue());
            }
        }
        catch (Exception e) {
            throw new JAXPConfigurationException(e);
        }
    }
    
    /**
     * Simple "struct" class used for storing the best configurations for the given
     * pairs of {@link XMLReader} and {@link SAXTransformerFactory} types.
     *
     * @author  David McKain
     * @version $Revision: 58 $
     */
    private static final class XMLReaderConfiguration {
        
        /** {@link XMLReader} class that this configuration supports */
        public final Class<? extends XMLReader> xmlReaderClass;

        /** {@link SAXTransformerFactory} class that this configuration supports */
        public final Class<? extends SAXTransformerFactory> transformerFactoryClass;

        /** Best values for the various supported {@link SAXFeatures}, mapping feature name -> Boolean value. */
        public final Map<String, Boolean> saxFeatureMap;

        XMLReaderConfiguration(final Class<? extends XMLReader> xmlReaderClass,
                final Class<? extends SAXTransformerFactory> factoryClass) {
            this.xmlReaderClass = xmlReaderClass;
            this.transformerFactoryClass = factoryClass;
            this.saxFeatureMap = new HashMap<String, Boolean>();
        }
    }
    
    //-----------------------------------------------------------
    
    /**
     * Creates a vanilla {@link TransformerFactory} with no further configuration performed on it.
     * 
     * @throws JAXPConfigurationException if factory could not be instantiated.
     */
    public TransformerFactory createTransformerFactory() {
        try {
            return TransformerFactory.newInstance();
        }
        catch (TransformerFactoryConfigurationError e) {
            throw new JAXPConfigurationException("Could not create TransformerFactory", e);
        }
    }

    /**
     * Creates a new {@link SAXTransformerFactory} instance and ensures it can support
     * transforms with SAX Sources and SAX Results. If the factory cannot be prepared
     * as such then a fatal error is logged a {@link JAXPConfigurationException}
     * is thrown.
     *
     * @return SAXTransformerFactory which can handle SAXSource and SAXResults.
     *
     * @throws JAXPConfigurationException if no such factory can be created.
     */
    public SAXTransformerFactory createSAXTransformerFactory() {
        TransformerFactory transformerFactory = createTransformerFactory();
        XMLUtilities.requireFeature(transformerFactory, SAXTransformerFactory.FEATURE);
        XMLUtilities.requireFeature(transformerFactory, SAXSource.FEATURE);
        XMLUtilities.requireFeature(transformerFactory, SAXResult.FEATURE);
        
        /* Must have been OK! */
        return (SAXTransformerFactory) transformerFactory;
    }
    
    /**
     * Creates a new {@link TransformerFactory} instance and ensures it can support
     * transforms with DOM Sources and DOM Results. If the factory cannot be prepared
     * as such then a fatal error is logged a {@link JAXPConfigurationException}
     * is thrown.
     *
     * @return TransformerFactory which can handle SAXSource and SAXResults.
     *
     * @throws JAXPConfigurationException if no such factory can be created.
     */
    public TransformerFactory createDOMCompatibleTransformerFactory() {
        TransformerFactory transformerFactory = createTransformerFactory();
        XMLUtilities.requireFeature(transformerFactory, DOMSource.FEATURE);
        XMLUtilities.requireFeature(transformerFactory, DOMResult.FEATURE);
        
        /* Must have been OK! */
        return transformerFactory;
    }
    
    //-----------------------------------------------------------
    
    public DocumentBuilder createNSAwareDocumentBuilder(boolean wantValidating) {
        DocumentBuilderFactory documentBuilderFactory = DocumentBuilderFactory.newInstance();
        documentBuilderFactory.setValidating(wantValidating);
        documentBuilderFactory.setNamespaceAware(true);
        try {
            return documentBuilderFactory.newDocumentBuilder();
        }
        catch (ParserConfigurationException e) {
            throw new JAXPConfigurationException("No suitable DocumentBuilder available; please install and/or fix your CLASSPATH", e);
        }
    }

    //-------------------------------------------------------------------
    
    public static void main(String[] args) {
        StringBuilder outputBuilder = new StringBuilder();
        outputBuilder.append("Factory Method Results:\n\n");
        
        Class<?>[] emptyArgumentsDecl = new Class<?>[0];
        Class<?>[] booleanArgumentDecl = new Class<?>[] { Boolean.TYPE };
        appendResult(outputBuilder, "createTransformerFactory", emptyArgumentsDecl);
        appendResult(outputBuilder, "createSAXTransformerFactory", emptyArgumentsDecl);
        appendResult(outputBuilder, "createDOMCompatibleTransformerFactory", emptyArgumentsDecl);
        
        for (Boolean boolValue : new Boolean[] { Boolean.FALSE, Boolean.TRUE }) {
            appendResult(outputBuilder, "createNSAwareDocumentBuilder", booleanArgumentDecl, boolValue);
            appendResult(outputBuilder, "createNSAwareSAXParser", booleanArgumentDecl, boolValue);
            appendResult(outputBuilder, "createNSAwareXMLReader", booleanArgumentDecl, boolValue);
            appendResult(outputBuilder, "createNSAwareXMLReaderForTransformerHandler", booleanArgumentDecl, boolValue);
        }
        
        outputBuilder.append("\nSAX Features allowing XMLReader to work with TransformerHandler:\n\n");
        XMLReader xmlReader = singletonInstance.createNSAwareXMLReaderForTransformerHandler(false);
        for (String featureName : SAX_FEATURES_FOR_TRANSFORMERHANDLER) {
            outputBuilder.append(featureName).append(" => ");
            try {
                outputBuilder.append(xmlReader.getFeature(featureName));
            }
            catch (Exception e) {
                outputBuilder.append("[Not supported/recognised]");
            }
            outputBuilder.append('\n');
        }
        System.out.print(outputBuilder);
    }
    
    private static void appendResult(StringBuilder outputBuilder, String methodName, Class<?>[] parameterTypes, Object... parameterValues) {
        outputBuilder.append(methodName).append("(");
        StringUtilities.join(outputBuilder, parameterValues, ",");
        outputBuilder.append(") => ");
        try {
            Method method = singletonInstance.getClass().getMethod(methodName, parameterTypes);
            outputBuilder.append(method.invoke(singletonInstance, parameterValues).getClass().getName());
        }
        catch (Exception e) {
            if (e instanceof JAXPConfigurationException) {
                outputBuilder.append("[No suitable result avaiable under current configuration]");
            }
            else {
                outputBuilder.append("[Got Exception " + e + "]");
            }
        }
        outputBuilder.append('\n');

    }
}