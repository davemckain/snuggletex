/* $Id: ObjectWriterStrategy.java 58 2008-08-03 19:29:15Z dmckain $
 *
 * Copyright (c) 2003 - 2008 University of Edinburgh.
 * All Rights Reserved
 */
package uk.ac.ed.ph.commons.databinding;

import java.util.Map;

import org.xml.sax.ContentHandler;
import org.xml.sax.SAXException;

/**
 * Interface for classes which can fire off a series of SAX Events
 * serializing a particular type of Object.
 * <p>
 * You should create an implementation of this interface for each Class
 * of Object being serialized.
 * <p>
 * An instance of this class will created and reused by a single Thread.
 * Therefore, instances should be reusable but not thread-safe.
 * <p>
 * Normally you'll want to use one of the convenience subclasses for this.
 *
 * @author  David McKain
 * @version $Revision: 58 $
 */
public interface ObjectWriterStrategy<E> {

    /**
     * Sets the {@link AbstractMarshaller} instance that created this strategy. This happens
     * before anything else is called and allows the strategy to call back
     * on the {@link AbstractMarshaller} in case embedded Objects need to be written.
     *
     * @param marshaller
     */
    void setMarshaller(AbstractMarshaller marshaller);

    /**
     * Generates an XML document from the given Object by firing off a complete
     * series of SAX Events at the given {@link ContentHandler} contentHandler.
     *
     * @param object Object to write, of the correct Class handled by this
     *   strategy.
     * @param contentHandler ContentHandler to fire events at.
     */
    void generateDocument(E object, ContentHandler contentHandler)
        throws SAXException;

    /**
     * Generates an XML fragment from the given Object by firing off
     * SAX Events. These events can be embedded in a partial document.
     *
     * @param object Object to write, of the correct Class handled by this strategy.
     * @param contentHandler ContentHandler to fire events at.
     * @param inscopeNamespaceMappings Map of currently in-scope namespace mappings in the
     *   form prefix => namespace, which may be null if no mappings have yet been made.
     *   Implementations must not alter this map!
     */
    void generateFragment(E object, ContentHandler contentHandler,
            Map<String,String> inscopeNamespaceMappings)
        throws SAXException;

    /**
     * Called after the SAX Events have been fired. Implementations should
     * use this as a chance to clear up any state accrued and become ready
     * for reuse.
     * <p>
     * <strong>Note:</strong> This is currently not necessary in its present
     * form as we are no longer caching strategies, but it's good housekeeping
     * to have and may return in future.
     */
    void reset();

    /**
     * Gets the System ID of the resulting XML documents. This System ID
     * will appear in the DOCTYPE declaration of resulting XML documents.
     * If null, no DOCTYPE declaration is produced.
     */
    String getSystemId();
}
