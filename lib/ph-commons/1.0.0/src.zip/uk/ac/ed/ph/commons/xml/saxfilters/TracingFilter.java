/* $Id:TracingFilter.java 2824 2008-08-01 15:46:17Z davemckain $
 *
 * Copyright (c) 2003 - 2008 University of Edinburgh.
 * All Rights Reserved
 */
package uk.ac.ed.ph.commons.xml.saxfilters;

import uk.ac.ed.ph.commons.xml.JAXPConfigurationException;
import uk.ac.ed.ph.commons.xml.XMLFactory;

import java.io.File;
import java.io.IOException;

import javax.xml.transform.OutputKeys;
import javax.xml.transform.Result;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.sax.TransformerHandler;

import org.xml.sax.Attributes;
import org.xml.sax.ContentHandler;
import org.xml.sax.DTDHandler;
import org.xml.sax.EntityResolver;
import org.xml.sax.ErrorHandler;
import org.xml.sax.InputSource;
import org.xml.sax.Locator;
import org.xml.sax.SAXException;
import org.xml.sax.SAXNotRecognizedException;
import org.xml.sax.SAXNotSupportedException;
import org.xml.sax.SAXParseException;
import org.xml.sax.XMLReader;
import org.xml.sax.ext.LexicalHandler;

/**
 * Simple variation of {@link XMLLexicalTeeFilter} which uses the 2nd outgoing
 * SAX stream to create a serialized copy of the incoming SAX Events. This can
 * be very handy for debugging.
 * 
 * <h2>Usage</h2>
 * 
 * <strong>Note:</strong> You don't want to change the output stream while
 * parsing is happening. We don't test for that.
 * 
 * <strong>Note:</strong> I have intentionally <strong>not</strong> added a
 * constructor that takes a {@link File} Object as the JAXP API does NOT close
 * streams so the resulting stream would never be closed. It is up to the caller
 * to manage this.
 * 
 * @author  David McKain
 * @version $Revision:2824 $
 */
public class TracingFilter extends XMLLexicalFilterImpl {
    
    private final XMLFactory xmlFactory;

    /** Underlying Tee Filter */
    private final XMLLexicalTeeFilter teeFilter;

    /** TrAX Result Object that the tracing output will be sent to/stored at */
    private Result tracingResult;

    public TracingFilter(XMLFactory xmlFactory) {
        this(xmlFactory, null);
    }

    public TracingFilter(XMLFactory xmlFactory, Result result) {
        this.xmlFactory = xmlFactory;
        this.teeFilter = new XMLLexicalTeeFilter();
        setTracingResult(result);
    }

    public Result getTracingResult() {
        return tracingResult;
    }

    /**
     * Sets the TrAX Result Object that the trace output will be sent to.
     * <p>
     * This MUST be set before parsing begins.
     *
     * @param tracingResult Result to send the output to
     */
    public void setTracingResult(Result tracingResult) {
        this.tracingResult = tracingResult;
    }

    //-------------------------------------------------

    /**
     * Overridden to initialise the trace serializer at the start of the document.
     *
     * @throws IllegalStateException if no tracer has been set.
     * @throws JAXPConfigurationException if the trace serializer could not be set up.
     * @throws SAXException
     */
    @Override
    public void startDocument() throws SAXException {
        if (tracingResult==null) {
            throw new IllegalStateException("Trace Result has not been set");
        }
        /* Create a serializer */
        TransformerHandler serializerHandler;
        try {
            serializerHandler = xmlFactory.createSAXTransformerFactory().newTransformerHandler();
        }
        catch (TransformerConfigurationException e) {
            /* Should only happen in very bad circumstances so wrap up */
            throw new JAXPConfigurationException(e);
        }
        /* Configure serializer */
        Transformer serializerTransformer = serializerHandler.getTransformer();
        serializerTransformer.setOutputProperty(OutputKeys.METHOD, "xml");
        serializerTransformer.setOutputProperty(OutputKeys.INDENT, "yes");
        serializerHandler.setResult(tracingResult);

        /* Set the serializer as the secondary output of the Tee filter */
        teeFilter.setTeeContentHandler(serializerHandler);
        teeFilter.setTeeLexicalHandler(serializerHandler);

        /* Then delegate to the Tee filter */
        teeFilter.startDocument();
    }

    @Override
    public void endDocument() throws SAXException {
        teeFilter.endDocument();
    }

    @Override
    public void characters(char[] ch, int start, int length) throws SAXException {
        teeFilter.characters(ch, start, length);
    }

    @Override
    public void comment(char[] ch, int start, int length) throws SAXException {
        teeFilter.comment(ch, start, length);
    }

    @Override
    public void endCDATA() throws SAXException {
        teeFilter.endCDATA();
    }

    @Override
    public void endDTD() throws SAXException {
        teeFilter.endDTD();
    }

    @Override
    public void endElement(String uri, String localName, String qName) throws SAXException {
        teeFilter.endElement(uri, localName, qName);
    }

    @Override
    public void endEntity(String name) throws SAXException {
        teeFilter.endEntity(name);
    }

    @Override
    public void endPrefixMapping(String prefix) throws SAXException {
        teeFilter.endPrefixMapping(prefix);
    }

    @Override
    public void error(SAXParseException exception) throws SAXException {
        teeFilter.error(exception);
    }

    @Override
    public void fatalError(SAXParseException exception) throws SAXException {
        teeFilter.fatalError(exception);
    }

    @Override
    public ContentHandler getContentHandler() {
        return teeFilter.getContentHandler();
    }

    @Override
    public DTDHandler getDTDHandler() {
        return teeFilter.getDTDHandler();
    }

    @Override
    public EntityResolver getEntityResolver() {
        return teeFilter.getEntityResolver();
    }

    @Override
    public ErrorHandler getErrorHandler() {
        return teeFilter.getErrorHandler();
    }

    @Override
    public boolean getFeature(String name) throws SAXNotRecognizedException,
            SAXNotSupportedException {
        return teeFilter.getFeature(name);
    }

    @Override
    public LexicalHandler getLexicalHandler() {
        return teeFilter.getLexicalHandler();
    }

    @Override
    public XMLReader getParent() {
        return teeFilter.getParent();
    }

    @Override
    public Object getProperty(String name) throws SAXNotRecognizedException,
            SAXNotSupportedException {
        return teeFilter.getProperty(name);
    }

    @Override
    public void ignorableWhitespace(char[] ch, int start, int length) throws SAXException {
        teeFilter.ignorableWhitespace(ch, start, length);
    }

    @Override
    public void notationDecl(String name, String publicId, String systemId) throws SAXException {
        teeFilter.notationDecl(name, publicId, systemId);
    }

    @Override
    public void parse(String systemId) throws IOException, SAXException {
        teeFilter.parse(systemId);
    }

    @Override
    public void parse(InputSource input) throws IOException, SAXException {
        teeFilter.parse(input);
    }

    @Override
    public void processingInstruction(String target, String data) throws SAXException {
        teeFilter.processingInstruction(target, data);
    }

    @Override
    public InputSource resolveEntity(String publicId, String systemId) throws SAXException,
            IOException {
        return teeFilter.resolveEntity(publicId, systemId);
    }

    @Override
    public void setContentHandler(ContentHandler handler) {
        teeFilter.setContentHandler(handler);
    }

    @Override
    public void setDocumentLocator(Locator locator) {
        teeFilter.setDocumentLocator(locator);
    }

    @Override
    public void setDTDHandler(DTDHandler handler) {
        teeFilter.setDTDHandler(handler);
    }

    @Override
    public void setEntityResolver(EntityResolver resolver) {
        teeFilter.setEntityResolver(resolver);
    }

    @Override
    public void setErrorHandler(ErrorHandler handler) {
        teeFilter.setErrorHandler(handler);
    }

    @Override
    public void setFeature(String name, boolean value) throws SAXNotRecognizedException,
            SAXNotSupportedException {
        teeFilter.setFeature(name, value);
    }

    @Override
    public void setLexicalHandler(LexicalHandler handler) {
        teeFilter.setLexicalHandler(handler);
    }

    @Override
    public void setParent(XMLReader parent) {
        teeFilter.setParent(parent);
    }

    @Override
    public void setProperty(String name, Object value) throws SAXNotRecognizedException,
            SAXNotSupportedException {
        teeFilter.setProperty(name, value);
    }

    @Override
    public void skippedEntity(String name) throws SAXException {
        teeFilter.skippedEntity(name);
    }

    @Override
    public void startCDATA() throws SAXException {
        teeFilter.startCDATA();
    }

    @Override
    public void startDTD(String name, String publicId, String systemId) throws SAXException {
        teeFilter.startDTD(name, publicId, systemId);
    }

    @Override
    public void startElement(String uri, String localName, String qName, Attributes atts)
            throws SAXException {
        teeFilter.startElement(uri, localName, qName, atts);
    }

    @Override
    public void startEntity(String name) throws SAXException {
        teeFilter.startEntity(name);
    }

    @Override
    public void startPrefixMapping(String prefix, String uri) throws SAXException {
        teeFilter.startPrefixMapping(prefix, uri);
    }

    @Override
    public void unparsedEntityDecl(String name, String publicId, String systemId,
            String notationName) throws SAXException {
        teeFilter.unparsedEntityDecl(name, publicId, systemId, notationName);
    }

    @Override
    public void warning(SAXParseException exception) throws SAXException {
        teeFilter.warning(exception);
    }
}
