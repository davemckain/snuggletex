/* $Id:IllegalXMLCharacterFilter.java 2824 2008-08-01 15:46:17Z davemckain $
 *
 * Copyright (c) 2003 - 2008 University of Edinburgh.
 * All Rights Reserved
 */
package uk.ac.ed.ph.commons.xml.saxfilters;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.XMLFilterImpl;

/**
 * Trivial XML Filter that removes any Unicode characters that are not allowed in
 * XML documents from incoming character data.
 * <p>
 * This can be useful if you need to serialize results as XML downstream as otherwise
 * the results will not be parseable.
 * <p>
 * An instance of this class is stateless so is thread-safe and reusable.
 *
 * @author  David McKain
 * @version $Revision:2824 $
 */
public class IllegalXMLCharacterFilter extends XMLFilterImpl {
    
    private static final Log log = LogFactory.getLog(IllegalXMLCharacterFilter.class);
    
    @Override
    public void characters(char[] ch, int start, int length) throws SAXException {
        int pos;
        int startOfLastGoodRegion = -1; /* Records pos of first legal char in run, -1 if not in a legal run */
        char c;
        for (pos = start; pos < start+length; pos++) {
            c = ch[pos];
            if (c<32 && !(c==9 || c==10 || c==13)) {
                /* Current character is illegal. Dump existing buffer and then output this character */
                if (startOfLastGoodRegion!=-1) {
                    super.characters(ch, startOfLastGoodRegion, pos-startOfLastGoodRegion);
                }
                /* Mark that we've finished a region of good characters */
                startOfLastGoodRegion = -1;
                
                /* Output a replacement for the illegal character */
                handleIllegalCharacter(c);
            }
            else {
                /* Current character is OK */
                if (startOfLastGoodRegion==-1) {
                    /* Mark current position as starting a (hopefully) good run of chars */
                    startOfLastGoodRegion = pos;
                }
            }
        }
        /* Fire any left-over good characters */
        if (startOfLastGoodRegion!=-1) {
            super.characters(ch, startOfLastGoodRegion, length-(startOfLastGoodRegion-start));
        }
    }
    
    @SuppressWarnings("unused")
    protected void handleIllegalCharacter(char c) throws SAXException {
        log.warn("Unicode character U+"
                + Integer.toHexString(c)
                + " removed as it is not legal in XML");
    }
}
