/* $Id:StatefulFilter.java 2824 2008-08-01 15:46:17Z davemckain $
 *
 * Copyright (c) 2003 - 2008 University of Edinburgh.
 * All Rights Reserved
 */
package uk.ac.ed.ph.commons.xml.saxfilters;

import uk.ac.ed.ph.commons.xml.XMLPipeline;

import org.xml.sax.SAXException;

/**
 * Trivial extension of {@link XMLLexicalFilterImpl} that defines a "stateful" filter, i.e.
 * one that keeps track of stuff doing parsing.
 * <p>
 * This interface is not very exciting, but is good for documentation purposes.
 * 
 * TODO: Think about cleaning up after errors. Maybe {@link XMLPipeline} should explicitly call
 * {@link #resetState()} when this happens?
 *
 * @author  David McKain
 * @version $Revision:2824 $
 */
public abstract class StatefulFilter extends XMLLexicalFilterImpl {
    
    /** Called at the start of parsing to initialise the internal state as appropriate. */
    public abstract void initState();
    
    /** 
     * Called at the end of successful parsing. Subclasses should implement to verify that
     * the internal state is consistent at this point.
     * 
     * @throws IllegalStateException if the internal state is inconsistent at this point.
     */
    public abstract void checkFinalState();
    
    /**
     * Called at the end of successful parsing. Subclasses should fill in to clear things up
     * and allow garbage collection (if appropriate). Classes using this filter should also
     * call this method if parsing fails for some reason to ensure that things are cleaned up
     * properly.
     */
    public abstract void resetState();
    
    @Override
    public void startDocument() throws SAXException {
        initState();
        super.startDocument();
    }
    
    @Override
    public void endDocument() throws SAXException {
        checkFinalState();
        super.endDocument();
        resetState();
    }
}
