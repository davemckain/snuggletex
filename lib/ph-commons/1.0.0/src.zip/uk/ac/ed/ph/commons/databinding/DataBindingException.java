/* $Id: DataBindingException.java 58 2008-08-03 19:29:15Z dmckain $
 *
 * Copyright (c) 2003 - 2008 University of Edinburgh.
 * All Rights Reserved
 */
package uk.ac.ed.ph.commons.databinding;

/**
 * Base Exception class for problems occurring using the Data Binding packages.
 * <p>
 * This is a {@link RuntimeException} since data binding Exceptions are always
 * caused by programming errors.
 *
 * @author  David McKain
 * @version $Revision: 58 $
 */
public class DataBindingException extends RuntimeException {

    private static final long serialVersionUID = 3258130237031396914L;

    public DataBindingException() {
        super();
    }

    public DataBindingException(String message) {
        super(message);
    }

    public DataBindingException(String message, Throwable cause) {
        super(message, cause);
    }

    public DataBindingException(Throwable cause) {
        super(cause);
    }
}
