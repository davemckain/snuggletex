/* $Id:XMLPipeline.java 2824 2008-08-01 15:46:17Z davemckain $
 *
 * Copyright (c) 2003 - 2008 University of Edinburgh.
 * All Rights Reserved
 */
package uk.ac.ed.ph.commons.xml;

import uk.ac.ed.ph.commons.xml.saxfilters.XMLLexicalFilterImpl;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.xml.parsers.SAXParser;
import javax.xml.transform.Result;
import javax.xml.transform.Source;
import javax.xml.transform.Templates;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.sax.SAXResult;
import javax.xml.transform.sax.SAXTransformerFactory;
import javax.xml.transform.sax.TransformerHandler;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.xml.sax.ContentHandler;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
import org.xml.sax.XMLReader;
import org.xml.sax.ext.LexicalHandler;
import org.xml.sax.helpers.XMLFilterImpl;

/**
 * This is a simple layer on top of the TrAX API for building (SAX-based)
 * XML Pipelines.
 * <p>
 * You use this by creating a <code>new XMLPipeline(XMLFilter)</code>. You
 * then add a number of steps to the pipeline (filters, XSLT steps
 * and terminating steps) using the various <code>addXXX</code>
 * methods.
 * <p>
 * Each time you add a step, the previous step will be configured so that
 * it sends its output to the new step.
 * <p>
 * Your final step will normally be a serializer ({@link #addSerializer(Result)})
 * or a terminating ContentHandler ({@link #addTerminalStep(ContentHandler)}
 * though it can be anything - obviously a final step which does nothing
 * is possibly a waste of time!
 * <p>
 * To run the pipeline, call the {@link #execute(File)} method, supplying
 * the input for the pipeline. Some convenience facilities have been added
 * for reporting runtime XSLT errors.
 * <p>
 * Alternatively, you can pull out the first SAX handler in the pipeline by
 * calling <code>getStep(0)</code> and feed this handler directly with SAX
 * events.
 * <p>
 * Each pipeline contains a reference to the {@link XMLFactory} passed to
 * it during creation, which is available to you for accessing an {@link SAXTransformerFactory}
 * (used to build steps) and a {@link XMLReader} (used for the parsing).
 * You can use the {@link SAXTransformerFactory}
 * to create {@link Templates} objects and you can use the {@link XMLReader}
 * to add Error Handlers and stuff during the parsing stage.
 * <p>
 * <strong>Important Node:</strong> You CANNOT reuse a pipeline since it
 * uses JAXP {@link TransformerHandler}s to implement the XSLT stages and
 * these are not reusable (though not well documented). However, constructing
 * the pipeline is very simple so if you stick to reusable filters and
 * compiled stylesheets ({@link #addTransformStep(Templates)}) then reconstructing
 * a pipeline is efficient and just amounts to doing a bit of configuration.
 * The pipeline will complain if you try to reuse it.
 *
 * @author  David McKain
 * @version $Revision:2824 $
 */
public final class XMLPipeline {

    private static final Log log = LogFactory.getLog(XMLPipeline.class);
    
    /** {@link XMLFactory} used to instantiate SAX/XSLT classes */
    private final XMLFactory xmlFactory;

    /** SAXTransformerFactory used during the lifetime of this pipeline */
    private final SAXTransformerFactory saxTransFactory;

    /** XMLReader that will do the parsing of the first step of the pipeline */
    private final XMLReader sourceReader;

    /** ContentHandlers at each step of the pipeline. */
    private final List<ContentHandler> steps;

    /** Will also keep hold of the last step */
    private ContentHandler lastStep;

    /** Flag to indicate that pipeline has run */
    private boolean hasRun;

    /** Flag to indicate that no more steps can be added */
    private boolean isClosed;

    /**
     * Creates a new XML Pipeline with a non-validating parser.
     */
    public XMLPipeline(XMLFactory xmlFactory) {
        this(xmlFactory, false);
    }

    /**
     * Creates a new XML Pipeline with an optionally validating
     * parser.
     *
     * @param isValidating true if you want the XMLReader to be
     *   validating, false otherwise. You can always turn validation
     *   off if needed.
     */
    public XMLPipeline(XMLFactory xmlFactory, boolean isValidating) {
        this.xmlFactory = xmlFactory;
        
        /* Create SAXTransformerFactory to allow any TransformerHandlers
         * to be created. We also expose this to callers to help
         * them create Templates objects.
         */
        log.debug("Creating SAXTransformerFactory for creating XSLT steps");
        saxTransFactory = xmlFactory.createSAXTransformerFactory();
        if (log.isDebugEnabled()) {
            log.debug("SAXTransformerFactory is " + saxTransFactory.getClass().getName());
        }
        /* Create a SAX Parser for running the pipeline which has been correctly
         * configured for passing events to a TransforemrHandler
         */
        log.debug("Creating SAXParser to use for instantiating this pipeline");
        sourceReader = xmlFactory.createNSAwareXMLReaderForTransformerHandler(isValidating);

        this.steps = new ArrayList<ContentHandler>();
        this.lastStep = null;
        this.hasRun = false;
        this.isClosed = false;
    }

    //-------------------------------------------------

    /**
     * Adds the given XML Filter to the pipeline.
     */
    public void addFilterStep(XMLFilterImpl step) {
        addStepObject(step);
    }

    /**
     * Adds the given XML Filter supporting lexical events to the pipeline.
     */
    public void addFilterStep(XMLLexicalFilterImpl step) {
        addStepObject(step);
    }

    /**
     * Adds the given ContentHandler to the pipeline. This is considered
     * a terminal step as a vanilla ContentHandler is not able to pass
     * events onwards.
     */
    public void addTerminalStep(ContentHandler step) {
        addStepObject(step);
        isClosed = true;
    }

    /**
     * Adds an XSLT Transformation step using the given compiled
     * stylesheet Templates object. The XMLPipeline will turn this into
     * a {@link TransformerHandler} that will be used to process the
     * incoming SAX Events.
     * <p>
     * This handler is returned to allow you to
     * get at the underlying Transformer object to allow you to set
     * parameters and such-like.
     *
     * @param step compiled stylesheet to add
     * @return a TransformerHandler that will perform the actual SAX filtering
     *
     * @throws JAXPConfigurationException if a TransformerHandler
     *   could not be created from your Templates.
     */
    public TransformerHandler addTransformStep(Templates step) {
        /* Create a TransformerHandler for the Templates object */
        TransformerHandler xsltHandler;
        try {
            xsltHandler = saxTransFactory.newTransformerHandler(step);
        }
        catch (TransformerConfigurationException e) {
            throw new JAXPConfigurationException(e);
        }
        addStepObject(xsltHandler);
        return xsltHandler;
    }

    /**
     * Adds an XSLT Transformation step which will be read in from the
     * given TrAX Source object. The XMLPipeline will turn this into
     * a {@link TransformerHandler} that will be used to process the
     * incoming SAX Events.
     * <p>
     * @see #addTransformStep(Templates)
     *
     * @throws JAXPConfigurationException if a TransformerHandler
     *   could not be created from your Templates.
     */
    public TransformerHandler addTransformStep(Source step) {
        /* Create TransformerHandler for the source */
        TransformerHandler xsltHandler;
        try {
            xsltHandler = saxTransFactory.newTransformerHandler(step);
        }
        catch (TransformerConfigurationException e) {
            throw new JAXPConfigurationException(e);
        }
        addStepObject(xsltHandler);
        return xsltHandler;
    }

    /**
     * Adds an XSLT Identity Transformation step. The XMLPipeline will turn this into
     * a {@link TransformerHandler} that will be used to process the
     * incoming SAX Events.
     * <p>
     * @see #addTransformStep(Templates)
     *
     * @throws JAXPConfigurationException if a TransformerHandler
     *   could not be created from your Templates.
     */
    public TransformerHandler addIdentityTransform() {
        /* Create TransformerHandler for the source */
        TransformerHandler xsltHandler;
        try {
            xsltHandler = saxTransFactory.newTransformerHandler();
        }
        catch (TransformerConfigurationException e) {
            throw new JAXPConfigurationException(e);
        }
        addStepObject(xsltHandler);
        return xsltHandler;
    }

    /**
     * Adds an serialization step to the pipeline. This is just an identity
     * transform. The pipeline will be considered closed after this; no
     * more steps can be added.
     * <p>
     * <strong>Note:</strong> If you're sending results to a "stream", remember
     * that you'll have to close the stream yourself!
     *
     * @param result TrAX Result object that the serializer will serialize to.
     *
     * @throws JAXPConfigurationException if a TransformerHandler
     *   could not be created from your Templates.
     *   
     * @see #addTransformStep(Templates)
     */
    public TransformerHandler addSerializer(Result result) {
        TransformerHandler serializer = addIdentityTransform();
        serializer.setResult(result);
        isClosed = true;
        return serializer;
    }

    //-------------------------------------------------

    /**
     * Internal method to do the actual job of adding to the pipeline.
     * This will configure the previous step so that it forwards to
     * this new step.
     */
    private void addStepObject(ContentHandler newStep) {
        if (log.isDebugEnabled()) {
            log.debug("Adding step " + newStep + " to pipeline " + this);
        }
        /* Make sure the pipeline isn't already closed */
        if (isClosed) {
            throw new IllegalStateException("Pipeline was closed by last step");
        }
        /* Make sure we don't already have this step */
        if (steps.contains(newStep)) {
            throw new IllegalStateException("This step has already been registered");
        }
        /* Decide whether step is just a CH or a CH/LH combo so that we can join it to
         * the last one correctly */
        ContentHandler newContentHandler = newStep;
        LexicalHandler newLexicalHandler = null;
        if (newStep instanceof LexicalHandler) {
            newLexicalHandler = (LexicalHandler) newStep;
        }
        /* Make the current last step fire on to this one */
        if (lastStep != null) {
            if (lastStep instanceof XMLLexicalFilterImpl) {
                /* Enhanced XML filter that copes with lexical events too */
                XMLLexicalFilterImpl lastFilter = (XMLLexicalFilterImpl) lastStep;
                lastFilter.setContentHandler(newContentHandler);
                lastFilter.setLexicalHandler(newLexicalHandler);
            }
            else if (lastStep instanceof XMLFilterImpl) {
                /* It's a standard XML Filter, which doesn't accept lexical events */
                XMLFilterImpl lastFilter = (XMLFilterImpl) lastStep;
                lastFilter.setContentHandler(newContentHandler);
            }
            else if (lastStep instanceof TransformerHandler) {
                /* It's an XSLT stylesheet */
                TransformerHandler lastTransform = (TransformerHandler) lastStep;
                /* Wire it up to forward to our new handler */
                SAXResult result = new SAXResult();
                result.setHandler(newContentHandler);
                result.setLexicalHandler(newLexicalHandler);
                lastTransform.setResult(result);
            }
            else {
                /* Last step closed the pipeline so we can't add this new one */
                throw new IllegalStateException("Last step added closed this pipeline");
            }
        }
        /* Now save our new step and remember it for the next run of the loop */
        lastStep = newStep;
        steps.add(newStep);
    }

    //----------------------------------------------------------

    /**
     * Returns the number of steps in this pipeline
     */
    public int getStepCount() {
        return steps.size();
    }

    /**
     * Gets the ContentHandler for the step at the given position.
     * You will be able to cast this to TransformerHandler (if it's
     * an XSLT step) or LexicalHandler (if its an XSLT Step or
     * an XMLLexicalFilterImpl step).
     *
     * @param pos the pipeline step to obtain, starting at 0 for
     *   the first step in the pipeline
     *
     * @return ContentHandler that receives SAX events at
     *   this step in the pipeline.
     *
     * @throws IndexOutOfBoundsException if pos is out of range.
     */
    public ContentHandler getStep(int pos) {
        return steps.get(pos);
    }

    /**
     * Convenience method that gets the last step in the pipeline,
     * null if no steps have been
     * added.
     *
     * @return ContentHandler that receives SAX events at the end of
     *   the pipeline.
     */
    public ContentHandler getLastStep() {
        return lastStep;
    }

    //----------------------------------------------------------
    
    public XMLFactory getXMLFactory() {
        return this.xmlFactory;
    }

    /**
     * Exposes the underlying SAXTransformerFactory used by this
     * factory. Callers can use this to create Templates objects
     * and/or set global properties for the TransformerHandlers
     * that will be created as you build your pipeline from
     * Source and/or Templates objects.
     *
     * @return Returns the underlying saxTransFactory.
     */
    public SAXTransformerFactory getSAXTransformerFactory() {
        return saxTransFactory;
    }

    public XMLReader getXMLReader() {
        return sourceReader;
    }

    //----------------------------------------------------------

    /**
     * Runs the pipeline on the given {@link InputSource} by constructing a
     * {@link SAXParser} suitably configured for working with the default
     * {@link SAXTransformerFactory}.
     * <p>
     * <b>IMPORTANT:</b> If your {@link TransformerHandler} steps were not created
     * by the default {@link SAXTransformerFactory} then this pipeline execution
     * will probably break.
     *
     * @param inputSource input document to be passed through the pipeline
     *
     * @throws TransformerException if a runtime error occurs during the
     *             transform.
     *
     * @throws SAXException if a parsing error occurs with the source document.
     *
     * @throws IOException
     * 
     * @see #execute(File)
     * @see #execute(File, String)
     */
    public void execute(InputSource inputSource) throws SAXException, IOException, TransformerException {
        /* Make sure pipeline hasn't already run */
        if (hasRun) {
            throw new IllegalStateException("Pipeline has already been run - they are not reusable");
        }
        hasRun = true;
        if (lastStep==null) {
            /* Nothing to do */
            return;
        }
        if (log.isDebugEnabled()) {
            log.debug("Running pipeline " + this + " on InputSource with System ID " + inputSource.getSystemId());
        }
        try {
            /* Wire our XMLReader up to the first step in the pipeline */
            ContentHandler firstContentHandler = steps.get(0);
            sourceReader.setContentHandler(firstContentHandler);
            if (firstContentHandler instanceof LexicalHandler) {
                sourceReader.setProperty("http://xml.org/sax/properties/lexical-handler",
                        firstContentHandler);
            }
            /* Then parse, which will fire the pipeline off */
            sourceReader.parse(inputSource);
        }
        catch (SAXException e) {
            /* Some Runtime XSLT errors get wrapped up by the TransformerHandler
             * as SAXExceptions. These contain TransformerExceptions which may contain
             * further SAXExceptions and/or TransformerExceptions etc. We'll extract the
             * deepest Exception of type SAXException or TransformerException and throw that.
             */
            Throwable currentException = e;
            Throwable deepestGoodException = e;
            Throwable parentException = null;
            while (currentException!=null) {
                if (currentException instanceof SAXException || currentException instanceof TransformerException) {
                    deepestGoodException = currentException;
                }
                /* Now unwind the current Exception, which is a bit tortuous unfortunately! */
                parentException = null;
                if (currentException instanceof SAXException) {
                    parentException = ((SAXException) currentException).getException();
                }
                else if (currentException instanceof TransformerException) {
                    parentException = ((TransformerException) currentException).getException();
                }
                if (parentException==null) {
                    parentException = currentException.getCause();
                }
                /* Phew! */
                currentException = parentException;
            }
            if (deepestGoodException instanceof TransformerException) {
                TransformerException transformerException = (TransformerException) deepestGoodException;
                log.info("XSLT Runtime error notification: " + transformerException.getMessageAndLocation());
                throw transformerException;
            }
            /* If still here then it deepestGoodException is SAXException */
            log.info("Error parsing pipeline source ", e);
            throw ((SAXException) deepestGoodException);
        }
        catch (IOException e) {
            log.info("XMLPipeline experienced IOException during parsing", e);
            throw e;
        }
        if (log.isDebugEnabled()) {
            log.debug("Execution of pipeline " + this + " succeeded");
        }
    }
    
    /**
     * Simple wrapper round {@link #execute(InputSource)} that takes a File
     * rather than an InputSource and uses the canonical <tt>file:...</tt> URI for its
     * System ID.
     *
     * @param inputXMLFile
     * @throws IOException
     * @throws SAXException
     * @throws TransformerException
     *
     * @see #execute(InputSource)
     * @see #execute(File, String)
     */
    public void execute(File inputXMLFile) throws IOException, SAXException, TransformerException {
        execute(inputXMLFile, inputXMLFile.toURI().toURL().toString());
    }

    /**
     * Simple wrapper round {@link #execute(InputSource)} that takes a File
     * rather than an InputSource. It also allow the system ID of the File to be specified, which
     * is sometimes useful if the File is a temporary copy of something belonging to a particular
     * URI scheme since, in this case, it makes sense for the system ID to be in the original
     * URI scheme rather than the <tt>file:...</tt> scheme.
     *
     * @param inputXMLFile
     * @throws IOException
     * @throws SAXException
     * @throws TransformerException
     *
     * @see #execute(InputSource)
     * @see #execute(File)
     */
    public void execute(File inputXMLFile, String systemId) throws IOException, SAXException,
            TransformerException {
        if (log.isDebugEnabled()) {
            log.debug("Starting XML parse of " + inputXMLFile);
        }
        FileInputStream inputStream = null;
        try {
            /* We will set the System ID on the InputSource just in case
             * some relative lookups are required.
             */
            inputStream = new FileInputStream(inputXMLFile);
            InputSource source = new InputSource(inputStream);
            source.setSystemId(systemId);
            execute(source);
        }
        catch (FileNotFoundException e) {
            log.info("XMLPipeline could not locate File to parse", e);
            throw e;
        }
        finally {
            try {
                if (inputStream!=null) {
                    inputStream.close();
                }
            }
            catch (IOException e) {
                log.warn("Could not close InputStream", e);
            }
        }
    }
}
