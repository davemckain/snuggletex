/* $Id: JAXPConfigurationException.java 58 2008-08-03 19:29:15Z dmckain $
 *
 * Copyright (c) 2003 - 2008 University of Edinburgh.
 * All Rights Reserved
 */
package uk.ac.ed.ph.commons.xml;

/**
 * This exception is used to indicate a problem creating suitable
 * classes for XML processing using the JAXP interfaces.
 * <p>
 * For example, it is used if we cannot create SAX Parsers having
 * the features required by our system.
 * <p>
 * This is an unchecked exception since we can't and shouldn't really
 * handle these programmatically as it normally indicates an issue
 * with deployment or configuration.
 *
 * @author  David McKain
 * @version $Revision: 58 $
 */
public class JAXPConfigurationException extends RuntimeException {

    private static final long serialVersionUID = 3258128059566995511L;

    public JAXPConfigurationException() {
        super();
    }

    public JAXPConfigurationException(String message) {
        super(message);
    }

    public JAXPConfigurationException(String message, Throwable cause) {
        super(message, cause);
    }

    public JAXPConfigurationException(Throwable cause) {
        super(cause);
    }
}
