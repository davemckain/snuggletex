/* $Id: AbstractMarshallingTest.java 58 2008-08-03 19:29:15Z dmckain $
 *
 * Copyright (c) 2003 - 2008 University of Edinburgh.
 * All Rights Reserved
 */
package uk.ac.ed.ph.commons.testutils.databinding;

/**
 * Simple JUnit 3.x base class for testing full marshalling (reading and writing)
 * between an Object and XML.
 *
 * @author  David McKain
 * @version $Revision: 58 $
 */
public abstract class AbstractMarshallingTest<T> extends AbstractReaderTest<T> {

    /**
     * This test parses, serialises then parses to ensure that
     * the final object matches what we started with.
     */
    public void testParseSerializeParseValidating() throws Exception {
        if (isXMLValidatable()) {
            String xmlSample = readSampleXML();
            T first = parseXML(xmlSample, true);
            String serialised = serialize(first);

            /* Do a Validating check */
            checkSampleData(parseXML(serialised, true));
        }
    }

    /**
     * This test parses, serialises then parses to ensure that
     * the final object matches what we started with.
     */
    public void testParseSerializeParseNonValidating() throws Exception {
        String xmlSample = readSampleXML();
        T first = parseXML(xmlSample, false);
        String serialised = serialize(first);
        
        /* Do a Validating check */
        checkSampleData(parseXML(serialised, false));
    }

    /**
     * This test ensures that a valid prototype Object as created
     * by the subclass serialises and parses correctly.
     *
     * @throws Exception
     */
    public void testPrototypeObject() throws Exception {
        T prototype = createPrototypeObject();
        String original = serialize(prototype);

        /* Test non-validating */
        T parsed = parseXML(original, false);
        String result = serialize(parsed);

        assertEquals(original, result);

        /* Test validating */
        if (isXMLValidatable()) {
            parsed = parseXML(original, true);
            result = serialize(parsed);
            assertEquals(original, result);
        }
    }

    //-------------------------------------------------------------

    protected String serialize(T object) throws Exception {
        return createMarshaller().writeObject(object);
    }
}
