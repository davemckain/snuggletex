/* $Id: DefaultReaderStrategy.java 58 2008-08-03 19:29:15Z dmckain $
 *
 * Copyright (c) 2003 - 2008 University of Edinburgh.
 * All Rights Reserved
 */
package uk.ac.ed.ph.commons.databinding;

import org.xml.sax.Attributes;
import org.xml.sax.SAXException;

/**
 * Convenience subclass of {@link SimpleReaderStrategy} that fills in
 * "do nothing" stubs for all of the various events.
 * <p>
 * This still needs subclassed before it can be used.
 *
 * @author  David McKain
 * @version $Revision: 58 $
 */
public abstract class DefaultReaderStrategy<E> extends SimpleReaderStrategy<E> {

    //-----------------------------------------------------
    // Register no interesting elements.

    @Override
    public ElementMap getContainerElements() {
        return null;
    }

    @Override
    public ElementMap getTextElements() {
        return null;
    }

    @Override
    public ElementMap getEmbeddedObjectElements() {
        return null;
    }

    @Override
    public ElementMap getMixedContentContainerElements() {
        return null;
    }

    //-----------------------------------------------------
    // No embedded objects registered so create null prototype.

    @Override
    public Object createEmbeddedObjectPrototype(String namespaceUri, String localName) {
        return null;
    }

    //-----------------------------------------------------
    // Do nothing when events happen


    @SuppressWarnings("unused")
    @Override
    public void embeddedObject(Object object, String namespaceUri, String localName) throws SAXException {
    }

    @SuppressWarnings("unused")
    @Override
    public void startContainerElement(String namespaceUri, String localName, Attributes attrs) throws SAXException {
    }

    @SuppressWarnings("unused")
    @Override
    public void endContainerElement(String namespaceUri, String localName) throws SAXException {
    }

    @SuppressWarnings("unused")
    @Override
    public void textElement(String namespaceUri, String localName, Attributes attrs, String value) throws SAXException {
    }

    @SuppressWarnings("unused")
    @Override
    public void mixedContent(String namespaceUri, String localName, Attributes attrs, String xmlFragment) throws SAXException {
    }

    @Override
    public void clearResultObject() {
    }

    @Override
    public void resetState() {
    }
}
