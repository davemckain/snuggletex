/* $Id:XMLLexicalTeeFilter.java 2824 2008-08-01 15:46:17Z davemckain $
 *
 * Copyright (c) 2003 - 2008 University of Edinburgh.
 * All Rights Reserved
 */
package uk.ac.ed.ph.commons.xml.saxfilters;

import org.xml.sax.Attributes;
import org.xml.sax.ContentHandler;
import org.xml.sax.SAXException;
import org.xml.sax.ext.LexicalHandler;

/**
 * Simple extension of {@link XMLLexicalFilterImpl} that passes incoming events
 * onwards as usual, whilst also firing them towards an additional pair of
 * {@link org.xml.sax.ContentHandler} and {@link org.xml.sax.ext.LexicalHandler}s.
 * This can be used for tracing intermediate results.
 *
 * @author  David McKain
 * @version $Revision:2824 $
 */
public class XMLLexicalTeeFilter extends XMLLexicalFilterImpl {

    /** Additional ContentHandler to receive events, if requested. */
    protected ContentHandler teeContentHandler;

    /** Additional LexicalHandler to receive events, if requested */
    protected LexicalHandler teeLexicalHandler;

    public ContentHandler getTeeContentHandler() {
        return teeContentHandler;
    }

    public LexicalHandler getTeeLexicalHandler() {
        return teeLexicalHandler;
    }

    public void setTeeContentHandler(ContentHandler handler) {
        teeContentHandler = handler;
    }

    public void setTeeLexicalHandler(LexicalHandler handler) {
        teeLexicalHandler = handler;
    }

    //--------------------------------------------------------------

    @Override
    public void comment(char[] ch, int start, int length) throws SAXException {
        if (teeLexicalHandler!=null) {
            teeLexicalHandler.comment(ch, start, length);
        }
        super.comment(ch, start, length);
    }

    @Override
    public void endCDATA() throws SAXException {
        if (teeLexicalHandler!=null) {
            teeLexicalHandler.endCDATA();
        }
        super.endCDATA();
    }

    @Override
    public void endDTD() throws SAXException {
        if (teeLexicalHandler!=null) {
            teeLexicalHandler.endDTD();
        }
        super.endDTD();
    }

    @Override
    public void endEntity(String name) throws SAXException {
        if (teeLexicalHandler!=null) {
            teeLexicalHandler.endEntity(name);
        }
        super.endEntity(name);
    }

    @Override
    public void startCDATA() throws SAXException {
        if (teeLexicalHandler!=null) {
            teeLexicalHandler.startCDATA();
        }
        super.startCDATA();
    }

    @Override
    public void startDTD(String name, String publicId, String systemId)
            throws SAXException {
        if (teeLexicalHandler!=null) {
            teeLexicalHandler.startDTD(name, publicId, systemId);
        }
        super.startDTD(name, publicId, systemId);
    }

    @Override
    public void startEntity(String name) throws SAXException {
        if (teeLexicalHandler!=null) {
            teeLexicalHandler.startEntity(name);
        }
        super.startEntity(name);
    }

    @Override
    public void characters(char[] ch, int start, int length) throws SAXException {
        if (teeContentHandler!=null) {
            teeContentHandler.characters(ch, start, length);
        }
        super.characters(ch, start, length);
    }

    @Override
    public void endDocument() throws SAXException {
        if (teeContentHandler!=null) {
            teeContentHandler.endDocument();
        }
        super.endDocument();
    }

    @Override
    public void endElement(String uri, String localName, String qName)
            throws SAXException {
        if (teeContentHandler!=null) {
            teeContentHandler.endElement(uri, localName, qName);
        }
        super.endElement(uri, localName, qName);
    }

    @Override
    public void endPrefixMapping(String prefix) throws SAXException {
        if (teeContentHandler!=null) {
            teeContentHandler.endPrefixMapping(prefix);
        }
        super.endPrefixMapping(prefix);
    }

    @Override
    public void ignorableWhitespace(char[] ch, int start, int length)
            throws SAXException {
        if (teeContentHandler!=null) {
            teeContentHandler.ignorableWhitespace(ch, start, length);
        }
        super.ignorableWhitespace(ch, start, length);
    }

    @Override
    public void processingInstruction(String target, String data)
            throws SAXException {
        if (teeContentHandler!=null) {
            teeContentHandler.processingInstruction(target, data);
        }
        super.processingInstruction(target, data);
    }

    @Override
    public void skippedEntity(String name) throws SAXException {
        if (teeContentHandler!=null) {
            teeContentHandler.skippedEntity(name);
        }
        super.skippedEntity(name);
    }

    @Override
    public void startDocument() throws SAXException {
        if (teeContentHandler!=null) {
            teeContentHandler.startDocument();
        }
        super.startDocument();
    }

    @Override
    public void startElement(String uri, String localName,
            String qName, Attributes atts) throws SAXException {
        if (teeContentHandler!=null) {
            teeContentHandler.startElement(uri, localName, qName, atts);
        }
        super.startElement(uri, localName, qName, atts);
    }

    @Override
    public void startPrefixMapping(String prefix, String uri) throws SAXException {
        if (teeContentHandler!=null) {
            teeContentHandler.startPrefixMapping(prefix, uri);
        }
        super.startPrefixMapping(prefix, uri);
    }
}
