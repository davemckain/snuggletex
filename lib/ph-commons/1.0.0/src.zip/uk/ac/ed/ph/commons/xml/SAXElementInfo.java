/* $Id: SAXElementInfo.java 58 2008-08-03 19:29:15Z dmckain $
 *
 * Copyright (c) 2003 - 2008 University of Edinburgh.
 * All Rights Reserved
 */
package uk.ac.ed.ph.commons.xml;

import uk.ac.ed.ph.commons.util.ObjectUtilities;

import org.xml.sax.Attributes;
import org.xml.sax.ContentHandler;
import org.xml.sax.helpers.AttributesImpl;

/**
 * Trivial wrapper class to store information passed by
 * {@link ContentHandler#startElement(String, String, String, Attributes)}
 * in case it needs to be stored for a while.
 *
 * @author  David McKain
 * @version $Revision: 58 $
 */
public class SAXElementInfo {
    
    private String uri;
    private String localName;
    private String qName;
    private AttributesImpl attr;
    
    public SAXElementInfo() {
    }
    
    /**
     * Records a wrapper for the information passed by
     * {@link ContentHandler#startElement(String, String, String, Attributes)},
     * making a copy of the {@link AttributesImpl} Object since the SAX API allows the Object
     * passed to {@link ContentHandler#startElement(String, String, String, Attributes)} to have
     * transient state;
     * 
     * @param uri
     * @param localName
     * @param qName
     * @param attr
     */
    public SAXElementInfo(String uri, String localName, String qName, Attributes attr) {
        this();
        this.uri = uri;
        this.localName = localName;
        this.qName = qName;
        this.attr = new AttributesImpl(attr);
    }
    
    public String getUri() {
        return this.uri;
    }
    
    public void setUri(String uri) {
        this.uri = uri;
    }
    
    public String getLocalName() {
        return this.localName;
    }
    
    public void setLocalName(String localName) {
        this.localName = localName;
    }
    
    public String getQName() {
        return this.qName;
    }
    
    public void setQName(String name) {
        this.qName = name;
    }
    
    public AttributesImpl getAttr() {
        return this.attr;
    }
    
    public void setAttr(AttributesImpl attr) {
        this.attr = attr;
    }
    
    @Override
    public String toString() {
        return ObjectUtilities.beanToString(this);
    }
}
