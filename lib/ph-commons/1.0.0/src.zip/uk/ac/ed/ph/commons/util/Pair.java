/* $Id: Pair.java 73 2008-08-12 11:15:07Z dmckain $
 *
 * Copyright 2008 University of Edinburgh.
 * All Rights Reserved
 */
package uk.ac.ed.ph.commons.util;

/**
 * Trivial utility class describing a pair/tuple, which can occasionally be
 * useful.
 * 
 * @param <E> type for the first element of the pair
 * @param <F> type for the second element of the pair
 *
 * @author  David McKain
 * @version $Revision: 73 $
 */
public class Pair<E,F> {
    
    private E first;
    private F second;
    
    public Pair() {
        /* Empty constructor */
    }
    
    public Pair(E first, F second) {
        this.first = first;
        this.second = second;
    }

    
    public E getFirst() {
        return first;
    }
    
    public void setFirst(E first) {
        this.first = first;
    }

    
    public F getSecond() {
        return second;
    }
    
    public void setSecond(F second) {
        this.second = second;
    }
}
