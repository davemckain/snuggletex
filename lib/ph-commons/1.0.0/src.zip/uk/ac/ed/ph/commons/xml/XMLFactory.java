/* $Id:XMLFactory.java 2824 2008-08-01 15:46:17Z davemckain $
 *
 * Copyright (c) 2003 - 2008 University of Edinburgh.
 * All Rights Reserved
 */
package uk.ac.ed.ph.commons.xml;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.SAXParser;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.sax.SAXTransformerFactory;
import javax.xml.transform.sax.TransformerHandler;

import org.xml.sax.XMLReader;

/**
 * This factory interface provides easy access to various entry points into the JAXP system.
 * <p>
 * You're probably thinking "factories of factories... bloody hell!". But this abstraction
 * makes it possible to forego the whole JAXP factory-based approach if you want to hard-code
 * your choice of XML parser and XSLT processor into your application by simply creating an
 * instance of this interface which does the required work.
 * <p>
 * This approach also replaces the various checked Exceptions thrown by JAXP into the unchecked
 * {@link JAXPConfigurationException}. Having an unchecked Exception is generally a better option
 * for this kind of thing as this usually indicates some kind of configuration or deployment issue
 * (e.g. ClassPath not set up) that can't really be recovered from.
 * <p>
 * There are also methods for getting at factories having certain common configurations, which
 * makes life a bit easier.
 * <p>
 * A default implementation {@link JAXPDefaultXMLFactory} provides the same functionality that
 * you get when using the usual JAXP factory methods.
 * 
 * @see JAXPDefaultXMLFactory
 *
 * @author  David McKain
 * @version $Revision:2824 $
 */
public interface XMLFactory {
    
    //-------------------------------------------
    // SAX Parsing
    
    /**
     * Creates and returns a new namespace-aware {@link SAXParser}
     * with optional support for validation. The usual rules about the use of such parsers applies.
     * If no such parser can be configured then a fatal error is logged and a
     * {@link JAXPConfigurationException} is thrown.
     *
     * @param wantValidating determines whether the parser should be validating
     *
     * @return SAXParser configured to support namespace processing.
     * @throws JAXPConfigurationException
     *             if a suitable parser cannot be created.
     */
    SAXParser createNSAwareSAXParser(boolean wantValidating);
    
    /**
     * Creates and returns a new namespace-aware {@link XMLReader}
     * with optional support for validation. The usual rules about the use of such readers applies.
     *
     * @param wantValidating determines whether the parser should be validating
     *
     * @return SAXParser configured to support namespace processing.
     * @throws JAXPConfigurationException
     *             if a suitable parser cannot be created.
     */
    XMLReader createNSAwareXMLReader(boolean wantValidating);
    
    /**
     * Creates and returns a new namespace-aware {@link XMLReader}
     * with optional support for validation which is configured to ensure that it
     * supplies the correct type of SAX Events to a {@link TransformerHandler} created
     * by the current result of a {@link #createSAXTransformerFactory()}.
     * <p>
     * The usual rules about the use of such readers applies.
     *
     * @param wantValidating determines whether the parser should be
     *   validating
     *
     * @return SAXParser configured to support namespace processing.
     * @throws JAXPConfigurationException
     *             if a suitable parser cannot be created.
     */
    XMLReader createNSAwareXMLReaderForTransformerHandler(boolean wantValidating);
    
    //-------------------------------------------
    // DOM Parsing/building
    
    /**
     * Creates a new namespace-aware {@link DocumentBuilder}, with optional support for validation.
     *
     * @param wantValidating determines whether the resulting {@link DocumentBuilder} should be
     *   validating
     *
     * @return namespace-aware {@link DocumentBuilder}
     * @throws JAXPConfigurationException if a suitable result cannot be created.
     */
    DocumentBuilder createNSAwareDocumentBuilder(boolean wantValidating);
    
    //-------------------------------------------
    // XSLT

    /**
     * Creates a vanilla {@link TransformerFactory} with no further configuration performed on it.
     * 
     * @throws JAXPConfigurationException if factory could not be instantiated.
     */
    TransformerFactory createTransformerFactory();

    /**
     * Creates a new {@link SAXTransformerFactory} instance and ensures it can support
     * transforms with SAX Sources and SAX Results.
     *
     * @return SAXTransformerFactory which can handle SAXSource and SAXResults.
     *
     * @throws JAXPConfigurationException if no such factory can be created.
     */
    SAXTransformerFactory createSAXTransformerFactory();
    
    /**
     * Creates a new {@link TransformerFactory} instance and ensures it can support
     * transforms with DOM Sources and DOM Results.
     *
     * @return TransformerFactory which can handle SAXSource and SAXResults.
     *
     * @throws JAXPConfigurationException if no such factory can be created.
     */
    TransformerFactory createDOMCompatibleTransformerFactory();
}