/* $Id:SAXErrorHandler.java 2824 2008-08-01 15:46:17Z davemckain $
 *
 * Copyright (c) 2003 - 2007 University of Edinburgh.
 * All Rights Reserved
 */
package uk.ac.ed.ph.commons.xml;

import uk.ac.ed.ph.commons.xml.saxfilters.XMLLexicalFilterImpl;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.xml.sax.ErrorHandler;
import org.xml.sax.SAXException;
import org.xml.sax.SAXParseException;
import org.xml.sax.XMLReader;

/**
 * This is a simple implementation of the SAX {@link ErrorHandler} interface
 * that has a number of convenience features for making error handling
 * a bit easier.
 * <p>
 * This can either be used as a fully-fledged {@link XMLLexicalFilterImpl} or
 * it can simply be used as the {@link ErrorHandler} for an {@link XMLReader}, as
 * described below. (I could have split this into 2 separate classes
 * but it's annoying to implement this!)
 * <p>
 * By default, SAX warnings and errors are recorded but otherwise
 * keep parsing going. SAX fatal errors throw {@link SAXParseException}s
 * (as they should do). You can make errors and/or warnings throw
 * immediate Exceptions using the
 * {@link #setImmediateFailureLevel(int)}.
 * <p>
 * Once parsing has finished, you can retrieve the warnings, errors
 * and (possible) fatal error that was recorded using the
 * {@link #getWarnings()}, {@link #getErrors()} and
 * {@link #getFatalErrors()} methods.
 * <p>
 * Call the {@link #reset()} method to reset the results stored from
 * the previous parse if you want to reuse this handler, or just
 * save a bit of memory.
 *
 * <h2>Used as an XML Filter</h2>
 *
 * As well as the above functionality, when used as an XML filter you
 * can specify that a SAXException should be thrown when the end of
 * document is reached if any errors and/or warnings have been found.
 * Use the {@link #setEndDocumentFailureLevel(int)} to set this. By
 * default, it is set to throw an exception if a fatal error occurred,
 * which will never actually happen since the fatal error would have
 * terminated processing earlier.
 * <p>
 * The {@link #reset()} method will be called automatically when
 * parsing starts.
 *
 * @author  David McKain
 * @version $Revision:2824 $
 */
public class SAXErrorHandler extends XMLLexicalFilterImpl implements ErrorHandler {

    private static final Log log = LogFactory.getLog(SAXErrorHandler.class);

    /** Convenience empty array used in return methods below */
    private static final SAXParseException[] EMPTY_RESULT = new SAXParseException[0];

    /* NB: Numbers below MUST be 0, 1, 2 */
    public static final int WARNING = 0;
    public static final int ERROR   = 1;
    public static final int FATAL   = 2;

    //------------------------------------------------
    // Properties

    /**
     * Indicates the minimum severity level at which parsing will
     * terminate if such an event is found.
     */
    private int immediateFailureLevel;

    /**
     * Indicates the minimum severity level at which the parse
     * will automatically fail at the end of document if any
     * such events are found.
     */
    private int endDocumentFailureLevel;

    //------------------------------------------------
    // State

    /** Set when we've decided we mus fail at endDocument */
    private boolean willFailAtEnd;

    /**
     * List of Lists where exceptions will be accumulated, one
     * List per error level. The outer list will have fixed
     * size and null values at first. The inner lists will
     * be created on-demand.
     */
    private List<List<SAXParseException>> exceptionsByLevel;

    //------------------------------------------------

    /**
     * This simple constructor creates a default ErrorHandler which will fail on
     * any fatal error. If used as a filter, any accrued errors and warnings
     * will NOT cause parsing to fail at the end of the document.
     */
    public SAXErrorHandler() {
        this(FATAL, FATAL);
    }

    /**
     * This constructor creates a SAXErrorHandler with the given immediateFailureLevel
     * and endDocumentFailureLevel.
     *
     * @param immediateFailureLevel
     * @param endDocumentFailureLevel
     */
    public SAXErrorHandler(int immediateFailureLevel, int endDocumentFailureLevel) {
        /* Set up array for storing results */
        ArrayList<List<SAXParseException>> exceptions = new ArrayList<List<SAXParseException>>(FATAL + 1);
        for (int i = 0; i <= FATAL; i++) {
            exceptions.add(null);
        }
        exceptions.trimToSize();
        this.exceptionsByLevel = exceptions;

        /* Initialise failure levels */
        setImmediateFailureLevel(immediateFailureLevel);
        setEndDocumentFailureLevel(endDocumentFailureLevel);
    }

    //------------------------------------------------

    /**
     * Gets the severity level at which parsing will terminate when
     * such an event occurs.
     */
    public int getImmediateFailureLevel() {
        return immediateFailureLevel;
    }

    /**
     * Sets the severity level at which parsing will terminate when
     * such an event occurs.
     * <p>
     * For example, if set to fail at an ERROR then calls to
     * error() and fatalError() will throw SAXParseExceptions.
     *
     * @param level should be one of the constants
     * {@link #WARNING}, {@link #ERROR} or {@link #FATAL}.
     */
    public void setImmediateFailureLevel(int level) {
        if (level < 0 || level > FATAL) {
            throw new IllegalArgumentException("Illegal failure level");
        }
        this.immediateFailureLevel = level;
    }

    /**
     * Gets the level at which any accrued events of that level
     * or greater will cause a SAXException to be thrown at the
     * endDocument event.
     */
    public int getEndDocumentFailureLevel() {
        return endDocumentFailureLevel;
    }

    /**
     * Sets the level at which any accrued events of that level
     * or greater will cause a SAXException to be thrown at the
     * endDocument event.
     */
    public void setEndDocumentFailureLevel(int level) {
        if (level < 0 || level > FATAL) {
            throw new IllegalArgumentException("Illegal failure level");
        }
        this.endDocumentFailureLevel = level;
    }

    //------------------------------------------------

    /**
     * Resets all parsing exceptions gathered by this handler.
     * <p>
     * This is necessary if you plan to reuse the handler; it
     * also allows things to be cleared up if you no longer
     * need the results.
     */
    public void reset() {
        Collections.fill(exceptionsByLevel, null);
        willFailAtEnd = false;
    }

    /**
     * Gets a List of SAXParseExceptions representing any errors, warnings
     * and fatal errors found during parsing.
     * <p>
     * This will only return a meaningful result after a parse and before
     * either the next parse or a call to {@link #reset()}. No recording
     * of this state is made as it's hard to manage so be careful!
     *
     * @return Array of SAXParseExceptions, which may be empty but never
     *   null.
     */
    public SAXParseException[] getParseExceptions(int errorLevel) {
        List<SAXParseException> exceptions = exceptionsByLevel.get(errorLevel);
        if (exceptions!=null) {
            return exceptions.toArray(new SAXParseException [exceptions.size()]);
        }
        return EMPTY_RESULT;
    }

    /**
     * Returns an array of SAX Warnings encountered during the last
     * parse, which may be empty but never null.
     */
    public SAXParseException[] getWarnings() {
        return getParseExceptions(WARNING);
    }

    /**
     * Returns an array of SAX Errors encountered during the last
     * parse, which may be empty but never null.
     */
    public SAXParseException[] getErrors() {
        return getParseExceptions(ERROR);
    }

    /**
     * Returns an array of SAX Fatal Errors encountered during the last
     * parse, which will either have 0 or 1 elements.
     */
    public SAXParseException[] getFatalErrors() {
        return getParseExceptions(FATAL);
    }

    //------------------------------------------------

    @Override
    public void warning(SAXParseException exception) throws SAXParseException {
        log.info("Warning notification " + exception);
        handleException(WARNING, exception);
    }

    @Override
    public void error(SAXParseException exception) throws SAXParseException {
        log.info("Error notification " + exception);
        handleException(ERROR, exception);
    }

    @Override
    public void fatalError(SAXParseException exception) throws SAXException {
        log.info("Fatal Error notification " + exception);
        handleException(FATAL, exception);
        /* NB: This will always throw SAXException */
    }

    //------------------------------------------------

    /**
     * Does the job of deciding what to do with the given Exception
     * and severity level.
     */
    private void handleException(int errorLevel, SAXParseException exception) throws SAXParseException {
        if (log.isDebugEnabled()) {
            log.debug("Registering SAXParseException at severity level " + errorLevel);
        }
        /* Record the error. */
        if (exceptionsByLevel.get(errorLevel)==null) {
            exceptionsByLevel.set(errorLevel, new ArrayList<SAXParseException>());
        }
        exceptionsByLevel.get(errorLevel).add(exception);

        /* Now maybe fail if error is at the appropriate level */
        if (errorLevel >= immediateFailureLevel) {
            if (log.isDebugEnabled()) {
                log.debug("Throwing SAXParseException as its severity is "
                        + errorLevel + " which is at least as high as your "
                        + "selected failure level " + immediateFailureLevel);
            }
            throw exception;
        }
        /* If still here, see if this error will make us fail later */
        if (errorLevel >= endDocumentFailureLevel) {
            if (!willFailAtEnd && log.isDebugEnabled()) {
                log.debug("This parsing event is severe enough to cause parsing to fail "
                        + "once the end of the document has been reached");
            }
            willFailAtEnd = true;
        }
    }

    //------------------------------------------------
    // Filter methods

    /**
     * Overridden to reset any results from a previous parse.
     */
    @Override
    public void startDocument() throws SAXException {
        reset();
        super.startDocument();
    }

    /**
     * Overridden to fail parsing if any errors or warnings are reported
     * during parsing. This makes us ultra-stringent.
     */
    @Override
    public void endDocument() throws SAXException {
        if (willFailAtEnd) {
            if (log.isDebugEnabled()) {
                log.debug("Some SAX errors/warnings were logged during processing; you've asked "
                        + "for parsing to fail now so enjoy!");
            }
            throw new SAXException("Warnings or errors were notified during parsing.");
        }
        super.endDocument();
    }
}
