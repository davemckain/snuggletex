/* $Id: StringUtilities.java 373 2008-11-04 14:32:52Z dmckain $
 *
 * Copyright (c) 2003 - 2008 University of Edinburgh.
 * All Rights Reserved
 */
package uk.ac.ed.ph.commons.util;

import java.util.ArrayList;
import java.util.Iterator;

/**
 * Some vaguely useful String-related methods that are used from
 * time to time.
 * <p>
 * Based on COSMAP StringUtilities v1.4 (which was formerly based
 * on the old ITBase StringUtilities).
 *
 * @author  David McKain
 * @version $Revision: 373 $
 */
public final class StringUtilities {
	
    /** Shared instance of an empty array of Strings, which is sometimes useful! */
	public static final String[] EMPTY_STRING_ARRAY = new String[0];

    /**
     * Joins the given collection of Objects using the given
     * separator and each Object's normal toString() method.
     * <p>
     * For example, joining the collection "a", "b", "c" with "/"
     * gives "a/b/c".
     *
     * @param objects collection of Objects to join
     * @param separator separator to use
     * @return objects joined using the given separator.
     */
    public static String join(final Iterable<? extends Object> objects, final CharSequence separator) {
        StringBuilder result = new StringBuilder();
        for (Iterator<? extends Object> iter = objects.iterator(); iter.hasNext(); ) {
            result.append(iter.next().toString());
            if (iter.hasNext()) {
                result.append(separator);
            }
        }
        return result.toString();
    }

    /**
     * Same as {@link #join(Iterable, CharSequence)} but simply takes an array
     * of Objects.
     *
     * @param objects array of Objects to join
     * @param separator separator to use
     */
    public static String join(final Object[] objects, final CharSequence separator) {
        return join(objects, separator, 0, objects.length);
    }
    
    /**
     * Version of {@link #join(Object[], CharSequence)} that allows you to pass in
     * a {@link StringBuilder} that the result will be built up in. This is useful if you need
     * to do add in other stuff later on.
     *
     * @param resultBuilder StringBuilder to append results to
     * @param objects array of Objects to join
     * @param separator separator to use
     */
    public static void join(final StringBuilder resultBuilder, final Object[] objects, 
    		final CharSequence separator) {
        join(resultBuilder, objects, separator, 0, objects.length);
    }
    
    /**
     * Version of {@link #join(Object[], CharSequence)} that allows you to specify a range of
     * indices in the array to join. This can be useful in some cases.
     *
     * @param objects array of Objects to join
     * @param separator separator to use
     * @param startIndex first index to join
     * @param endIndex index after last one to join
     */
    public static String join(final Object[] objects, final CharSequence separator,
    		final int startIndex, final int endIndex) {
        StringBuilder result = new StringBuilder();
        join(result, objects, separator, startIndex, endIndex);
        return result.toString();
    }
    
    /**
     * Version of {@link #join(Object[], CharSequence, int, int)} that allows you to pass in
     * a {@link StringBuilder} that the result will be built up in. This is useful if you need
     * to do add in other stuff later on.
     *
     * @param resultBuilder StringBuilder to append results to
     * @param objects array of Objects to join
     * @param separator separator to use
     * @param startIndex first index to join
     * @param endIndex index after last one to join
     */
    public static void join(final StringBuilder resultBuilder, final Object[] objects,
    		final CharSequence separator, final int startIndex, final int endIndex) {
        boolean hasDoneFirst = false;
        for (int i=startIndex; i<endIndex; i++) {
            if (hasDoneFirst) {
                resultBuilder.append(separator);
            }
            resultBuilder.append(objects[i].toString());
            hasDoneFirst = true;
        }
    }
    
    //------------------------------------------------------------------------
    
    /**
     * Tests whether the given String is null or empty ("").
     */
    public static boolean isNullOrEmpty(final String string) {
        return string==null || string.length()==0;
    }

    /**
     * Convenience method that turns a String to null if it is empty (i.e. "") or null.
     *
     * @param string
     * @return same string if it is non-null and non-empty, otherwise null.
     */
    public static String nullIfEmpty(final String string) {
        return isNullOrEmpty(string) ? null : string;
    }

    /**
     * Convenience method that turns a String to an empty String ("") if it is null.
     *
     * @param string
     * @return same string if it is non-empty, otherwise null.
     */
    public static String emptyIfNull(final String string) {
        return string!=null ? string : "";
    }
    
    //------------------------------------------------------------------------

    /**
     * Trivial helper method to convert a boolean into either
     * "yes" or "no" depending on its state.
     *
     * @param state boolean to convert
     * @return "yes" if true, "no" if false.
     */
    public static String toYesNo(final boolean state) {
        return state ? "yes" : "no";
    }
    
    /**
     * Trivial helper method to convert a boolean into either
     * "true" or "false" depending on its state.
     *
     * @param state boolean to convert
     * @return "true" if true, "false" if false.
     */
    public static String toTrueFalse(final boolean state) {
        return state ? "true" : "false";
    }

    /**
     * Converts the given String argument to a boolean using
     * the scheme "yes"=>true, "no"=>false. Any other value
     * results in an IllegalArgumentException.
     *
     * @param value
     * @return true if "yes", false if "no"
     *
     * @throws IllegalArgumentException if value if null or
     *   neither "yes" or "no"
     */
    public static boolean fromYesNo(final String value) {
    	return fromBinaryValues(value, "yes", "no");
    }

    /**
     * Converts the given String argument to a boolean using
     * the scheme "true"=>true, "false"=>false. Any other value
     * results in an IllegalArgumentException.
     *
     * @param value
     * @return true if "yes", false if "no"
     *
     * @throws IllegalArgumentException if value if null or
     *   neither "yes" or "no"
     */
    public static boolean fromTrueFalse(final String value) {
    	return fromBinaryValues(value, "true", "false");
    }
    
    /**
     * Converts the given String argument to a boolean using
     * the scheme trueValue => true, falseValue => false.
     * Any other value results in an IllegalArgumentException.
     *
     * @param value
     * @param trueValue value returning true
     * @param falseValue value returning false
     *
     * @throws IllegalArgumentException if value if null or
     *   neither trueValue nor falseValue
     */
    public static boolean fromBinaryValues(final String value,
    		final String trueValue, final String falseValue) {
        if (value!=null) {
            if (value.equals(trueValue)) {
                return true;
            }
            else if (value.equals(falseValue)) {
                return false;
            }
        }
        throw new IllegalArgumentException("Argument must be "
        		+ trueValue + " or " + falseValue);
    }    
    //------------------------------------------------------------------------
    
    /**
     * Utility method for relativising one "path" against another, using the given path separator
     * and "go up one step" tokens.
     * <p>
     * It is assumed that that paths will already have been split into arrays of components
     * and that the components contain suitably legal characters in them.
     * <p>
     * <h3>Example</h3>
     * 
     * Using the usual Unix path separators, then <tt>a/b/c/d</tt> against base <tt>a/b/e/f</tt>
     * would be <tt>../c/d</tt> since we need to go up one from the <tt>f</tt> and then down
     * the <tt>c</tt> and <tt>d</tt>.
     */
    public static String relativisePaths(final String[] thisPathComponents,
    		final String[] basePathComponents,
            final String pathSeparator, final String upPathToken) {
        /* In general, we find the last match between the underlying path
         * components. Then need a .. for all remaining components of the base path
         * followed by the rest of the current path.
         */
        int lastMatch = 0;
        boolean isAfterLastMatch = false;
        ArrayList<String> result = new ArrayList<String>();
        for (int i = 0; i < basePathComponents.length - 1; i++) {
            if (!isAfterLastMatch && i < thisPathComponents.length && thisPathComponents[i] != null
                    && basePathComponents[i].equals(thisPathComponents[i])) {
                lastMatch++;
            }
            else {
                /*
                 * After last match so add component for each extra bit of first
                 * path
                 */
                isAfterLastMatch = true;
                result.add(upPathToken);
            }
        }
        /* (Add left over bits from this path) */
        for (int i=lastMatch; i<thisPathComponents.length; i++) {
            result.add(thisPathComponents[i]);
        }
        return join(result, pathSeparator);
    }
    
    /**
     * Convenience version of {@link #relativisePaths(String[], String[], String, String)}
     * that takes raw path String as arguments, splitting them against the given path separator to
     * form components before calling {@link #relativisePaths(String[], String[], String, String)}
     * as normal.
     */
    public static String relativisePaths(final String thisPath, final String basePath,
    		final String pathSeparator, String upPathToken) {
        String pathSplitRegexp = "\\Q" + pathSeparator;
        return relativisePaths(thisPath.split(pathSplitRegexp), basePath.split(pathSplitRegexp),
                pathSeparator, upPathToken);
    }
}
