/* $Id: SAXFeatures.java 58 2008-08-03 19:29:15Z dmckain $
 *
 * Copyright (c) 2003 - 2008 University of Edinburgh.
 * All Rights Reserved
 */
package uk.ac.ed.ph.commons.xml;

/**
 * Convenience enumeration of relevant SAX Features. This saves having
 * to mess about with full names, which is often error-prone.
 *
 * @author  David McKain
 * @version $Revision: 58 $
 */
public interface SAXFeatures {

    /** Base part of the "url" used to represent various SAX Features */
    public static final String FEATURE_BASE = "http://xml.org/sax/features/";

    /** SAX "namespaces" feature */
    public static final String NAMESPACES = FEATURE_BASE + "namespaces";

    /** SAX "namespace-prefixes" feature */
    public static final String NAMESPACE_PREFIXES = FEATURE_BASE + "namespace-prefixes";

    /** SAX "xmlns-uris" feature */
    public static final String XMLNS_URIS = FEATURE_BASE + "xmlns-uris";
}
