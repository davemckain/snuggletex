/* $Id: XMLUtilities.java 58 2008-08-03 19:29:15Z dmckain $
 *
 * Copyright (c) 2003 - 2008 University of Edinburgh.
 * All Rights Reserved
 */
package uk.ac.ed.ph.commons.xml;

import java.io.StringReader;

import javax.xml.transform.TransformerFactory;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.xml.sax.Attributes;
import org.xml.sax.EntityResolver;
import org.xml.sax.InputSource;
import org.xml.sax.helpers.AttributesImpl;

/**
 * A collection of simple but useful XML-related helpers and constants.
 *
 * @author David McKain
 * @version $Revision: 58 $
 */
public final class XMLUtilities {

    private static final Log log = LogFactory.getLog(XMLUtilities.class);
    
    /** Name of the System property that determines which XSLT TransformerFactory to use */
    public static final String TRANSFORMER_FACTORY_PROPERTY = "javax.xml.transform.TransformerFactory";

    /** Name of the System property that determines which SAX Parser Factory to use */
    public static final String SAX_PARSER_FACTORY_PROPERTY = "javax.xml.parsers.SAXParserFactory";
    
    /**
     * Ensures that the given {@link TransformerFactory} has the required feature.
     * 
     * @param transformerFactory TransformerFactory to check
     * @param featureName required feature
     * 
     * @throws JAXPConfigurationException if the factory does not support the required feature.
     */
    public static void requireFeature(TransformerFactory transformerFactory, String featureName) {
        if (!transformerFactory.getFeature(featureName)) {
            String errorMessage = "TransformerFactory" + transformerFactory.getClass().getName()
                + " does not support the required feature " + featureName;
            log.fatal(errorMessage);
            throw new JAXPConfigurationException(errorMessage);
        }
    }

    //-----------------------------------------------------------

    /**
     * Handy implementation of {@link EntityResolver} which returns nothing, as if the
     * DTD declaration has been omitted.
     * <p>
     * This is Thread-safe so can be shared as much as needed.
     */
    public static final EntityResolver DO_NOTHING_ENTITY_RESOLVER = new EntityResolver() {
        public InputSource resolveEntity(String publicId, String systemId) {
            InputSource result = new InputSource(new StringReader(""));
            result.setPublicId(publicId);
            result.setSystemId(systemId);
            return result;
        }
    };
    
    /**
     * Handy <tt>read-only</tt> empty Attributes object.
     * <p>
     * This is Thread-safe so can be shared as much as needed.
     */
    public static final AttributesImpl EMPTY_ATTRIBUTES = new AttributesImpl() {
        @Override
        public void addAttribute(String uri,String localName,String qName,String type,String value) {
            throw new UnsupportedOperationException("Empty Attributes list is read-only");
        }
    };
    
    /**
     * Occasionally useful convenience method that performs a sensible "toString()" on an
     * {@link Attributes} list.
     * 
     * @param attrs
     */
    public static String attributesToString(Attributes attrs) {
        StringBuilder result = new StringBuilder("[");
        for (int i=0, size=attrs.getLength(); i<size; i++) {
            if (i>0) {
                result.append(",");
            }
            result.append(attrs.getLocalName(i)).append("=").append(attrs.getValue(i));
        }
        result.append("]");
        return result.toString();
    }
}