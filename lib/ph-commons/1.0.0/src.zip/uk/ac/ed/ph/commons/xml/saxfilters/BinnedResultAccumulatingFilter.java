/* $Id:BinnedResultAccumulatingFilter.java 2824 2008-08-01 15:46:17Z davemckain $
 *
 * Copyright (c) 2003 - 2008 University of Edinburgh.
 * All Rights Reserved
 */
package uk.ac.ed.ph.commons.xml.saxfilters;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.xml.sax.SAXException;

/**
 * Version of {@link ResultAccumulatingFilter} that stores results in different "bins".
 * This can be useful for building up disparate {@link List}s of results over the space
 * of one parse, e.g. building totals for elements with different names.
 *
 * @param <B> type of bin to use
 * @param <E> type of result to store in each bin.
 *
 * @see uk.ac.ed.ph.commons.xml.saxfilters.ResultAccumulatingFilter
 *
 * @author  David McKain
 * @version $Revision:2824 $
 */
public abstract class BinnedResultAccumulatingFilter<B,E> extends XMLLexicalFilterImpl {

    private static final Log log = LogFactory.getLog(BinnedResultAccumulatingFilter.class);

    /** Set of bins to store results in */
    private final Set<B> bins;

    /** Flag to indicate whether new bins can be created dynamically or not */
    private boolean allowsNewBins;

    /** List of Strings found during parsing */
    private Map<B,List<E>> results;

    //----------------------------------------------------------

    /**
     * Default constructor creates a filter with no pre-registered Bins that
     * allows new Bins to be added as required.
     */
    public BinnedResultAccumulatingFilter() {
        this(new HashSet<B>(), true);
    }

    /**
     * This constructor creates a filter with the given initial set of Bins
     * and accepts new bins iff the <code>allowsNewBins</code> flag is true.
     *
     * @param bins
     * @param allowsNewBins
     */
    public BinnedResultAccumulatingFilter(Set<B> bins, boolean allowsNewBins) {
        if (bins==null) {
            throw new IllegalArgumentException("Bins must not be null");
        }
        if (bins.contains(null)) {
            throw new IllegalArgumentException("All bins must be non-null");
        }
        this.bins = bins;
        this.allowsNewBins = allowsNewBins;
    }

    /**
     * Returns whether new Bins can be created dynamically.
     */
    public boolean getAllowsNewBins() {
        return allowsNewBins;
    }

    /**
     * Sets whether new Bins can be created dynamically.
     */
    public void setAllowsNewBins(boolean allowsNewBins) {
        this.allowsNewBins = allowsNewBins;
    }

    /**
     * Checks whether the given Bin has been registered.
     *
     * @param bin
     * @return true if bin has been registered, false otherwise.
     */
    public boolean containsBin(B bin) {
        return bins.contains(bin);
    }

    //----------------------------------------------------------

    /**
     * Clears up the results built up during the last parse,
     * allowing things to be garbage collected.
     */
    public void reset() {
        this.results = null;
    }

    /**
     * Registers the given bin, allowing results to be stored in it. This will
     * only be allowed if {@link #allowsNewBins} is true.
     *
     * @param bin bin to register
     *
     * @throws IllegalStateException if new bins are not allowed
     * @throws IllegalArgumentException if the given bin is already registered.
     */
    public void addBin(B bin) {
        checkBin(bin);
        if (results.containsKey(bin)) {
            throw new IllegalArgumentException("Bin " + bin + " has already been registered");
        }
        if (!allowsNewBins) {
            throw new IllegalStateException("New bins are not allowed");
        }
        setupBin(bin);
    }

    /**
     * Retrieves the List of results for this parse for the bin of
     * the given type. The List may be empty if nothing has been stored
     * for the given bin.
     * <p>
     * If the bin has not yet been registered then null is returned.
     *
     * @return List containing the results stored in the given bin
     *   during parsing, null if parsing has not yet started or if
     *   the bin has not been registered.
     */
    public List<E> getResults(B bin) {
        checkBin(bin);
        if (results==null) {
            /* Not started parsing yet */
            return null;
        }
        return results.get(bin);
    }

    //----------------------------------------------------------

    /**
     * Overridden to create new List of results at the start of parsing.
     */
    @Override
    public void startDocument() throws SAXException {
        reset();
        setupResults();
        super.startDocument();
    }

    /**
     * Adds the given result to the given bin. If the binType has not yet
     * been used, a new one is created.
     */
    protected final void addResult(B bin, E result) {
        checkBin(bin);
        if (log.isDebugEnabled()) {
            log.debug("Recording result " + result + " in bin " + bin);
        }
        getResults(bin).add(result);
    }

    //----------------------------------------------------------

    /**
     * Internal method to set up the results object. This is called at the
     * start of parsing.
     */
    private void setupResults() {
        results = new HashMap<B,List<E>>();
        for (B bin : bins) {
            setupBin(bin);
        }
    }

    /**
     * Internal method to set up storage space for the given Bin bin in the
     * results object. The results object must already exist.
     *
     * @param bin
     */
    private void setupBin(B bin) {
        results.put(bin, new ArrayList<E>());
    }

    /**
     * Internal method to ensure that a given Bin is not null.
     *
     * @param bin
     */
    private void checkBin(B bin) {
        if (bin==null) {
            throw new IllegalArgumentException("Bin cannot be null");
        }
    }
}
