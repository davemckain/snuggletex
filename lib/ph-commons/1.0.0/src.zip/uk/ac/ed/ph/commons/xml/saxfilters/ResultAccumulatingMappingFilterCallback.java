/* $Id:ResultAccumulatingMappingFilterCallback.java 2824 2008-08-01 15:46:17Z davemckain $
 *
 * Copyright (c) 2003 - 2008 University of Edinburgh.
 * All Rights Reserved
 */
package uk.ac.ed.ph.commons.xml.saxfilters;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * Useful partial implementation of {@link MappingFilterCallback} that provides a mechanism for
 * optionally recording each matched Node.
 *
 * @param <E> type of result that will be accumulated.
 *
 * @author  David McKain
 * @version $Revision:2824 $
 */
public abstract class ResultAccumulatingMappingFilterCallback<E> implements MappingFilterCallback {

    private static final Log log = LogFactory.getLog(ResultAccumulatingFilter.class);

    /** List of Objects found during parsing */
    private List<E> results;
    
    /** Whether to accumulate results or not */
    private boolean accumulatingResults;
    
    /**
     * Creates a new callback, configured to record results registered with
     * {@link #maybeAddResult(Object)}
     */
    public ResultAccumulatingMappingFilterCallback() {
        this.accumulatingResults = true;
    }
    
    public boolean isAccumulatingResults() {
        return this.accumulatingResults;
    }
    
    public void setAccumulatingResults(boolean accumulatingResults) {
        this.accumulatingResults = accumulatingResults;
    }

    //----------------------------------------------------------

    /**
     * Clears up the results built up during the last parse,
     * allowing things to be garbage collected.
     */
    public void reset() {
        this.results = null;
    }
    
    /**
     * Initialises state before the beginning of parsing. This is called automatically
     * by {@link #onStartDocument()} but is available to subclasses in case they want to
     * do anything strange.
     */
    protected void init() {
        this.results = new ArrayList<E>();
    }

    /**
     * Retrieves the List of results for this parse. It will be
     * a List of the type E you want to accumulate.
     */
    public List<E> getResults() {
        return results;
    }

    //----------------------------------------------------------
    
    /**
     * Overridden to create new List of results at the start of parsing.
     */
    public void onStartDocument() {
        init();
    }
    
    public void onEndDocument() {
    }
    
    //----------------------------------------------------------

    /**
     * Adds the given result to the List of results if {@link #accumulatingResults} is true.
     *
     * @param result result to add to List
     */
    protected final void maybeAddResult(E result) {
        if (accumulatingResults) {
            if (log.isDebugEnabled()) {
                log.debug("Recording result " + result);
            }
            results.add(result);
        }
    }
}
