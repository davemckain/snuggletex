/* $Id: XSLTErrorListener.java 58 2008-08-03 19:29:15Z dmckain $
 *
 * Copyright (c) 2003 - 2008 University of Edinburgh.
 * All Rights Reserved
 */
package uk.ac.ed.ph.commons.xml;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import javax.xml.transform.ErrorListener;
import javax.xml.transform.TransformerException;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * This is an implementation of the TrAX {@link ErrorListener}
 * interface that behaves in a similar way to {@link SAXErrorHandler},
 * except that it does not support "end document failure" concepts.
 *
 * @author  David McKain
 * @version $Revision: 58 $
 */
public class XSLTErrorListener implements ErrorListener {

    private static final Log log = LogFactory.getLog(XSLTErrorListener.class);

    /** Convenience empty array used in return methods below */
    private static final TransformerException[] EMPTY_RESULT = new TransformerException[0];

    /* NB: Numbers below MUST be 0, 1, 2 */
    public static final int WARNING = 0;
    public static final int ERROR   = 1;
    public static final int FATAL   = 2;

    //------------------------------------------------
    // Properties

    /**
     * Indicates the minimum severity level at which transforming will
     * terminate if such an event is found.
     */
    private int immediateFailureLevel;

    //------------------------------------------------
    // State

    /**
     * List of Lists where exceptions will be accumulated, one
     * List per error level. The outer list will have fixed
     * size and null values at first. The inner lists will
     * be created on-demand.
     */
    private List<List<TransformerException>> exceptionsByLevel;

    //------------------------------------------------

    /**
     * This simple constructor creates a default ErrorHandler which will fail on
     * any fatal error. If used as a filter, any accrued errors and warnings
     * will NOT cause parsing to fail at the end of the document.
     */
    public XSLTErrorListener() {
        this(FATAL);
    }

    /**
     * This constructor creates a {@link XSLTErrorListener} with the given immediateFailureLevel.
     *
     * @param immediateFailureLevel
     */
    public XSLTErrorListener(int immediateFailureLevel) {
        /* Set up array for storing results */
        ArrayList<List<TransformerException>> exceptions = new ArrayList<List<TransformerException>>(FATAL + 1);
        for (int i = 0; i <= FATAL; i++) {
            exceptions.add(null);
        }
        exceptions.trimToSize();
        this.exceptionsByLevel = exceptions;

        /* Initialise failure levels */
        setImmediateFailureLevel(immediateFailureLevel);
    }

    //------------------------------------------------

    /**
     * Gets the severity level at which parsing will terminate when
     * such an event occurs.
     */
    public int getImmediateFailureLevel() {
        return immediateFailureLevel;
    }

    /**
     * Sets the severity level at which parsing will terminate when
     * such an event occurs.
     * <p>
     * For example, if set to fail at an ERROR then calls to
     * error() and fatalError() will throw TransformerExceptions.
     *
     * @param level should be one of the constants
     * {@link #WARNING}, {@link #ERROR} or {@link #FATAL}.
     */
    public void setImmediateFailureLevel(int level) {
        if (level < 0 || level > FATAL) {
            throw new IllegalArgumentException("Illegal failure level");
        }
        this.immediateFailureLevel = level;
    }

    //------------------------------------------------

    /**
     * Resets all parsing exceptions gathered by this handler.
     * <p>
     * This is necessary if you plan to reuse the handler; it
     * also allows things to be cleared up if you no longer
     * need the results.
     */
    public void reset() {
        Collections.fill(exceptionsByLevel, null);
    }

    /**
     * Gets a List of TransformerExceptions representing any errors, warnings
     * and fatal errors found during parsing.
     * <p>
     * This will only return a meaningful result after a parse and before
     * either the next parse or a call to {@link #reset()}. No recording
     * of this state is made as it's hard to manage so be careful!
     *
     * @return Array of TransformerExceptions, which may be empty but never
     *   null.
     */
    public TransformerException[] getParseExceptions(int errorLevel) {
        List<TransformerException> exceptions = exceptionsByLevel.get(errorLevel);
        if (exceptions!=null) {
            return exceptions.toArray(new TransformerException [exceptions.size()]);
        }
        return EMPTY_RESULT;
    }

    /**
     * Returns an array of SAX Warnings encountered during the last
     * parse, which may be empty but never null.
     */
    public TransformerException[] getWarnings() {
        return getParseExceptions(WARNING);
    }

    /**
     * Returns an array of SAX Errors encountered during the last
     * parse, which may be empty but never null.
     */
    public TransformerException[] getErrors() {
        return getParseExceptions(ERROR);
    }

    /**
     * Returns an array of SAX Fatal Errors encountered during the last
     * parse, which will either have 0 or 1 elements.
     */
    public TransformerException[] getFatalErrors() {
        return getParseExceptions(FATAL);
    }

    //------------------------------------------------

    public void warning(TransformerException exception) throws TransformerException {
        logEvent("Warning", exception);
        handleException(WARNING, exception);
    }

    public void error(TransformerException exception) throws TransformerException {
        logEvent("Error", exception);
        handleException(ERROR, exception);
    }

    public void fatalError(TransformerException exception) throws TransformerException {
        logEvent("Fatal Error", exception);
        handleException(FATAL, exception);
        /* NB: This will always throw TransformerException */
    }

    private void logEvent(String severity, TransformerException exception) {
        log.info(severity + " notification: " + exception.getMessageAndLocation());
    }

    //------------------------------------------------

    /**
     * Does the job of deciding what to do with the given Exception
     * and severity level.
     */
    private void handleException(int errorLevel, TransformerException exception)
            throws TransformerException {
        if (log.isDebugEnabled()) {
            log.debug("Registering TransformerException at severity level " + errorLevel);
        }
        /* Record the error. */
        if (exceptionsByLevel.get(errorLevel)==null) {
            exceptionsByLevel.set(errorLevel, new ArrayList<TransformerException>());
        }
        exceptionsByLevel.get(errorLevel).add(exception);

        /* Now maybe fail if error is at the appropriate level */
        if (errorLevel >= immediateFailureLevel) {
            if (log.isDebugEnabled()) {
                log.debug("Throwing TransformerException as its severity is "
                        + errorLevel + " which is at least as high as your "
                        + "selected failure level " + immediateFailureLevel);
            }
            throw exception;
        }
    }
}
