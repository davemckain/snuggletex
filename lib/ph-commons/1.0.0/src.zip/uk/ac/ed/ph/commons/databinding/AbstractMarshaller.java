/* $Id:AbstractMarshaller.java 2824 2008-08-01 15:46:17Z davemckain $
 *
 * Copyright (c) 2003 - 2008 University of Edinburgh.
 * All Rights Reserved
 */
package uk.ac.ed.ph.commons.databinding;

import uk.ac.ed.ph.commons.util.StrategyFactory;
import uk.ac.ed.ph.commons.util.StrategyFactoryConfiguration;
import uk.ac.ed.ph.commons.xml.SAXErrorHandler;
import uk.ac.ed.ph.commons.xml.XMLFactory;
import uk.ac.ed.ph.commons.xml.XMLPipeline;
import uk.ac.ed.ph.commons.xml.XMLUtilities;
import uk.ac.ed.ph.commons.xml.saxfilters.IllegalXMLCharacterFilter;

import java.io.Closeable;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.StringReader;
import java.io.StringWriter;
import java.util.Map;

import javax.xml.parsers.SAXParser;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Result;
import javax.xml.transform.Transformer;
import javax.xml.transform.sax.TransformerHandler;
import javax.xml.transform.stream.StreamResult;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.xml.sax.ContentHandler;
import org.xml.sax.EntityResolver;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
import org.xml.sax.XMLReader;

/**
 * This is a very simple but reusable Object <-> XML marshalling class.
 * <p>
 * It has intentionally been created as an abstract class as it needs
 * to be "configured" in order to tell it how to read/write Objects
 * of certain types and this is done at compile time rather than by
 * XML configuration files.
 *
 * <h2>Usage Notes</h2>
 * 
 * Previous versions (when in  Aardvark up to 0.13.6) of this class cached
 * reader/writer strategies which meant that instances of this class
 * would not be thread-safe. It also meant that we could not do re-entrant
 * things like read/write composites like <tt>A -> A</tt> or <tt>A -> B -> A</tt>
 * (where <tt>-></tt> denotes "embeds") as the strategies for reading and writing
 * are stateful.
 * <p>
 * As of Aardvark 0.13.7, reader and writer strategies are instantiated on demand
 * and used once only. An instance of this class is therefore thread-safe if and only
 * if all of its bean properties (currently just {@link #getEntityResolver()} are.
 *
 * @author  David McKain
 * @version $Revision:2824 $
 */
public abstract class AbstractMarshaller {

    private static final Log log = LogFactory.getLog(AbstractMarshaller.class);
    
    /** {@link XMLFactory} used to instantiate SAX/XSLT classes */
    private final XMLFactory xmlFactory;

    /** Strategy Factory creating Classes for writing Objects to XML, keyed on class Name */
    @SuppressWarnings("unchecked")
    private final StrategyFactory<String, ObjectWriterStrategy> writerStrategyFactory;

    /** Strategy Factory creating Classes for reading Objects from XML, keyed on class Name  */
    @SuppressWarnings("unchecked")
    private final StrategyFactory<String, ObjectReaderStrategy> readerStrategyFactory;
    
    /** Shared instance of {@link IllegalXMLCharacterFilter} for writing out XML */
    private final IllegalXMLCharacterFilter illegalCharacterFilter;

    /** EntityResolver to use when reading in XML */
    private EntityResolver entityResolver;

    /**
     * This constructor creates a AbstractMarshaller that uses the given set of writer and reader
     * classes to do its work.
     * <p>
     * Subclasses should call this in their constructors in order to set things
     * up as they require.
     *
     * @param writerClasses
     * @param readerClasses
     */
    @SuppressWarnings("unchecked")
    public AbstractMarshaller(XMLFactory xmlFactory,
            StrategyFactoryConfiguration<String, ObjectWriterStrategy> writerClasses,
            StrategyFactoryConfiguration<String, ObjectReaderStrategy> readerClasses) {
        /* Create factories, with no caching of strategies */
        this.xmlFactory = xmlFactory;
        this.writerStrategyFactory = new StrategyFactory<String, ObjectWriterStrategy>(writerClasses, false);
        this.readerStrategyFactory = new StrategyFactory<String, ObjectReaderStrategy>(readerClasses, false);
        this.illegalCharacterFilter = new IllegalXMLCharacterFilter();
    }

    //--------------------------------------------------
    
    /**
     * Returns the {@link XMLFactory} used to create this Marshaller.
     */
    public XMLFactory getXMLFactory() {
        return this.xmlFactory;
    }
    
    /**
     * Returns the EntityResolver used to resolve any XML entities when
     * reading from XML.
     *
     * @return Returns the entityResolver.
     */
    public EntityResolver getEntityResolver() {
        return entityResolver;
    }

    /**
     * Sets the EntityResolver used to resolve any XML entities when
     * reading from XML.
     *
     * @param entityResolver The entityResolver to set.
     */
    public void setEntityResolver(EntityResolver entityResolver) {
        this.entityResolver = entityResolver;
    }

    //--------------------------------------------------
    // Reading Objects from XML a.k.a. Parsing

    /**
     * Reads the given Object <code>object</code> using the XML contained
     * in the String <code>xmlString</code>.
     * <p>
     * The mandatory <code>options</code> Object decides how much DTD loading and
     * validation should be performed.
     * 
     * @throws DataBindingException
     */
    public void readObject(Object object, String xmlString, ReaderOptions options) {
        readObject(object, new InputSource(new StringReader(xmlString)), options);
    }

    /**
     * Reads the given Object <code>object</code> using the XML read in from the given
     * {@link InputStream} <code>inputStream</code>. The stream is closed after reading.
     * <p>
     * The mandatory <code>options</code> Object decides how much DTD loading and
     * validation should be performed.
     * 
     * @throws DataBindingException
     */
    public void readObject(Object object, InputStream inputStream, ReaderOptions options) {
        try {
            readObject(object, new InputSource(inputStream), options);
        }
        finally {
            ensureCloseStream(inputStream);
        }
    }

    /**
     * Reads the given Object <code>object</code> using the XML read in from the given
     * {@link InputSource} <code>xmlSource</code>.
     * <p>
     * The mandatory <code>options</code> Object decides how much DTD loading and
     * validation should be performed.
     * 
     * @throws DataBindingException
     */
    public <E> void readObject(E object, InputSource xmlSource, ReaderOptions options) {
        /* Get an XML Reader */
        SAXParser parser = xmlFactory.createNSAwareSAXParser(options==ReaderOptions.READ_DTD_AND_VALIDATE);
        XMLReader reader;
        try {
            reader = parser.getXMLReader();
        }
        catch (SAXException e) {
            log.error("Could not get at XMLReader", e);
            throw new DataBindingException(e);
        }
        /* Be extremely strict about parsing errors */
        SAXErrorHandler errorHandler = new SAXErrorHandler();
        errorHandler.setImmediateFailureLevel(SAXErrorHandler.WARNING);
        reader.setErrorHandler(errorHandler);

        /* Set up EntityResolver if we are reading DTD, otherwise suppress DTD reading
         * by using a fake EntityResolver
         */
        EntityResolver resolver = (options==ReaderOptions.DO_NOT_READ_DTD) ?
                XMLUtilities.DO_NOTHING_ENTITY_RESOLVER : entityResolver;
        reader.setEntityResolver(resolver);

        /* Get class who'll handle the incoming SAX Events and set it up */
        ObjectReaderStrategy<E> readerStrategy = getObjectReaderStrategy(object);
        readerStrategy.init();

        /* That's us ready to go! */
        if (log.isDebugEnabled()) {
            log.debug("Reading Object of class " + object.getClass()
                    + " using strategy " + readerStrategy
                    + " and entity resolver " + resolver
                    + "; validating=" + parser.isValidating());
        }

        /* Now fire SAX Events at it */
        reader.setContentHandler(readerStrategy);
        try {
            reader.parse(xmlSource);
        }
        catch (Exception e) {
            throw new DataBindingException(e);
        }
        finally {
            readerStrategy.reset();
        }
    }

    /**
     * Returns an ObjectReaderStrategy configured to build up the given Object
     * object from incoming SAX Events, reusing any previously strategy created
     * by this Marshaller for this type of object.
     * <p>
     * The strategy must not be used by two Threads at once and is still "owned"
     * by the Marshaller object that created it.
     *
     * @param object
     * 
     * @throws DataBindingException
     */
    @SuppressWarnings("unchecked")
    <E> ObjectReaderStrategy<E> getObjectReaderStrategy(E object) {
        ObjectReaderStrategy<E> readerStrategy = readerStrategyFactory.getStrategy(object.getClass().getName());
        if (readerStrategy==null) {
            throw new DataBindingException("AbstractMarshaller doesn't know how to read objects of Class "
                    + object.getClass());
        }
        readerStrategy.setMarshaller(this);
        readerStrategy.setResult(object);
        return readerStrategy;
    }

    //--------------------------------------------------
    // Writing Objects as XML a.k.a. Serialization
    
    /**
     * Serializes the given Object as an XML document, fired as a series of SAX Events.
     * <p>
     * The caller should ensure that the Object is in a consistent (e.g. valid) state -
     * if appropriate - before calling this method.
     * <p>
     * Note that XML character data here MAY contain illegal Unicode characters; add a 
     * {@link IllegalXMLCharacterFilter} filter manually if you want to fix this.
     * 
     * @param object Object to serialize
     * @param contentHandler SAX ContentHandler to receive the incoming XML events.
     * 
     * @see #embedObject(Object, ContentHandler)
     * 
     * @throws DataBindingException if any error occurs during the serialization
     *   process.
     */
    public <E> void writeObject(E object, ContentHandler contentHandler) {
        /* Get the appropriate generator class */
        ObjectWriterStrategy<E> writer = getObjectWriterStrategy(object);
        if (log.isDebugEnabled()) {
            log.debug("Writing object " + object
                    + " to ContentHandler " + contentHandler
                    + " using strategy " + writer);
        }
        try {
            writer.generateDocument(object, contentHandler);
        }
        catch (SAXException e) {
            throw new DataBindingException("Could not write Object " + object, e);
        }
        finally {
            writer.reset();
        }
    }
    
    public <E> void embedObject(E object, ContentHandler contentHandler) {
        embedObject(object, contentHandler, null);
    }
        
    public <E> void embedObject(E object, ContentHandler contentHandler, Map<String,String> inscopeNamespaceMappings) {
        /* Get the appropriate generator class */
        ObjectWriterStrategy<E> writer = getObjectWriterStrategy(object);
        if (log.isDebugEnabled()) {
            log.debug("Embedding object " + object
                    + " in midstream ContentHandler " + contentHandler
                    + " using strategy " + writer
                    + " and current prefix mapping scope " + inscopeNamespaceMappings);
        }
        try {
            writer.generateFragment(object, contentHandler, inscopeNamespaceMappings);
        }
        catch (SAXException e) {
            throw new DataBindingException("Could not embed Object " + object, e);
        }
        finally {
            writer.reset();
        }
    }
    
    /**
     * Fires the given Object at the given XML Pipeline.
     * <p>
     * This is a convenience method that pulls out the first {@link ContentHandler}
     * from the pipeline and then calls {@link #writeObject(Object, ContentHandler)} on that.
     * <p>
     * The caller should ensure that the Object is in a consistent (e.g. valid) state -
     * if appropriate - before calling this method.
     *
     * @throws DataBindingException if any error occurs during the serialization
     *   process.
     */
    public <E> void writeObject(E object, XMLPipeline pipeline) {
        writeObject(object, pipeline.getStep(0));
    }

    /**
     * Serializes the given Object into a UTF-8 encoded XML character Stream,
     * created from the given {@link OutputStream}. The stream will be closed afterwards.
     * <p>
     * The caller should ensure that the Object is in a consistent (e.g. valid) state -
     * if appropriate - before calling this method.
     * <p>
     * This uses a {@link IllegalXMLCharacterFilter} to filter out any bad Unicode characters
     * in the Object data.
     *
     * @throws DataBindingException if any error occurs during the serialization
     *   process.
     */
    public <E> void writeObject(E object, OutputStream outputStream) {
        try {
            writeObject(object, new StreamResult(outputStream));
        }
        finally {
            ensureCloseStream(outputStream);
        }
    }


    /**
     * Serializes the given Object into a (UTF-8 encoded) SAX Result.
     * <p>
     * The caller should ensure that the Object is in a consistent (e.g. valid) state -
     * if appropriate - before calling this method.
     * <p>
     * This uses a {@link IllegalXMLCharacterFilter} to filter out any bad Unicode characters
     * in the Object data.
     *
     * @throws DataBindingException if any error occurs during the serialization
     *   process.
     */
    public <E> void writeObject(E object, Result result) {
        /* Get the appropriate generator class */
        ObjectWriterStrategy<E> writer = getObjectWriterStrategy(object);
        if (log.isDebugEnabled()) {
            log.debug("Writing object " + object + " using strategy " + writer);
        }
        /* Create a very simple pipeline to do the serialization. */
        XMLPipeline pipeline = new XMLPipeline(xmlFactory);
        
        /* Add filter to remove illegal chars */
        pipeline.addFilterStep(illegalCharacterFilter);

        /* Now add serializer */
        TransformerHandler serializer = pipeline.addSerializer(result);
        Transformer transformer = serializer.getTransformer();

        /* Make sure serializer has the correct properties set */
        String outputSystemId = writer.getSystemId();
        if (outputSystemId!=null) {
            transformer.setOutputProperty(OutputKeys.DOCTYPE_SYSTEM, outputSystemId);
        }
        transformer.setOutputProperty(OutputKeys.ENCODING, "UTF-8");
        transformer.setOutputProperty(OutputKeys.INDENT, "yes");

        /* Now feed the pipeline */
        ContentHandler pipelineInput = pipeline.getStep(0);
        try {
            writer.generateDocument(object, pipelineInput);
        }
        catch (SAXException e) {
            throw new DataBindingException("Could not write Object " + object, e);
        }
        finally {
            writer.reset();
        }
    }

    /**
     * Convenience method to serialize the given Object as a UTF-8 encoded XML document,
     * returned as a String.
     * <p>
     * The caller should ensure that the Object is in a consistent (e.g. valid) state -
     * if appropriate - before calling this method.
     * <p>
     * This uses a {@link IllegalXMLCharacterFilter} to filter out any bad Unicode characters
     * in the Object data.
     * 
     * @param object
     * @return XML document
     * 
     * @throws DataBindingException if any error occurs during the serialization
     *   process.
     */
    public String writeObject(Object object) {
        StringWriter result = new StringWriter();
        writeObject(object, new StreamResult(result));
        return result.toString();
    }

    /**
     * Gets an instance of a strategy for writing out the given Object as a series
     * of SAX Events. If an instance has already been created by this marshaller
     * then it will be reused.
     * <p>
     * This strategy must not be used by two Threads at once, and must be considered
     * "owned" by the Marshaller that created it.
     *
     * @param object
     * 
     * @throws DataBindingException
     */
    @SuppressWarnings("unchecked")
    <E> ObjectWriterStrategy<E> getObjectWriterStrategy(Object object) {
        ObjectWriterStrategy<E> writerStrategy = writerStrategyFactory.getStrategy(object.getClass().getName());
        if (writerStrategy==null) {
            throw new DataBindingException("AbstractMarshaller doesn't know how to write objects of Class "
                    + object.getClass());
        }
        writerStrategy.setMarshaller(this);
        return writerStrategy;
    }
    
    /**
     * Trivial helper to make sure the given {@link Closeable} can be closed, throwing
     * {@link DataBindingException} if not. This is used by the methods which accept
     * streams.
     * 
     * @param stream
     */
    private void ensureCloseStream(Closeable stream) {
        try {
            stream.close();
        }
        catch (IOException e) {
            throw new DataBindingException("Could not close stream " + stream, e);
        }
    }
}
