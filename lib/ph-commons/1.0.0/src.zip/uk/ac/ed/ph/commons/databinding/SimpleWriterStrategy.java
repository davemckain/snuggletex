/* $Id:SimpleWriterStrategy.java 2824 2008-08-01 15:46:17Z davemckain $
 *
 * Copyright (c) 2003 - 2008 University of Edinburgh.
 * All Rights Reserved
 */
package uk.ac.ed.ph.commons.databinding;

import uk.ac.ed.ph.commons.xml.XMLUtilities;
import uk.ac.ed.ph.commons.xml.saxfilters.DocumentEmbeddingFilter;

import java.io.IOException;
import java.io.StringReader;
import java.util.HashMap;
import java.util.Map;

import javax.xml.parsers.SAXParser;

import org.xml.sax.Attributes;
import org.xml.sax.ContentHandler;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
import org.xml.sax.XMLReader;
import org.xml.sax.helpers.AttributesImpl;

/**
 * Simple implementation of {@link ObjectWriterStrategy} that adds methods for firing
 * off common types of SAX Events. It complements the {@link SimpleReaderStrategy}
 * base class for reading but is somewhat simpler as reading is generally harder.
 * <p>
 * The names of the types of elements to be created (container, text, mixed content,
 * embedded objects) correspond to those used in {@link SimpleReaderStrategy}.
 *
 * <h2>To to Use</h2>
 *
 * Subclasses should implement {@link #getNamespaceMappings(Object)} to register
 * a set of Namespace prefix -> Namespace URI mappings. This is a convenience
 * measure to allow use of simple Qualified Names in all of the other methods.
 *
 * Subclasses should also implement {@link #fireDocumentEvents(Object)} to fire
 * off the appropriate SAX Events. There are methods for firing off different
 * types of elements.
 *
 * <h2>Limitations</h2>
 *
 * As with {@link SimpleReaderStrategy}, the design of this strategy is slightly poor
 * as it adapts the interface too much and things are very heavily coupled, but it is
 * in fact very easy to create subclasses and it is also easy to manage.
 *
 * @see SimpleReaderStrategy
 *
 * @author  David McKain
 * @version $Revision:2824 $
 */
public abstract class SimpleWriterStrategy<E> implements ObjectWriterStrategy<E> {

    /** AbstractMarshaller that created this */
    private AbstractMarshaller marshaller;

    //---------------------------------------------------------
    // State during Event generation

    /** ContentHandler that we're firing at */
    private ContentHandler contentHandler;

    /**
     * Currently in-scope prefix mappings,
     * set in {@link #generateFragment(Object, ContentHandler, Map)}
     * in time for the call to {@link #fireDocumentEvents(Object)}
     */
    private Map<String,String> namespaceMappings;

    /** XMLReader for handling XML fragments, initialised when needed */
    private XMLReader fragmentReader;

    /** Filter for embedding XML fragments in output, initialised when needed */
    private FragmentEmbeddingFilter fragmentEmbeddingFilter;
    
    /** 
     * Buffer used to contain the results of splitting QNames into
     * <code> { nsUri, nsPrefix, nsLocalName } </code>
     */
    private String[] qnameSplitBuffer;

    //-----------------------------------------------
    // Implementation of ObjectWriterStrategy

    public void setMarshaller(AbstractMarshaller marshaller) {
        this.marshaller = marshaller;
    }

    public final void generateDocument(E object, ContentHandler handler) throws SAXException {
        handler.startDocument();
        generateFragment(object, handler, null);
        handler.endDocument();
    }

    public final void generateFragment(E object, ContentHandler handler,
            Map<String,String> inscopeNamespaceMappings) throws SAXException {
        /* Set up buffer to split QNames into (saves having to create arrays over and over) */
        this.qnameSplitBuffer = new String[3];
        
        /* Read in new namespace mappings for this strategy */
        String[] newNamespaceMappingsArray = getNamespaceMappings(object);
        String prefix, uri, oldUri;
        for (int i=0; i<newNamespaceMappingsArray.length; ) {
            prefix = newNamespaceMappingsArray[i++];
            uri    = newNamespaceMappingsArray[i++];
        }
        
        /* Register new mappings, closing existing ones if required. */
        for (int i=0; i<newNamespaceMappingsArray.length; ) {
            prefix = newNamespaceMappingsArray[i++];
            uri    = newNamespaceMappingsArray[i++];
            oldUri = inscopeNamespaceMappings!=null ? inscopeNamespaceMappings.get(prefix) : null;
            if (oldUri!=null && oldUri.equals(uri)) {
                /* Same mappings as what's currently in scope, so do nothing */
            }
            else {
                /* Remove old mapping and replace with new */
                if (oldUri!=null) {
                    handler.endPrefixMapping(prefix);
                }
                handler.startPrefixMapping(prefix, uri);
            }
        }
        
        /* Merge new mappings with ones that were passed as being currently in-scope, being
         * careful to make a new Map rather than altering the existing one! */
        if (inscopeNamespaceMappings==null) {
            this.namespaceMappings = new HashMap<String, String>();
        }
        else {
            this.namespaceMappings = new HashMap<String, String>(inscopeNamespaceMappings);
        }
        for (int i=0; i<newNamespaceMappingsArray.length; ) {
            prefix = newNamespaceMappingsArray[i++];
            uri    = newNamespaceMappingsArray[i++];
            this.namespaceMappings.put(prefix, uri);
        }
        
        /* Set ContentHandler for during of run, then allow subclass
         * to control what happens next before clearing up.
         */
        this.contentHandler = handler;
        fireDocumentEvents(object);

        /* Finally, revert prefix mappings to the way they were before */
        for (int i=0; i<newNamespaceMappingsArray.length; ) {
            prefix = newNamespaceMappingsArray[i++];
            uri    = newNamespaceMappingsArray[i++];
            oldUri = inscopeNamespaceMappings!=null ? inscopeNamespaceMappings.get(prefix) : null;
            if (oldUri!=null && oldUri.equals(uri)) {
                /* Same mappings as what's currently in scope, so do nothing */
            }
            else {
                /* Remove new mapping and replace with old */
                handler.endPrefixMapping(prefix);
                if (oldUri!=null) {
                    handler.startPrefixMapping(prefix, oldUri);
                }
            }
        }
    }

    public void reset() {
        this.contentHandler = null;
        this.namespaceMappings = null;
        this.qnameSplitBuffer = null;
    }

    //-----------------------------------------------
    // Subclasses can call the following methods to fire out the appropriate SAX Events.

    /**
     * Starts a new Container element having the given qualified name.
     * <p>
     * An optional list of attributes can be specified as
     * a simple String array of the form:
     *
     * <code>{ qname, value, qname, value, ... }</code>
     *
     * For convenience, any null values will result in the corresponding
     * attribute being ignored.
     *
     * @param qName
     * @param attrsMap
     * @throws SAXException
     */
    protected void startContainerElement(String qName, String[] attrsMap) throws SAXException {
        /* First, split the qName into nsPrefix:localName, storing results in qnameSplitBuffer */
        splitQName(qName);
        String eltNsUri     = qnameSplitBuffer[0];
        String eltNsPrefix  = qnameSplitBuffer[1];
        String eltLocalName = qnameSplitBuffer[2];
        if (eltNsPrefix.length()==0) {
            throw new DataBindingException("Element name " + qName + " must be qualified");
        }

        /* Build up attributes, if specified. We remove any null values here */
        AttributesImpl attrs = null;
        if (attrsMap!=null) {
            String attrQName, attrValue, attrUri, attrLocalName;
            for (int i=0; i<attrsMap.length; ) {
                attrQName = attrsMap[i++];
                attrValue = attrsMap[i++];
                if (attrValue!=null) {
                    /* A non-null value has been specified, so we'll create new attribute */

                    /* Split up qualified names in attributes, storing results in qnameSplitBuffer */
                    splitQName(attrQName);
                    attrUri = qnameSplitBuffer[0];
                    attrLocalName = qnameSplitBuffer[2];
                    
                    /* Create and store attribute, lazily instantiating attrs Object if required */
                    if (attrs==null) {
                        attrs = new AttributesImpl();
                    }
                    attrs.addAttribute(attrUri, attrLocalName, attrQName, "CDATA", attrValue);
                }
            }
        }
        /* Finally if no attributes have been set, use the shared empty object */
        if (attrs==null) {
            attrs = XMLUtilities.EMPTY_ATTRIBUTES;
        }
        /* Now fire off relevant SAX Event */
        contentHandler.startElement(eltNsUri, eltLocalName, qName, attrs);
    }

    /**
     * Convenience version of {@link #startContainerElement(String, String[])}
     * for elements without attributes.
     *
     * @param qName
     * @throws SAXException
     */
    protected void startContainerElement(String qName) throws SAXException {
        startContainerElement(qName, null);
    }

    /**
     * Ends the (previously started) Container element with the given
     * qualified name.
     *
     * @param qName XML QName of the container element to end.
     * @throws SAXException
     */
    protected void endContainerElement(String qName) throws SAXException {
        /* First, split the qName into nsPrefix:localName, storing result in qnameSplitBuffer */
        splitQName(qName);
        String eltNsUri     = qnameSplitBuffer[0];
        String eltNsPrefix  = qnameSplitBuffer[1];
        String eltLocalName = qnameSplitBuffer[2];
        if (eltNsPrefix.length()==0) {
            throw new DataBindingException("Expecting all element names to be qualified");
        }
        /* Now end the element */
        contentHandler.endElement(eltNsUri, eltLocalName, qName);
    }

    /**
     * Helper method to split a qualified name (e.g. xlink:href) into a
     * Namespace URI (http://www.etc...), Namespace prefix (xlink)
     * and localName (href).
     * <p>
     * Any namespace prefixes found are checked to ensure they have been
     * registered.
     * <p>
     * The results are stored in the {@link #qnameSplitBuffer}. We do this rather
     * than creating a temporary result array Object.
     *
     * @param qName
     */
    private void splitQName(String qName) {
        String nsPrefix;
        String nsUri;
        String localName;
        int colonPos = qName.indexOf(':');
        if (colonPos==-1) {
            nsPrefix = "";
            nsUri = "";
            localName = qName;
        }
        else {
            nsPrefix = qName.substring(0, colonPos);
            nsUri = namespaceMappings.get(nsPrefix);
            localName = qName.substring(colonPos + 1);
            if (nsUri==null) {
                throw new DataBindingException("Undeclared namespace prefix " + nsPrefix);
            }
        }
        qnameSplitBuffer[0] = nsUri;
        qnameSplitBuffer[1] = nsPrefix;
        qnameSplitBuffer[2] = localName;
    }

    /**
     * Convenience composite of {@link #startContainerElement(String, String [])}
     * and {@link #endContainerElement(String)} to generate an empty element.
     *
     * @param qName
     * @param attrsMap
     * @throws SAXException
     */
    protected void fireEmptyElement(String qName, String [] attrsMap) throws SAXException {
        startContainerElement(qName, attrsMap);
        endContainerElement(qName);
    }

    /**
     * Creates a Text element having the given name and Content.
     * The content MUST be non-null.
     *
     * @see #fireTextElement(String, String)
     * @see #maybeFireTextElement(String, Object)
     *
     * @param qName
     * @param attributesMap
     * @param content text content to write, which must not be null
     * @throws SAXException
     */
    protected void fireTextElement(String qName, String [] attributesMap, String content) throws SAXException {
        if (content==null) {
            throw new DataBindingException("Content passed to createTextElement() must not be null");
        }
        startContainerElement(qName, attributesMap);
        fireCharacters(content);
        endContainerElement(qName);
    }

    /**
     * Convenience version of {@link #fireTextElement(String, String[], String)}
     * for elements with no attributes or namespace mappings.
     *
     * @see #fireTextElement(String, String[], String)
     * @see #maybeFireTextElement(String, Object)
     *
     * @param qName
     * @param content
     * @throws SAXException
     */
    protected void fireTextElement(String qName, String content) throws SAXException {
        fireTextElement(qName, null, content);
    }

    /**
     * Convenience wrapper round {@link #fireTextElement(String, String)}
     * that creates the text element only if the given String content is non-null,
     * otherwise does nothing.
     *
     * @see #fireTextElement(String, String)
     *
     * @param qName
     * @param content
     * @throws SAXException
     */
    protected void maybeFireTextElement(String qName, Object content) throws SAXException {
        if (content!=null) {
            fireTextElement(qName, content.toString());
        }
    }

    /**
     * Helper method to fire off the given String as characters.
     *
     * @param content
     * @throws SAXException
     */
    private void fireCharacters(String content) throws SAXException {
        contentHandler.characters(content.toCharArray(), 0, content.length());
    }

    /**
     * Embeds the given Object in the XML at the current point. This calls
     * back on the AbstractMarshaller to fire off the appropriate XML fragment.
     * 
     * <h2>Important Note!</h2>
     * 
     * The Object being embedded MUST NOT be of the same type as an Object
     * "in scope" at the time of the embedding. For example, an Object of type A
     * cannot embed another Object of type A or embed an Object of type B which
     * in turn embeds an Object of type A. Doing so will lead to a
     * {@link NullPointerException} and will also mess up namespace mappings.
     *
     * @param object Object to write out
     * @throws DataBindingException
     */
    protected void embedObject(Object object) {
        marshaller.embedObject(object, contentHandler, namespaceMappings);
    }

    /**
     * Embeds the given XML Fragment inside a container element with the
     * given qualified name and Attributes.
     * <p>
     * Please note that whitespace in the XML Fragment may be changed to make the
     * result nicely indented.
     *
     * @see #fireMixedContentElement(String, String)
     *
     * @param qName
     * @param attributesMap
     * @param xmlFragment
     * @throws SAXException
     */
    protected void fireMixedContentElement(String qName, String [] attributesMap, String xmlFragment) throws SAXException {
        if (xmlFragment==null) {
            throw new DataBindingException("Fragment passed to writeMixedContent() must not be null");
        }
        startContainerElement(qName, attributesMap);
        if (xmlFragment.length()>0) { /* (No point trying to fire empty content) */
            if (xmlFragment.indexOf('<')==-1) {
                /* Mixed content is just plain text! */
                fireCharacters(xmlFragment);
            }
            else {
                /* This really is mixed content so parse it and fire it into the stream */
                fireXMLFragment(xmlFragment);
            }
        }
        endContainerElement(qName);
    }

    /**
     * Convenience version of {@link #fireMixedContentElement(String, String[], String)}
     * that adds on Attributes to the container element.
     *
     * @see #fireMixedContentElement(String, String[], String)
     *
     * @param qName
     * @param xmlFragment
     * @throws SAXException
     */
    protected void fireMixedContentElement(String qName, String xmlFragment) throws SAXException {
        fireMixedContentElement(qName, null, xmlFragment);
    }

    /**
     * Helper to do the job of firing off the XML fragments.
     *
     * @param xmlFragment String to fire, which must not be null.
     * @throws SAXException
     */
    private void fireXMLFragment(String xmlFragment) throws SAXException {
        /* See if we've got fragment embedding stuff sorted out */
        if (fragmentReader==null) {
            SAXParser parser = marshaller.getXMLFactory().createNSAwareSAXParser(false);
            fragmentReader = parser.getXMLReader();
            fragmentEmbeddingFilter = new FragmentEmbeddingFilter();
        }
        /* Need to turn the Fragment into a XML document. We'll do this by adding a fake
         * root element. This will be filtered out when passing to the downstream handler
         */
        String xmlDocument = "<root>" + xmlFragment + "</root>";
        fragmentEmbeddingFilter.setContentHandler(contentHandler);
        fragmentReader.setContentHandler(fragmentEmbeddingFilter);
        try {
            fragmentReader.parse(new InputSource(new StringReader(xmlDocument)));
        }
        catch (IOException e) {
            throw new DataBindingException("Unexpected IOException during fragment embedding", e);
        }
    }

    /**
     * Trivial extension of {@link DocumentEmbeddingFilter} used for when
     * we are embedding XML fragments into the output SAX Stream.
     * <p>
     * This basically ignores everything except for the (temporary) root
     * Element we put round the XML fragment to make sure it is a well-formed
     * XML document.
     *
     * @author  David McKain
     * @version $Revision:2824 $
     */
    static class FragmentEmbeddingFilter extends DocumentEmbeddingFilter {

        private int depth;

        @Override
        public void startDocument() throws SAXException {
            depth = 0;
            super.startDocument();
        }

        @Override
        public void startElement(String uri, String localName, String qName, Attributes atts) throws SAXException {
            if (depth++>0) {
                super.startElement(uri, localName, qName, atts);
            }
        }

        @Override
        public void endElement(String uri, String localName, String qName) throws SAXException {
            if (--depth>0) {
                super.endElement(uri, localName, qName);
            }
        }
    }

    //---------------------------------------------------------
    // Subclasses should fill in the following

    /**
     * Return a map of Namespace Prefix => URI mappings to use, flattened
     * as a simple <code>{ prefix, URI, prefix, URI }</code> array.
     * <p>
     * This is used to translate qualified Names into (namespace, local name)
     * pairs.
     * 
     * @param object the Object being written.
     */
    protected abstract String[] getNamespaceMappings(E object);

    /**
     * Implement to fire off the relevant events which will create the
     * actual content of the document. You do this by calling some of the
     * methods defined below.
     * 
     * @param object the Object being written
     */
    protected abstract void fireDocumentEvents(E object) throws SAXException;


}
