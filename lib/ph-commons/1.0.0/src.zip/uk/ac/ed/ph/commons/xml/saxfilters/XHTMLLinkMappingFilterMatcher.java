/* $Id:XHTMLLinkMappingFilterMatcher.java 2824 2008-08-01 15:46:17Z davemckain $
 *
 * Copyright (c) 2003 - 2008 University of Edinburgh.
 * All Rights Reserved
 */
package uk.ac.ed.ph.commons.xml.saxfilters;

import uk.ac.ed.ph.commons.xml.W3CConstants;

import java.util.HashSet;
import java.util.Set;

/**
 * Useful implementation of {@link MappingFilterMatcher} that can be used to hunt out
 * all links in an XHTML document, including the <tt>xml-stylesheet</tt> Processing Instruction.
 *
 * @author  David McKain
 * @version $Revision:2824 $
 */
public class XHTMLLinkMappingFilterMatcher implements MappingFilterMatcher {
    
    public static final String XML_STYLESHEET_PI_TARGET = "xml-stylesheet";
    
    private static final Set<String> elementAndAttributeSet;
    
    /** (Local Name, URI Attribute) pairs in XHTML that may need replaced */
    private static final String[] elementData = {
        /* From XHTML 1.0 Strict */
        "head", "profile",
        "base", "href",
        "link", "href",
        "script", "src",
        "blockquote", "cite",
        "ins", "cite",
        "a", "href",
        "q", "cite",
        "object", "classid",
        "object", "codebase",
        "object", "data",
        "object", "usemap",
        "img", "src",
        "img", "longdesc",
        "img", "usemap",
        "area", "href",
        "form", "action",
        "input", "src",
        "input", "usemap",
        /* From XHTML 1.0 Transitional */
        "iframe", "longdesc",
        "iframe", "src",
        "applet", "codebase",
        /* From XHTML 1.0 Frameset */
        "frame", "longdesc",
        "frame", "src",
        /* Stuff that isn't in the XHTML specification but is commonly used in practice */
        "embed", "src"
    };
    
    static {
        elementAndAttributeSet = new HashSet<String>();
        String xhtmlElementName, xhtmlAttributeName;
        for (int i=0; i<elementData.length; ) {
            xhtmlElementName = elementData[i++];
            xhtmlAttributeName = elementData[i++];
            elementAndAttributeSet.add(encodeElementAndAttributeName(xhtmlElementName, xhtmlAttributeName));
        }
    }
    
    private static String encodeElementAndAttributeName(String xhtmlElementLocalName, String xhtmlAttributeLocalName) {
        return xhtmlElementLocalName + " " + xhtmlAttributeLocalName;
    }

    public boolean matchTextElementContent(String elementNamespaceUri, String elementLocalName) {
        return false;
    }
    
    public boolean matchAttributeContent(String elementNamespaceUri, String elementLocalName,
            String attributeNamespaceUri, String attributeLocalName) {
        return elementAndAttributeSet.contains(encodeElementAndAttributeName(elementLocalName, attributeLocalName))
            && elementNamespaceUri.equals(W3CConstants.XHTML_NAMESPACE)
            && attributeNamespaceUri.equals("");
    }
    
    public boolean matchProcessingInstruction(String target) {
        return target.equals(XML_STYLESHEET_PI_TARGET);
    }
}
