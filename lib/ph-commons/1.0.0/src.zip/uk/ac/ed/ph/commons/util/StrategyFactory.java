/* $Id: StrategyFactory.java 58 2008-08-03 19:29:15Z dmckain $
 *
 * Copyright (c) 2003 - 2008 University of Edinburgh.
 * All Rights Reserved.
 */
package uk.ac.ed.ph.commons.util;

import java.lang.reflect.Constructor;
import java.util.HashMap;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * One common pattern used (especially in Aardvark) is a Map storing "strategy"
 * classes that perform particular operations based on an common interface.
 * <p>
 * For example, there are different Validation Strategies for different types of
 * Nodes and different strategies for marshalling Java Objects to and from XML
 * corresponding to the underlying class.
 * <p>
 * This class provides a very simple Factory class for instantiating, caching
 * and managing such strategies.
 * <p>
 * This now supports using a specified constructor by setting the
 * {@link #constructorParameterTypes} property to indicate which types of
 * constructor can be used. Constructor parameters can be passed to the
 * {@link #getStrategy(Object, Object...)} method.
 *
 * @param <K> Key class, must be a suitable hash key.
 * @param <S> Strategy class
 * 
 * @author  David McKain
 * @version $Revision: 58 $
 */
public class StrategyFactory<K,S> {

    private static final Log log = LogFactory.getLog(StrategyFactory.class);

    /** Map detailing which class to instantiate for each key K, must not be null */
    private final StrategyFactoryConfiguration<K,S> factoryClassMap;

    /** Whether to reuse strategies */
    private boolean caching;

    /** Map of instantiated strategies */
    private Map<K,S> factoryCache;

    /** Constructor parameter classes (normally null) */
    private Class<?> constructorParameterTypes;

    /**
     * Creates a non-caching Factory using the given Map to decide
     * which strategies to instantiate.
     *
     * @param factoryClassMap Map defining which strategies to use for the various keys K
     */
    public StrategyFactory(StrategyFactoryConfiguration<K,S> factoryClassMap) {
        this(factoryClassMap, false);
    }

    /**
     * Creates an optionally caching Factory using the given Map to decide
     * which strategies to instantiate.
     *
     * @param factoryClassMap Map defining which strategies to use for the various keys K
     * @param caching whether to cache strategies or not
     */
    public StrategyFactory(StrategyFactoryConfiguration<K,S> factoryClassMap, boolean caching) {
        ConstraintUtilities.ensureNotNull(factoryClassMap, "Factory Class Map");
        this.factoryClassMap = factoryClassMap;
        setCaching(caching);
    }

    public Map<K,Class<? extends S>> getFactoryClassMap() {
        return factoryClassMap;
    }

    public boolean isCaching() {
        return caching;
    }

    public void setCaching(boolean caching) {
        this.caching = caching;
        resetCache();
    }

    public Class<?> getConstructorParameterTypes() {
        return this.constructorParameterTypes;
    }

    public void setConstructorParameterTypes(Class<?> constructorParameterTypes) {
        this.constructorParameterTypes = constructorParameterTypes;
    }

    public synchronized void resetCache() {
        if (!caching) {
            factoryCache = null;
        }
        else {
            if (factoryCache!=null) {
                factoryCache.clear();
            }
            else {
                factoryCache = new HashMap<K,S>();
            }
        }
    }

    /**
     * Gets a strategy instance S for the given key K. This may result in
     * a cached instance being reused (if caching) or may cause a new strategy to be
     * created.
     * <p>
     * Note that the cache only caches by the type of strategy and the
     * constructorParamters are only used when the result Object is <b>first</b> created.
     *
     * @param key type of strategy to create
     * @param constructorParameters optional parameters to pass to strategy if/when it needs
     *   constructed.
     *
     * @return strategy for given key K, or null if no strategy exists for the given key.
     *
     * @throws StrategyCreationException if a strategy cannot be
     * instantiated.
     */
    public S getStrategy(K key, Object... constructorParameters) {
        if (!caching) {
            return createStrategy(key, constructorParameters);
        }
        S result;
        synchronized(this) {
            result = factoryCache.get(key);
            if (result==null) {
                result = createStrategy(key, constructorParameters);
                factoryCache.put(key, result);
            }
        }
        return result;
    }

    /**
     * Creates a new strategy instance S for the given key K. The newly created strategy
     * is <strong>not</strong> cached.
     *
     * @param key type of strategy to create
     * @param constructorParameters parameters to pass to strategy constructor
     *
     * @return strategy for given key K, or null if no strategy exists for the given key.
     *
     * @throws StrategyCreationException if a strategy cannot be
     * instantiated.
     */
    public S createStrategy(K key, Object... constructorParameters) {
        if (log.isDebugEnabled()) {
            log.debug("Creating new strategy for " + key);
        }
        Class<? extends S> factoryClass = factoryClassMap.get(key);
        if (factoryClass==null) {
            return null;
        }
        S result;
        try {
            if (constructorParameterTypes!=null) {
                /* Use specified constructor */
                Constructor<? extends S> constructor = factoryClass.getConstructor(constructorParameterTypes);
                result = constructor.newInstance(constructorParameters);
            }
            else {
                /* Use default constructor */
                result = factoryClass.newInstance();
            }
        }
        catch (Exception e) {
            throw new StrategyCreationException(e);
        }
        return result;
    }
}
