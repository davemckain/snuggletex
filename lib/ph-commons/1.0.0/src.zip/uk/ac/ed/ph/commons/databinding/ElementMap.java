/* $Id: ElementMap.java 58 2008-08-03 19:29:15Z dmckain $
 *
 * Copyright (c) 2003 - 2008 University of Edinburgh.
 * All Rights Reserved.
 */
package uk.ac.ed.ph.commons.databinding;

import java.util.HashMap;
import java.util.Map;

/**
 * Simple grouping of {@link ElementSet}s, organised as a {@link Map} keyed on Namespace URI.
 *
 * @author  David McKain
 * @version $Revision: 58 $
 */
public final class ElementMap {

    private final Map<String,ElementSet> elementsByNamespaceUri;

    public ElementMap(ElementSet... elementSets) {
        elementsByNamespaceUri = new HashMap<String,ElementSet>();
        for (int i=0; i<elementSets.length; i++) {
            elementsByNamespaceUri.put(elementSets[i].getNamespaceUri(), elementSets[i]);
        }
    }

    public boolean contains(String namespaceUri, String localName) {
        ElementSet elementSet = elementsByNamespaceUri.get(namespaceUri);
        return elementSet!=null && elementSet.getLocalNames().contains(localName);
    }
    
    public boolean isEmpty() {
        return elementsByNamespaceUri.isEmpty();
    }
}