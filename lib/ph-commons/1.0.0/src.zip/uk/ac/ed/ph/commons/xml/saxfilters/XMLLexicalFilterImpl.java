/* $Id:XMLLexicalFilterImpl.java 2824 2008-08-01 15:46:17Z davemckain $
 *
 * Copyright (c) 2003 - 2008 University of Edinburgh.
 * All Rights Reserved
 */
package uk.ac.ed.ph.commons.xml.saxfilters;

import uk.ac.ed.ph.commons.xml.XMLPipeline;

import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
import org.xml.sax.ext.LexicalHandler;
import org.xml.sax.helpers.XMLFilterImpl;

/**
 * A simple extension of {@link XMLFilterImpl} that can handle and pass on
 * lexical events in the same way that XMLFilterImpl handles other types of
 * event.
 * <p>
 * To enable filtering of Lexical events, call
 * {@link #setLexicalHandler(LexicalHandler)} to specify where the lexical
 * events will be sent downstream to.
 * <p>
 * You will also need to make sure that the source of SAX Event for this filter
 * really does fire Lexical events. If using XMLReader, then this is set as a
 * feature - see {@link XMLPipeline#execute(InputSource)} for an example.
 *
 * @author  David McKain
 * @version $Revision:2824 $
 */
public class XMLLexicalFilterImpl extends XMLFilterImpl implements LexicalHandler {

    /** Lexical Handler to receive events from the filter */
    protected LexicalHandler lexicalHandler;

    // ----------------------------------------------

    public LexicalHandler getLexicalHandler() {
        return lexicalHandler;
    }

    public void setLexicalHandler(LexicalHandler handler) {
        lexicalHandler = handler;
    }

    // ----------------------------------------------
    // Implementation of LexicalHandler

    public void comment(char[] ch, int start, int length) throws SAXException {
        if (lexicalHandler != null) {
            lexicalHandler.comment(ch, start, length);
        }
    }

    public void endCDATA() throws SAXException {
        if (lexicalHandler != null) {
            lexicalHandler.endCDATA();
        }
    }

    public void endDTD() throws SAXException {
        if (lexicalHandler != null) {
            lexicalHandler.endDTD();

        }
    }

    public void endEntity(String name) throws SAXException {
        if (lexicalHandler != null) {
            lexicalHandler.endEntity(name);
        }
    }

    public void startCDATA() throws SAXException {
        if (lexicalHandler != null) {
            lexicalHandler.startCDATA();
        }
    }

    public void startDTD(String name, String publicId, String systemId) throws SAXException {
        if (lexicalHandler != null) {
            lexicalHandler.startDTD(name, publicId, systemId);
        }
    }

    public void startEntity(String name) throws SAXException {
        if (lexicalHandler != null) {
            lexicalHandler.startEntity(name);
        }
    }
}
