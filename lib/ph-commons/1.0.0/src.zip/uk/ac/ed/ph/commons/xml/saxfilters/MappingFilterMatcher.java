/* $Id:MappingFilterMatcher.java 2824 2008-08-01 15:46:17Z davemckain $
 *
 * Copyright (c) 2003 - 2008 University of Edinburgh.
 * All Rights Reserved
 */
package uk.ac.ed.ph.commons.xml.saxfilters;

/**
 * Callback interface for a {@link MappingFilter} used to determine which text/attribute Nodes
 * to match in the incoming SAX Stream.
 *
 * @author  David McKain
 * @version $Revision:2824 $
 */
public interface MappingFilterMatcher {
    
    /**
     * Implementors should return whether they are interested in matching the text Node having the
     * given namespace/localName combination.
     * <p>
     * Implementors MUST NOT return true on elements which are not text Nodes (i.e. having
     * text content only.
     * 
     * @param elementNamespaceUri
     * @param elementLocalName
     */
    boolean matchTextElementContent(String elementNamespaceUri, String elementLocalName);
    
    /**
     * Implementors should return whether they are interested in matching the attribute Node of the
     * given Element.
     * 
     * @param elementNamespaceUri
     * @param elementLocalName
     * @param attributeNamespaceUri
     * @param attributeLocalName
     */
    boolean matchAttributeContent(String elementNamespaceUri, String elementLocalName, String attributeNamespaceUri, String attributeLocalName);
    
    /**
     * Implementors should return whether they are interested in matching the XML processing
     * instruction having the given target name
     * 
     * @param target
     */
    boolean matchProcessingInstruction(String target);
}