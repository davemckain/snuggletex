/* $Id: ReaderOptions.java 58 2008-08-03 19:29:15Z dmckain $
 *
 * Copyright (c) 2003 - 2008 University of Edinburgh.
 * All Rights Reserved
 */
package uk.ac.ed.ph.commons.databinding;

/**
 * Encapsulates options that can be passed to {@link AbstractMarshaller}
 * to control how XML files should be read in.
 *
 * @author  David McKain
 * @version $Revision: 58 $
 */
public enum ReaderOptions {

    /** SAX Parser will not read DTD in (and hence not validate) */
    DO_NOT_READ_DTD,

    /** SAX Parser will read DTD in (e.g. to apply defaults) but will not validate against it */
    READ_DTD_BUT_NO_NOT_VALIDATE,

    /** SAX Parser will read DTD in and validate against it */
    READ_DTD_AND_VALIDATE;

}
