/* $Id:ResultAccumulatingFilter.java 2824 2008-08-01 15:46:17Z davemckain $
 *
 * Copyright (c) 2003 - 2008 University of Edinburgh.
 * All Rights Reserved
 */
package uk.ac.ed.ph.commons.xml.saxfilters;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.xml.sax.SAXException;

/**
 * Trivial abstract SAX Base filter that allows you to record Lists of events or
 * results during parsing. This can be extremely handy sometimes - for example,
 * hunting out links, elements of a certain type etc.
 *
 * @param <E> type of result that will be accumulated.
 *
 * @see uk.ac.ed.ph.commons.xml.saxfilters.BinnedResultAccumulatingFilter
 *
 * @author  David McKain
 * @version $Revision:2824 $
 */
public abstract class ResultAccumulatingFilter<E> extends XMLLexicalFilterImpl {

    private static final Log log = LogFactory.getLog(ResultAccumulatingFilter.class);

    /** List of Objects found during parsing */
    private List<E> results;

    //----------------------------------------------------------

    /**
     * Clears up the results built up during the last parse,
     * allowing things to be garbage collected.
     */
    public void reset() {
        this.results = null;
    }
    
    /**
     * Initialises state before the beginning of parsing. This is called automatically
     * by {@link #startDocument()} but is available to subclasses in case they want to
     * do anything strange.
     */
    protected void init() {
        this.results = new ArrayList<E>();
    }

    /**
     * Retrieves the List of results for this parse. It will be
     * a List of the type E you want to accumulate.
     */
    public List<E> getResults() {
        return results;
    }

    //----------------------------------------------------------

    /**
     * Adds the given result to the List of results
     *
     * @param result result to add to List
     */
    protected final void addResult(E result) {
        if (log.isDebugEnabled()) {
            log.debug("Recording result " + result);
        }
        results.add(result);
    }

    /**
     * Overridden to create new List of results at the start of parsing.
     */
    @Override
    public void startDocument() throws SAXException {
        init();
        super.startDocument();
    }
}
