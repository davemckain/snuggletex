/* $Id: LRUHashMap.java 58 2008-08-03 19:29:15Z dmckain $
 *
 * Copyright (c) 2003 - 2008 University of Edinburgh.
 * All Rights Reserved
 */
package uk.ac.ed.ph.commons.util;

import java.util.LinkedHashMap;
import java.util.Map.Entry;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * Simple extension of Java 1.4's {@link LinkedHashMap} that makes its inherent ability
 * to be an LRU cache a bit more prominent.
 * 
 * @param <K> key type
 * @param <V> value type
 *
 * @author  David McKain
 * @version $Revision: 58 $
 */
public class LRUHashMap<K,V> extends LinkedHashMap<K,V> {

    private static final long serialVersionUID = 4050206323365198133L;
    private static final Log log = LogFactory.getLog(LRUHashMap.class);

    private static final int DEFAULT_MAXIMUM_SIZE = 10;

    /** Maximum size of cache */
    private int maxSize = DEFAULT_MAXIMUM_SIZE;
    
    /** Number of elements that have been purged from cache */
    private int purgeCount = 0;

    public LRUHashMap() {
        super();
    }

    public LRUHashMap(int initialCapacity, float loadFactor) {
        super(initialCapacity, loadFactor);
    }

    public LRUHashMap(int initialCapacity) {
        super(initialCapacity);
    }

    @Override
    protected final boolean removeEldestEntry(Entry<K,V> eldest) {
        boolean shouldRemove = (maxSize > 0 && size() > maxSize);
        if (shouldRemove) {
            log.info("Removing eldest entry " + eldest.getKey());
            purgeCount++;
        }
        return shouldRemove;
    }

    /**
     * @return Returns the maximum number of stylesheets cached by this cache.
     */
    public int getMaxSize() {
        return maxSize;
    }

    /**
     * Sets the maximum number of stylesheets held by this cache. This will be
     * enforced the next time a stylesheet is added to the cache.
     * <p>
     * If maxSize <= 0 then the cache will be unbounded.
     */
    public void setMaxSize(int maxSize) {
        this.maxSize = maxSize;
    }

    /**
     * Returns the number of elements that have been purged from this Map due
     * to size issues. This can be useful for auditing purposes.
     * 
     * @return number of elements that have been removed from the Map to accommodate
     *   the maximum size.
     */
    public int getPurgeCount() {
        return this.purgeCount;
    }
    
}
