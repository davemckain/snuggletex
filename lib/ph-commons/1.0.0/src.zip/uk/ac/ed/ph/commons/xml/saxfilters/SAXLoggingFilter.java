/* $Id:SAXLoggingFilter.java 2824 2008-08-01 15:46:17Z davemckain $
 *
 * Copyright (c) 2003 - 2008 University of Edinburgh.
 * All Rights Reserved
 */
package uk.ac.ed.ph.commons.xml.saxfilters;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.XMLFilterImpl;

/**
 * Trivial filter that simply logs the incoming SAX events at the "INFO" level.
 * This can sometimes be useful for debugging/developing.
 *
 * @author  David McKain
 * @version $Revision:2824 $
 */
public class SAXLoggingFilter extends XMLFilterImpl {
    
    private static final Log defaultLog = LogFactory.getLog(SAXLoggingFilter.class);
    
    private final Log log;
    
    public SAXLoggingFilter() {
        this(defaultLog);
    }
    
    public SAXLoggingFilter(Log log) {
        this.log = log;
    }
    
    @Override
    public void startDocument() throws SAXException {
        super.startDocument();
        log.info("startDocument()");
    }
    
    @Override
    public void startPrefixMapping(String prefix, String uri) throws SAXException {
        super.startPrefixMapping(prefix, uri);
        log.info("startPrefixMapping(prefix=" + prefix
                + ",uri=" + uri
                + ")");
    }
    
    @Override
    public void endPrefixMapping(String prefix) throws SAXException {
        super.endPrefixMapping(prefix);
        log.info("endPrefixMapping(prefix=" + prefix + ")");
    }
    
    @Override
    public void startElement(String uri, String localName, String name, Attributes atts)
            throws SAXException {
        super.startElement(uri, localName, name, atts);
        log.info("startElement(uri=" + uri
                + ",localName=" + localName
                + ",name=" + name
                + ",atts=" + attributesToString(atts)
                + ")");
    }
    
    private String attributesToString(Attributes atts) {
        StringBuilder result = new StringBuilder("{");
        for (int i=0, size=atts.getLength(); i<size; i++) {
            if (i>0) {
                result.append(",");
            }
            result.append(atts.getQName(i))
                .append("={")
                .append(atts.getURI(i))
                .append("}")
                .append(atts.getLocalName(i))
                .append("=>")
                .append(atts.getValue(i));
        }
        result.append("}");
        return result.toString();
    }
    
    @Override
    public void characters(char[] ch, int start, int length) throws SAXException {
        super.characters(ch, start, length);
        log.info("characters(text=" + new String(ch,start,length) + ")");
    }
    
    @Override
    public void endElement(String uri, String localName, String name) throws SAXException {
        super.endElement(uri, localName, name);
        log.info("endElement(uri=" + uri
                + ",localName=" + localName
                + ",name=" + name
                + ")");
    }
    
    @Override
    public void endDocument() throws SAXException {
        super.endDocument();
        log.info("endDocument()");
    }
    
    @Override
    public void ignorableWhitespace(char[] ch, int start, int length) throws SAXException {
        super.ignorableWhitespace(ch, start, length);
        log.info("ignorableWhitespace(" + new String(ch, start, length) + ")");
    }
    
    @Override
    public void notationDecl(String name, String publicId, String systemId) throws SAXException {
        super.notationDecl(name, publicId, systemId);
        log.info("notationDecl(name=" + name
                + ",publicId=" + publicId
                + ",systemId=" + systemId
                + ")");
    }
    
    @Override
    public void skippedEntity(String name) throws SAXException {
        super.skippedEntity(name);
        log.info("skippedEntity(name=" + name + ")");
    }
    
    @Override
    public void unparsedEntityDecl(String name, String publicId, String systemId,
            String notationName) throws SAXException {
        super.unparsedEntityDecl(name, publicId, systemId, notationName);
        log.info("unparsedEntityDecl(name=" + name
                + ",publicId=" + publicId
                + ",systemId=" + systemId
                + ",notationName=" + notationName
                + ")");
    }
}
