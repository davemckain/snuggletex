/* $Id: WriterContainer.java 58 2008-08-03 19:29:15Z dmckain $
 *
 * Copyright (c) 2003 - 2008 University of Edinburgh.
 * All Rights Reserved
 */
package uk.ac.ed.ph.commons.databinding;

import java.util.ArrayList;

/**
 * Convenience "container" Object that, when the associated {@link WriterContainerWriterStrategy}
 * is used, makes it easy to write out composites of Objects.
 * <p>
 * This makes it easier to write out a List (or even graph) of Objects inside a single XML
 * container element.
 * <p>
 * Note that there is no provision for reading such XML back in - you'll need to create proper
 * composite Objects and writers for that!
 *
 * @author  David McKain
 * @version $Revision: 58 $
 */
public final class WriterContainer extends ArrayList<Object> {

    private static final long serialVersionUID = 4151377351078981905L;
    
    private final String namespaceUri;
    private final String localName;
    private final String prefix;
    
    public WriterContainer(String namespaceUri, String localName, String prefix) {
        this.namespaceUri = namespaceUri;
        this.localName = localName;
        this.prefix = prefix;
    }
    
    public String getNamespaceUri() {
        return this.namespaceUri;
    }
    
    public String getLocalName() {
        return this.localName;
    }
    
    public String getPrefix() {
        return this.prefix;
    }
}
