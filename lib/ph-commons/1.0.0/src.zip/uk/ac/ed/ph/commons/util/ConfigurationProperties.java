/* $Id: ConfigurationProperties.java 58 2008-08-03 19:29:15Z dmckain $
 *
 * Copyright (c) 2003 - 2008 University of Edinburgh.
 * All Rights Reserved
 */
package uk.ac.ed.ph.commons.util;

import java.io.IOException;
import java.io.InputStream;
import java.util.Iterator;
import java.util.Properties;
import java.util.Set;
import java.util.Map.Entry;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * Simple wrapper round the standard {@link Properties} that makes it easier to
 * use as source of configuration properties by automatically throwing
 * {@link ConfigurationPropertyException} when things go wrong. This is usually
 * the best behaviour when something is mis-configured.
 * <p>
 * All properties files are loaded from the ClassPath.
 *
 * @author David McKain
 * @version $Revision: 58 $
 */
public class ConfigurationProperties {

    private static final Log log = LogFactory.getLog(ConfigurationProperties.class);

    /** Name of the Properties file (to be loaded from ClassPath) */
    private final String propertiesFileName;

    /** Loaded Properties instance (loaded on first access) */
    private Properties properties;

    public ConfigurationProperties(String propertiesFileName) {
        this.propertiesFileName = propertiesFileName;
    }


    /**
     * Looks up the given property, returning null if the property was not registered.
     *
     * @param propertyName
     * @return value of the property
     */
    public String getProperty(String propertyName) {
        return getProperties().getProperty(propertyName);
    }

    /**
     * Looks up the given property, throwing a {@link ConfigurationPropertyException}
     * if the property cannot be found.
     *
     * @param propertyName
     * @return value of the property
     *
     * @throws ConfigurationPropertyException if the given property name could not be found.
     */
    public String getRequiredProperty(String propertyName) {
        String result = getProperty(propertyName);
        if (result==null) {
            throw new ConfigurationPropertyException("Necessary property " + propertyName
                    + " is not set; please check the properties file "
                    + propertiesFileName);
        }
        return result;
    }

    /**
     * Reads in the properties file, if not already done, and returns
     * a {@link Properties} object corresponding to its contents.
     *
     * @return Properties object containing the loaded properties.
     *
     * @throws ConfigurationPropertyException if the properties file could not be loaded
     */
    public Properties getProperties() {
        if (properties==null) {
            /* Create instance lazily */
            properties = new Properties();
            try {
                InputStream propertiesStream = null;
                log.info("Trying to load properties file " + propertiesFileName
                        + " via ClassLoader...");
                propertiesStream = getClass().getClassLoader()
                        .getResourceAsStream(propertiesFileName);
                if (propertiesStream==null) {
                    throw new ConfigurationPropertyException("Could not load properties file "
                            + propertiesFileName
                            + " using ClassLoader");
                }
                properties.load(propertiesStream);
                propertiesStream.close();
                if (log.isDebugEnabled()) {
                    log.debug("Properties read in:\n" + toString());
                }
            }
            catch (IOException e) {
                throw new ConfigurationPropertyException("Could not read properties file " + propertiesFileName
                        + " from ClassPath", e);
            }
        }
        return properties;
    }

    @Override
    public String toString() {
        StringBuilder buffer = new StringBuilder("Properties file read from ");
        buffer.append(propertiesFileName);
        buffer.append(" are:\n");
        Set<Entry<Object, Object>> entrySet = getProperties().entrySet();
        for (Iterator<Entry<Object, Object>> entryIter = entrySet.iterator(); entryIter.hasNext();) {
            Entry<Object, Object> element = entryIter.next();
            buffer.append(element.getKey());
            buffer.append(" => ");
            buffer.append(element.getValue());
            if (entryIter.hasNext()) {
                buffer.append("\n");
            }
        }
        return buffer.toString();
    }
}
