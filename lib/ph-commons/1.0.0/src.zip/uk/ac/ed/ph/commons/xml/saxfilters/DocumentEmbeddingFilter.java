/* $Id:DocumentEmbeddingFilter.java 2824 2008-08-01 15:46:17Z davemckain $
 *
 * Copyright (c) 2003 - 2008 University of Edinburgh.
 * All Rights Reserved
 */
package uk.ac.ed.ph.commons.xml.saxfilters;

import org.xml.sax.SAXException;

/**
 * Trivial SAX Filter that can be applied if you want to embed
 * a document inside another one.
 * <p>
 * This works by stripping out any start/end Document events,
 * plus anything relevant to DTDs. Comments within the DTD will
 * be stripped out.
 * <p>
 * <strong>Note:</strong> The source document DTD must not
 * declare anything that is used later in the document, such as
 * a notation or unparsed entity as these will declarations will
 * be removed during the wrapping process. As a result, a SAXException
 * is thrown if any of these are seen.
 * <p>
 * This filter is serially reusable but <strong>NOT</strong> thread-safe.
 *
 * @author  David McKain
 * @version $Revision:2824 $
 */
public class DocumentEmbeddingFilter extends XMLLexicalFilterImpl {

    /** Flag to denote whether we are inside the DTD */
    private boolean isInDTD;

    /**
     * Overridden to do nothing.
     *
     * @throws SAXException
     */
    @SuppressWarnings("unused")
    @Override
    public void startDocument() throws SAXException {
        isInDTD = false;
    }

    /**
     * Overridden to do nothing.
     */
    @Override
    public void endDocument() {
    }

    /**
     * Overridden to do nothing.
     */
    @Override
    public void startDTD(String name, String publicId, String systemId) {
        isInDTD = true; // Update to avoid any comments being reported inside DTD
    }

    /**
     * Overridden to do nothing.
     */
    @Override
    public void endDTD() {
        isInDTD = false; // Update to allow comments after this
    }

    /**
     * Overridden to do nothing.
     */
    @Override
    public void startEntity(String name) {
    }

    /**
     * Overridden to do nothing.
     */
    @Override
    public void endEntity(String name) {
    }


    /**
     * Overridden to strip comments inside the DTD.
     */
    @Override
    public void comment(char[] ch,int start,int length) throws SAXException {
        if (!isInDTD) {
            super.comment(ch, start, length);
        }
    }

    /**
     * Overridden to fail as downstream handlers can't do anything with this.
     */
    @Override
    public void notationDecl(String name, String publicId, String systemId) throws SAXException {
        fail("notationDecl()");
    }

    /**
     * Overridden to fail as downstream handlers can't do anything with this.
     */
    @Override
    public void unparsedEntityDecl(String name, String publicId, String systemId, String notationName) throws SAXException {
        fail("unparsedEntityDecl()");
    }

    /**
     * Helper to cause failure if we encounter something we can't handle.
     *
     * @param eventType SAX Event name/type to use when constructing Exception.
     *
     * @throws SAXException
     */
    private void fail(String eventType) throws SAXException {
        throw new SAXException(getClass().getName()
                + " cannot handle documents that fire " + eventType
                + " Events");
    }
}
