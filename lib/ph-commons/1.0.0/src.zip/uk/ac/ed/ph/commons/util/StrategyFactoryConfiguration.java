/* $Id: StrategyFactoryConfiguration.java 58 2008-08-03 19:29:15Z dmckain $
 *
 * Copyright (c) 2003 - 2008 University of Edinburgh.
 * All Rights Reserved
 */
package uk.ac.ed.ph.commons.util;

import java.util.HashMap;

/**
 * Trivial class describing the configuration for a {@link StrategyFactory}.
 * This is just an obvious subclass of {@link HashMap} but makes things a bit
 * clearer to look at.
 *
 * @param <K> Key class
 * @param <S> Strategy class
 *
 * @author  David McKain
 * @version $Revision: 58 $
 */
public class StrategyFactoryConfiguration<K,S> extends HashMap<K,Class<? extends S>> {

    private static final long serialVersionUID = 1887364884134285920L;

}
