/* $Id: W3CConstants.java 58 2008-08-03 19:29:15Z dmckain $
 *
 * Copyright (c) 2003 - 2008 University of Edinburgh.
 * All Rights Reserved
 */
package uk.ac.ed.ph.commons.xml;

/**
 * A collection of useful World Wide Web Consortium-related constants (e.g. system identifiers,
 * namespaces, etc...)
 *
 * @author  David McKain
 * @version $Revision: 58 $
 */
public interface W3CConstants {
    
    /** Base for W3C-related stuff */
    String W3C_BASE_URI = "http://www.w3.org/";
    
    //--------------------------------------------------
    // Public and System Identifiers

    String XHTML_11_MATHML_20_PUBLIC_DTD = "-//W3C//DTD XHTML 1.1 plus MathML 2.0 plus SVG 1.1//EN";
    String XHTML_11_MATHML_20_SYSTEM_DTD = "http://www.w3.org/Math/DTD/mathml2/xhtml-math11-f.dtd";
    
    //--------------------------------------------------
    // Namespaces

    String MATHML_NAMESPACE = W3C_BASE_URI + "1998/Math/MathML";
    String XHTML_NAMESPACE = W3C_BASE_URI + "1999/xhtml";
    String XLINK_NAMESPACE = W3C_BASE_URI + "1999/xlink";
    String XSI_NAMESPACE = W3C_BASE_URI + "2001/XMLSchema-instance";

}
