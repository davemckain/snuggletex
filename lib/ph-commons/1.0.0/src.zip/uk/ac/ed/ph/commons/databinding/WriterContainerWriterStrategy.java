/* $Id: WriterContainerWriterStrategy.java 58 2008-08-03 19:29:15Z dmckain $
 *
 * Copyright (c) 2003 - 2008 University of Edinburgh.
 * All Rights Reserved
 */
package uk.ac.ed.ph.commons.databinding;

import org.xml.sax.SAXException;

/**
 * Utility strategy that writes out {@link WriterContainer} Objects. If you want to use this,
 * remember you still need to register it with the {@link AbstractMarshaller} just as you would
 * do with any other writer!
 *
 * @author  David McKain
 * @version $Revision: 58 $
 */
public final class WriterContainerWriterStrategy extends SimpleWriterStrategy<WriterContainer> {

    @Override
    protected void fireDocumentEvents(WriterContainer container) throws SAXException {
        String qName = container.getPrefix() + ":" + container.getLocalName();
        startContainerElement(qName);
        for (Object object : container) {
            embedObject(object);
        }
        endContainerElement(qName);
    }

    @Override
    protected String[] getNamespaceMappings(WriterContainer container) {
        return new String[] { container.getPrefix(), container.getNamespaceUri() };
    }

    public String getSystemId() {
        return null;
    }
}
