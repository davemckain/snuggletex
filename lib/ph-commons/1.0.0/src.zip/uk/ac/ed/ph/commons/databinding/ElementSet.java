/* $Id: ElementSet.java 58 2008-08-03 19:29:15Z dmckain $
 *
 * Copyright (c) 2003 - 2008 University of Edinburgh.
 * All Rights Reserved.
 */
package uk.ac.ed.ph.commons.databinding;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

/**
 * Simple container for a set of XML Elements belonging to a particular namespace.
 *
 * @author  David McKain
 * @version $Revision: 58 $
 */
public final class ElementSet {

    /** Namespace URI that these Elements live in */
    private final String namespaceUri;

    /** Local Names of Elements */
    private final Set<String> localNames;

    public ElementSet(String namespaceUri, String... localNames) {
        this.namespaceUri = namespaceUri;
        this.localNames = new HashSet<String>(Arrays.asList(localNames));
    }

    public String getNamespaceUri() {
        return namespaceUri;
    }

    public Set<String> getLocalNames() {
        return localNames;
    }
}