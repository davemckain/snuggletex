/* $Id:MappingFilter.java 2824 2008-08-01 15:46:17Z davemckain $
 *
 * Copyright (c) 2003 - 2008 University of Edinburgh.
 * All Rights Reserved
 */
package uk.ac.ed.ph.commons.xml.saxfilters;

import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.AttributesImpl;

/**
 * General-purpose filter that can search and optionally update certain incoming text Nodes and
 * attribute Nodes.
 *
 * @author  David McKain
 * @version $Revision:2824 $
 */
public class MappingFilter extends StatefulFilter {
    
    private StringBuilder textContentBuilder;
    private boolean isInTextElement;
    private String currentTextElementLocalName;
    private String currentTextElementUri;
    
    private final MappingFilterMatcher matcher;
    private final MappingFilterCallback callback;
    
    public MappingFilter(MappingFilterMatcher matcher, MappingFilterCallback callback) {
        this.matcher = matcher;
        this.callback = callback;
    }
    
    @Override
    public void initState() {
        isInTextElement = false;
        currentTextElementUri = null;
        currentTextElementLocalName = null;
        if (textContentBuilder!=null) {
            textContentBuilder.setLength(0);
        }
    }
    
    @Override
    public void checkFinalState() {
        if (isInTextElement || currentTextElementLocalName!=null || currentTextElementUri!=null
                || (textContentBuilder!=null && textContentBuilder.length()>0)) {
            throw new IllegalStateException("Bad state detected at end of document");
        }
    }
    
    @Override
    public void resetState() {
         initState();
    }
    
    @Override
    public void startDocument() throws SAXException {
        callback.onStartDocument();
        super.startDocument();
    }
    
    @Override
    public void endDocument() throws SAXException {
        super.endDocument();
        callback.onEndDocument();
    }

    @Override
    public void startElement(String uri, String localName, String qName, Attributes atts)
            throws SAXException {
        if (isInTextElement) {
            throw new IllegalStateException("New element started inside supposed text element with URI "
                    + currentTextElementUri + " and local name " + currentTextElementLocalName);
        }
        /* Decide whether we are going to search text content */
        if (matcher.matchTextElementContent(uri, localName)) {
            /* OK, start recording content */
            isInTextElement = true;
            currentTextElementUri = uri;
            currentTextElementLocalName = localName;
            if (textContentBuilder==null) {
                textContentBuilder = new StringBuilder();
            }
            else {
                textContentBuilder.setLength(0);
            }
        }
        /* Search any attributes */
        AttributesImpl alteredAtts = null;
        int attsLength = atts.getLength();
        String attrNamespaceUri;
        String attrLocalName;
        String attrValue, replacementAttrValue;
        int readIndex, writeIndex;
        for (readIndex=0, writeIndex=0; readIndex<attsLength; readIndex++, writeIndex++) {
            attrNamespaceUri = atts.getURI(readIndex);
            attrLocalName = atts.getLocalName(readIndex);
            if (matcher.matchAttributeContent(uri, localName, attrNamespaceUri, attrLocalName)) {
                attrValue = atts.getValue(readIndex);
                replacementAttrValue = callback.mapAttribute(uri, localName, attrNamespaceUri, attrLocalName, attrValue);
                if (replacementAttrValue==null || !replacementAttrValue.equals(attrValue)) {
                    /* We're making a change. Need to copy existing ones if we haven't already done so */
                    if (alteredAtts==null) {
                        alteredAtts = new AttributesImpl(atts);
                    }
                    if (replacementAttrValue!=null) {
                        /* Update existing attribute */
                        alteredAtts.setValue(writeIndex, replacementAttrValue);
                    }
                    else {
                        /* Remove attribute, and decrement writeIndex so that next loop iteration
                         * will return us to the same writeIndex */
                        alteredAtts.removeAttribute(writeIndex--);
                    }
                }
            }
        }
        /* Then fire start element as normal, using replacement attributes if required */
        super.startElement(uri, localName, qName, alteredAtts!=null ? alteredAtts : atts);
    }
    
    @Override
    public void characters(char[] ch, int start, int length) throws SAXException {
        if (isInTextElement) {
            textContentBuilder.append(ch, start, length);
        }
        else {
            super.characters(ch, start, length);
        }
    }
    
    @Override
    public void endElement(String uri, String localName, String qName) throws SAXException {
        if (isInTextElement) {
            String rawTextContent = textContentBuilder.toString();
            String replacementText = callback.mapTextElementContent(currentTextElementUri,
                    currentTextElementLocalName, rawTextContent);
            if (replacementText==null) {
                throw new IllegalStateException("Replacement content must not be null");
            }
            super.characters(replacementText.toCharArray(), 0, replacementText.length());
            resetState();
        }
        super.endElement(uri, localName, qName);
    }
    
    @Override
    public void processingInstruction(String target, String data) throws SAXException {
        String outgoingData = data;
        if (matcher.matchProcessingInstruction(target)) {
            outgoingData = callback.mapProcessingInstructionData(target, data);
        }
        super.processingInstruction(target, outgoingData);
    }
}
