/* $Id: LazyArrayList.java 316 2008-10-17 15:44:30Z dmckain $
 *
 * Copyright 2008 University of Edinburgh.
 * All Rights Reserved
 */
package uk.ac.ed.ph.commons.util;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.ListIterator;

/**
 * Trivial extension of {@link ArrayList} that automatically grows by adding new elements
 * created by {@link #createFillerElement()} so that interrogations on the list never fail
 * because the right index is out of range.
 * <p>
 * This is very useful for doing binding in Spring, as it calls getters and setters when
 * re-instantiating lists without first ensuring it has a suitable size.
 * 
 * @author  David McKain
 * @version $Revision: 316 $
 */
public abstract class LazyArrayList<E> extends ArrayList<E> {

    private static final long serialVersionUID = 6617844046831235735L;

    /**
     * Subclasses should override this to create a "filler" element when this is
     * deemed necessary.
     */
    protected abstract E createFillerElement();

    @Override
    public E get(int index) {
        ensureIndex(index);
        return super.get(index);
    }

    @Override
    public E set(int index, E element) {
        ensureIndex(index);
        return super.set(index, element);
    }

    @Override
    public void add(int index, E element) {
        ensureIndex(index);
        super.add(index, element);
    }

    @Override
    public boolean addAll(int index, Collection<? extends E> c) {
        ensureIndex(index);
        return super.addAll(index, c);
    }

    @Override
    public ListIterator<E> listIterator(int index) {
        ensureIndex(index);
        return super.listIterator(index);
    }
    
    @Override
    public E remove(int index) {
        ensureIndex(index);
        return super.remove(index);
    }

    @Override
    protected void removeRange(int fromIndex, int toIndex) {
        ensureIndex(toIndex);
        super.removeRange(fromIndex, toIndex);
    }
    
    @Override
    public List<E> subList(int fromIndex, int toIndex) {
        ensureIndex(toIndex);
        return super.subList(fromIndex, toIndex);
    }

    protected void ensureIndex(int index) {
        for (int i=size(); i<=index; i++) {
            super.add(createFillerElement());
        }
    }
}
