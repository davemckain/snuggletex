/* $Id: JSFunctionCall.java 58 2008-08-03 19:29:15Z dmckain $
 *
 * Copyright (c) 2003 - 2008 University of Edinburgh.
 * All Rights Reserved
 */
package uk.ac.ed.ph.commons.util;

/**
 * This trivial class represents a JavaScript function (or method) call, providing
 * some convenience methods for serializing as a String for passing to a JS interpreter
 * for evaluation (either by AJAX, Applet/browser communication or something similar).
 *
 * @author  David McKain
 * @version $Revision: 58 $
 */
public final class JSFunctionCall {

    /** Name of the function or method we are calling */
    private final String functionName;
    
    /** Array of arguments to pass to the function */
    private String[] arguments;
    
    public JSFunctionCall(String functionName, String... arguments) {
        this.functionName = functionName;
        this.arguments = arguments;
    }
    
    public String getFunctionName() {
        return this.functionName;
    }
    
    public String[] getArguments() {
        return this.arguments;
    }

    public String toJavaScript() {
        StringBuilder builder = new StringBuilder(functionName);
        builder.append("(");
        boolean hasDoneFirstArg = false;
        for (String arg : arguments) {
            if (hasDoneFirstArg) {
                builder.append(", ");
            }
            if (arg!=null) {
                appendJavaScriptString(builder, arg);
            }
            else {
                builder.append("null");
            }
            hasDoneFirstArg = true;
        }
        builder.append(");");
        return builder.toString();
    }
    
    @Override
    public String toString() {
        return toJavaScript();
    }
    
    /**
     * Useful helper method for converting a raw Java String into a String that can be passed
     * to JavaScript and interpreted as a String.
     * <p>
     * The result is appended to the given builder.
     * <p>
     * Examples:
     * <tt>Hello</tt> becomes <tt>"Hello"</tt>
     * <br>
     * <tt>Hello\n"There"</tt> becomes <tt>"Hello\\n\\"There\\""</tt>
     * 
     * @param s String to escape
     * 
     * @return resulting JavaScript-safe String
     * 
     * @see #appendJavaScriptString(StringBuilder, String)
     */
    public static String toJavaScriptString(String s) {
        StringBuilder result = new StringBuilder();
        appendJavaScriptString(result, s);
        return result.toString();
    }
    
    /**
     * Useful helper method for converting a raw Java String into a String that can be passed
     * to JavaScript and interpreted as a String.
     * <p>
     * The result is appended to the given builder.
     * <p>
     * Examples:
     * <tt>Hello</tt> becomes <tt>"Hello"</tt>
     * <br>
     * <tt>Hello\n"There"</tt> becomes <tt>"Hello\\n\\"There\\""</tt>
     * 
     * @param resultBuilder StringBuilder to append to.
     * @param s String to escape
     * 
     * @see #toJavaScriptString(String)
     */
    public static void appendJavaScriptString(StringBuilder resultBuilder, String s) {
        resultBuilder.append('"')
            .append(s.replace("\\", "\\\\")
                    .replace("\n", "\\n")
                    .replace("\r", "\\r")
                    .replace("\t", "\\t")
                    .replace("\"", "\\\"")
                    .replace("'", "\\'"))
            .append('"');
    }
}
