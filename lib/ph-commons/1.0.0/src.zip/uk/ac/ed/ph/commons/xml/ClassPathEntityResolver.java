/* $Id: ClassPathEntityResolver.java 58 2008-08-03 19:29:15Z dmckain $
 *
 * Copyright (c) 2003 - 2007 University of Edinburgh.
 * All Rights Reserved
 */
package uk.ac.ed.ph.commons.xml;

import java.io.InputStream;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.xml.sax.EntityResolver;
import org.xml.sax.InputSource;

/**
 * Implementation of {@link EntityResolver} that tries to resolve entity references via the
 * {@link ClassLoader}.
 * 
 * @see uk.ac.ed.ph.commons.xml.FilesystemEntityResolver
 * 
 * @author  David McKain
 * @version $Revision: 58 $
 */
public class ClassPathEntityResolver implements EntityResolver {

    private static final Log log = LogFactory.getLog(ClassPathEntityResolver.class);

    /** Base of the URL scheme handled by this Resolver */
    private static final String URL_BASE = "http://";

    /** Resource Base directory */
    private String resourceBase;

    public ClassPathEntityResolver() {
        this(null);
    }

    public ClassPathEntityResolver(String resourceBase) {
        setResourceBase(resourceBase);
    }

    //-------------------------------------------

    /**
     * @return Returns the resourceBase.
     */
    public String getResourceBase() {
        return resourceBase;
    }

    /**
     * @param resourceBase The resourceBase to set.
     */
    public void setResourceBase(String resourceBase) {
        this.resourceBase = resourceBase;
    }

    /**
     * Called when it's time to extract an external entity. This
     * uses {@link #findClassPathEntity(String)} to see if it is available
     * locally. If so, an InputSource is returned configured with the
     * correct Public/System ID. If not, null is returned.
     */
    public InputSource resolveEntity(String publicId, String systemId) {
        if (log.isDebugEnabled()) {
            log.debug("resolveEntity(publicId=" + publicId + ",systemId=" + systemId + ")");
        }
        InputStream stream = findClassPathEntity(systemId);
        InputSource result = null;
        if (stream!=null) {
            result = new InputSource(stream);
            result.setPublicId(publicId);
            result.setSystemId(systemId);
            if (log.isDebugEnabled()) {
                log.debug("resolveEntity() succeeded; returning local copy of publicId=" + publicId
                        + ",systemId=" + systemId);
            }
        }
        else {
            log.debug("resolveEntity() could not resolve using ClassLoader; returning null");

        }
        return result;
    }


    /**
     * A request for System ID having URL of the form
     *
     * <code>http://server/path</code>
     *
     * is mapped to a resource of the form
     *
     * <code>[resourceBase]/server/path</code>
     *
     * <p>
     * If this resource is located by the ClassLoader then
     * an InputStream is returned, otherwise null is
     * returned.
     * <p>
     * Only <code>http://</code> System IDs are handled this way.
     */
    public InputStream findClassPathEntity(final String systemId) {
        if (log.isDebugEnabled()) {
            log.debug("findClasspathEntity(systemId=" + systemId + ")");
        }
        InputStream result = null;
        if (systemId.startsWith(URL_BASE)) {
            String relativeSystemId = systemId.substring(URL_BASE.length());
            String resourcePath = null;
            if (resourceBase==null || resourceBase.equals("")) {
                resourcePath = systemId;
            }
            else {
                resourcePath = resourceBase + "/" + relativeSystemId;
            }
            if (log.isDebugEnabled()) {
                log.debug("Looking for entity at " + resourcePath + " using ClassLoader");
            }
            ClassLoader loader = getClass().getClassLoader();
            result = loader.getResourceAsStream(resourcePath);
        }
        if (result==null && log.isDebugEnabled()) {
            log.debug("findClassPathEntity() couldn't find entity using ClassLoader");
        }
        return result;
    }
}
