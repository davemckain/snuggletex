/* $Id: StrategyFactoryConfigurationPropertiesLoader.java 58 2008-08-03 19:29:15Z dmckain $
 *
 * Copyright (c) 2003 - 2008 University of Edinburgh.
 * All Rights Reserved
 */
package uk.ac.ed.ph.commons.util;

import java.util.Properties;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * Helper class that can create a {@link StrategyFactoryConfiguration} from a properties file
 * loaded from the ClassPath.
 *
 * @author  David McKain
 * @version $Revision: 58 $
 */
public class StrategyFactoryConfigurationPropertiesLoader {

    private static final Log log = LogFactory.getLog(StrategyFactoryConfigurationPropertiesLoader.class);

    /**
     * Looks up the given properties file in the ClassPath and creates a
     * {@link StrategyFactoryConfiguration} that can then be used to instantiate
     * a {@link StrategyFactory}.
     *
     * @param propertiesClasspathLocation
     * @param strategyBaseClass
     * @param <S> type of strategyBaseClass
     */
    public static <S> StrategyFactoryConfiguration<String,S> loadStrategies(String propertiesClasspathLocation,
            Class<S> strategyBaseClass) {
        StrategyFactoryConfiguration<String,S> result = new StrategyFactoryConfiguration<String,S>();
        if (log.isDebugEnabled()) {
            log.debug("Trying to load StrategyFactoryConfiguration properties from properties file at "
                    + propertiesClasspathLocation + " in ClassPath");
        }
        Properties properties = new ConfigurationProperties(propertiesClasspathLocation).getProperties();
        String keyString;
        String className = null;
        try {
            Class<? extends S> strategyClass;
            for (Object key : properties.keySet()) {
                keyString = (String) key;
                className = properties.getProperty(keyString);
                strategyClass = Class.forName(className).asSubclass(strategyBaseClass);
                result.put(keyString, strategyClass);
                if (log.isDebugEnabled()) {
                    log.debug("Mapped strategy " + className + " to key " + keyString);
                }
            }
        }
        catch (ClassNotFoundException e) {
            throw new ConfigurationPropertyException("Strategy class "
                    + className + " could not be loaded");
        }
        catch (ClassCastException e) {
            throw new ConfigurationPropertyException("Strategy class "
                    + className + " is not a subclass of " + strategyBaseClass.getName());
        }
        return result;
    }
}
