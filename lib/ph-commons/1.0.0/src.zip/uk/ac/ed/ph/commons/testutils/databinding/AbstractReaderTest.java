/* $Id: AbstractReaderTest.java 58 2008-08-03 19:29:15Z dmckain $
 *
 * Copyright (c) 2003 - 2008 University of Edinburgh.
 * All Rights Reserved
 */
package uk.ac.ed.ph.commons.testutils.databinding;

import uk.ac.ed.ph.commons.databinding.AbstractMarshaller;
import uk.ac.ed.ph.commons.databinding.ReaderOptions;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;

import junit.framework.TestCase;

/**
 * Simple JUnit 3.x base class for testing simple reading of an Object.
 *
 * @author  David McKain
 * @version $Revision: 58 $
 */
public abstract class AbstractReaderTest<T> extends TestCase {

    /**
     * Subclasses should create the appropriate subclass of AbstractMarshaller
     * that they want to do the work with.
     */
    protected abstract AbstractMarshaller createMarshaller();

    /**
     * Subclasses should fill in to indicate whether the XML representation
     * of the object being tested is validatable.
     */
    protected abstract boolean isXMLValidatable();

    /**
     * Fill in to get the path to the XML sample file, which will be
     * fetched via the ClassLoader.
     * <p>
     * You can avoid the need for this by overriding
     * {@link #readSampleXML()}
     */
    protected abstract String getSampleXMLLocation()
        throws Exception;

    /**
     * Fill in to create a (valid) prototype object which will be filled in
     * by the Marshalling process.
     */
    protected abstract T createPrototypeObject()
        throws Exception;

    /**
     * Fill in to check parsed data against what you expect
     * to get from the XML sample file.
     */
    protected abstract void checkSampleData(T object)
        throws Exception;

    //--------------------------------------------------------------

    /**
     * First test is to ensure the Sample XML parses and
     * matches
     */
    public void testParseXMLValidating() throws Exception {
        if (isXMLValidatable()) {
            String xmlSample = readSampleXML();
            T result = parseXML(xmlSample, true);
            checkSampleData(result);
        }
    }

    /**
     * First test is to ensure the Sample XML parses and
     * matches
     */
    public void testParseXMLNonvalidating() throws Exception {
        String xmlSample = readSampleXML();
        T result = parseXML(xmlSample, false);
        checkSampleData(result);
    }

    //-------------------------------------------------------------

    /**
     * Reads in sample XML file from the ClassPath.
     */
    protected String readSampleXML() throws Exception {
        StringBuilder xml = new StringBuilder();
        String sampleLocation = getSampleXMLLocation();
        InputStream xmlSource = getClass().getClassLoader()
            .getResourceAsStream(sampleLocation);
        assertNotNull("Can't find sample XML at " + sampleLocation, xmlSource);
        BufferedReader reader = new BufferedReader(new InputStreamReader(xmlSource));
        String line;
        while ((line = reader.readLine())!=null) {
            xml.append(line);
        }
        return xml.toString();
    }

    protected T parseXML(String xmlString, boolean shouldValidate)
            throws Exception {
        T prototype = createPrototypeObject();
        createMarshaller().readObject(prototype, xmlString,
                shouldValidate ? ReaderOptions.READ_DTD_AND_VALIDATE : ReaderOptions.DO_NOT_READ_DTD);
        return prototype;
    }
}
