/* $Id: StrategyCreationException.java 58 2008-08-03 19:29:15Z dmckain $
 *
 * Copyright (c) 2003 - 2008 University of Edinburgh.
 * All Rights Reserved.
 */
package uk.ac.ed.ph.commons.util;

/**
 * Exception thrown by {@link StrategyFactory} when a strategy class cannot be created.
 * <p>
 * This is a {@link RuntimeException} as it indicates a coding/configuration error.
 *
 * @author  David McKain
 * @version $Revision: 58 $
 */
public class StrategyCreationException extends RuntimeException {

    private static final long serialVersionUID = 3763101859954505783L;

    public StrategyCreationException() {
        super();
    }

    public StrategyCreationException(String message) {
        super(message);
    }

    public StrategyCreationException(String message, Throwable cause) {
        super(message, cause);
    }

    public StrategyCreationException(Throwable cause) {
        super(cause);
    }

}
