/* $Id: LambdaMap.java 58 2008-08-03 19:29:15Z dmckain $
 *
 * Copyright (c) 2003 - 2008 University of Edinburgh.
 * All Rights Reserved.
 */
package uk.ac.ed.ph.commons.util;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

/**
 * Simple implementation of Perl's <code>map</code> operator,
 * which applies a function to each element in a Collection to
 * produce a new Collection.
 * <p>
 * This isn't going to be high-performance but can be very
 * handy for unit testing and such-like!
 * 
 * @param <X> type of Object that <tt>lambda</tt> is applied to
 * @param <Y> resulting type of <tt>lambda(x)</tt> for each x in X.
 *
 * @author  David McKain
 * @version $Revision: 58 $
 */
public abstract class LambdaMap<X,Y> {

    /**
     * Subclasses should fill in to provide the function to apply to each element.
     *
     * @param x value of X to apply lambda to
     * @return value of <code>lambda(X)</code>
     */
    public abstract Y lambda(X x);

    /**
     * Applies the map to each element of the given Collection
     * xCollection, returning a List of the same size.
     *
     * @param xCollection
     * @return List where each element of <code>xCollection</code>
     *   has had lambda applied to it.
     */
    public List<Y> apply(Collection<X> xCollection) {
        ArrayList<Y> result = new ArrayList<Y>(xCollection.size());
        for (X xItem : xCollection) {
            result.add(lambda(xItem));
        }
        return result;
    }

    /**
     * Applies the map to each element of the given array,
     * returning a List of the same size.
     *
     * @param xArray
     * @return array where each element of <code>xCollection</code>
     *   has had lambda applied to it.
     */
    public List<Y> apply(X [] xArray) {
        ArrayList<Y> result = new ArrayList<Y>(xArray.length);
        for (X xItem : xArray) {
            result.add(lambda(xItem));
        }
        return result;
    }
}
