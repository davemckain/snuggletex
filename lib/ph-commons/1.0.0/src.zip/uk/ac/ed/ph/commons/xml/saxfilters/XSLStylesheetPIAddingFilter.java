/* $Id:XSLStylesheetPIAddingFilter.java 2824 2008-08-01 15:46:17Z davemckain $
 *
 * Copyright (c) 2003 - 2008 University of Edinburgh.
 * All Rights Reserved
 */
package uk.ac.ed.ph.commons.xml.saxfilters;

import org.xml.sax.SAXException;

/**
 * Trivial SAX filter that adds a processing instruction to the outgoing stream
 * specifying that one or more client-side XSLT stylesheet should be applied.
 *
 * @author  David McKain
 * @version $Revision:2824 $
 */
public class XSLStylesheetPIAddingFilter extends XMLLexicalFilterImpl {
    
    private static final char[] NEWLINE_CHARS = { '\n' };
    
    private final String[] stylesheetUrls;

    public XSLStylesheetPIAddingFilter(String... stylesheetUrls) {
        this.stylesheetUrls = stylesheetUrls;
    }
    
    @Override
    public void startDocument() throws SAXException {
        /* Let document start as normal */
        super.startDocument();
        /* Then immediately add the correct processing instruction(s) */
        String data;
        for (String stylesheetUrl : stylesheetUrls) {
            data = "type=\"text/xsl\" href=\"" + stylesheetUrl + "\""; 
            super.processingInstruction("xml-stylesheet", data);
            super.characters(NEWLINE_CHARS, 0, NEWLINE_CHARS.length);
        }
    }
}
