/* $Id: FilesystemEntityResolver.java 58 2008-08-03 19:29:15Z dmckain $
 *
 * Copyright (c) 2003 - 2008 University of Edinburgh
 * University of Edinburgh. All Rights Reserved
 */
package uk.ac.ed.ph.commons.xml;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.xml.sax.EntityResolver;
import org.xml.sax.InputSource;

/**
 * Simple implementation {@link EntityResolver} that tries to resolve requests for
 * external entities in the local filesystem.
 * <p>
 * See {@link #findLocalEntity(String)} to see the mechanism in which
 * this works.
 *
 * @see uk.ac.ed.ph.commons.xml.ClassPathEntityResolver
 *
 * @author  David McKain
 * @version $Revision: 58 $
 */
public final class FilesystemEntityResolver implements EntityResolver {

    private static final Log log = LogFactory.getLog(FilesystemEntityResolver.class);

    /** Base of the URL scheme handled by this Resolver */
    private static final String URL_BASE = "http://";

    /** Base directory to check for files in */
    private File localBaseDirectory;

    public FilesystemEntityResolver(File newBaseDirectory) {
        setLocalBaseDirectory(newBaseDirectory);
    }

    public File getLocalBaseDirectory() {
        return localBaseDirectory;
    }

    /**
     * Sets the base directory in which this EntityResolver will
     * look for files in.
     *
     * @param newBaseDirectory
     */
    public void setLocalBaseDirectory(File newBaseDirectory) {
        this.localBaseDirectory = newBaseDirectory;
    }

    /**
     * Called when it's time to extract an external entity. This
     * uses {@link #findLocalEntity(String)} to see if it is available
     * locally. If so, an InputSource is returned configured with the
     * correct Public/System ID. If not, null is returned.
     */
    public InputSource resolveEntity(String publicId, String systemId) {
        if (log.isDebugEnabled()) {
            log.debug("resolveEntity(publicId=" + publicId + ",systemId=" + systemId + ")");
        }
        InputStream stream = findLocalEntity(systemId);
        InputSource result = null;
        if (stream!=null) {
            result = new InputSource(stream);
            result.setPublicId(publicId);
            result.setSystemId(systemId);
            if (log.isDebugEnabled()) {
                log.debug("resolveEntity() succeeded; returning local copy of publicId=" + publicId
                        + ",systemId=" + systemId);
            }
        }
        else {
            log.debug("resolveEntity() could not resolve locally; returning null");

        }
        return result;
    }

    /**
     * A request for System ID having URL of the form
     *
     * <code>http://server/path</code>
     *
     * is mapped to a file URL
     *
     * <code>file://[base directory]/server/path</code>.
     *
     * <p>
     * If this local URL exists then its contents are served as
     * an InputStream, otherwise null if returned.
     * <p>
     * Only <code>http://</code> System IDs are handled this way.
     */
    public InputStream findLocalEntity(String systemId) {
        if (log.isDebugEnabled()) {
            log.debug("findLocalEntity(systemId=" + systemId + ")");
        }
        InputStream result = null;
        if (systemId.startsWith(URL_BASE)) {
            if (localBaseDirectory != null) {
                File localFile = new File(localBaseDirectory, systemId.substring(URL_BASE.length()));
                try {
                    if (log.isDebugEnabled()) {
                        log.debug("Looking for entity locally at " + localFile);
                    }
                    result = new FileInputStream(localFile);
                    if (log.isDebugEnabled()) {
                        log.debug("findLocalEntity() found System ID locally as " + localFile);
                    }
                }
                catch (FileNotFoundException e) {
                    /* Fall through and return null */
                }
            }
            else {
                log.warn("Base directory for local entity resolution is not set");
            }
        }
        if (result==null && log.isDebugEnabled()) {
            log.debug("findLocalEntity() couldn't resolve locally");
        }
        return result;
    }
}