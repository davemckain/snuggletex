/* $Id:MappingFilterCallback.java 2824 2008-08-01 15:46:17Z davemckain $
 *
 * Copyright (c) 2003 - 2008 University of Edinburgh.
 * All Rights Reserved
 */
package uk.ac.ed.ph.commons.xml.saxfilters;

/**
 * This interface is used by {@link MappingFilter} when Text or Attribute Nodes matched by
 * {@link MappingFilterMatcher} are encountered.
 *
 * @author  David McKain
 * @version $Revision:2824 $
 */
public interface MappingFilterCallback {

    /**
     * Called at the start of the document. Implementors may use this to build up internal state
     * (e.g. if they are making a list of everything that matched) if required.
     */
    void onStartDocument();
    
    /**
     * Called when an interesting Text Node is found. Implementors should do what they want with
     * the details and return new content for the text Node (which may of course be the same
     * as the existing content).
     * 
     * @param elementNamespaceUri
     * @param elementLocalName
     * @param elementContent
     * 
     * @return replacement content, which must not be null.
     */
    String mapTextElementContent(String elementNamespaceUri, String elementLocalName, String elementContent);
    
    /**
     * Called when an interesting Attribute Node has been found. Implementors should do what they
     * want with the details and return new content for the Attribute Node (which may of course
     * be the same as the existing content), or return null to indicate that the Attribute should
     * be dropped.
     * 
     * @param elementNamespaceUri
     * @param elementLocalName
     * @param attributeNamespaceUri
     * @param attributeLocalName
     * @param attributeValue
     * @return replacement Attribute value, or null to drop this attribute.
     */
    String mapAttribute(String elementNamespaceUri, String elementLocalName, String attributeNamespaceUri, String attributeLocalName, String attributeValue);
    
    /**
     * Called when an interesting processing instruction has been found. Implementors should do
     * whatever they want to do with the given PI target and data, returning a replacement value
     * for the data.

     * @param target PI target
     * @param data PI data
     * 
     * @return replacement for the PI data
     */
    String mapProcessingInstructionData(String target, String data);
    
    /**
     * Called at the end of the document. 
     */
    void onEndDocument();
}