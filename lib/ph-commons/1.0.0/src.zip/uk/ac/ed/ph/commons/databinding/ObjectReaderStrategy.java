/* $Id: ObjectReaderStrategy.java 58 2008-08-03 19:29:15Z dmckain $
 *
 * Copyright (c) 2003 - 2008 University of Edinburgh.
 * All Rights Reserved
 */
package uk.ac.ed.ph.commons.databinding;

import org.xml.sax.ContentHandler;

/**
 * Interface for classes that reconstruct the state of a particular
 * class of Object from XML.
 * <p>
 * You should create an implementation of this interface for each Class
 * of Object being read in.
 * <p>
 * An instance of this class will created and reused by a single Thread.
 * Therefore, instances should be reusable but not thread-safe.
 * <p>
 * You will normally want to use one of the convenience subclasses of this
 * which apply in almost all scenarios.
 *
 * @author  David McKain
 * @version $Revision: 58 $
 */
public interface ObjectReaderStrategy<E> extends ContentHandler {

    /**
     * Sets the Object that is to be filled in. This occurs before any other
     * method in this interface. The Object may not necessarily be clear.
     *
     * @param object
     */
    void setResult(E object);

    /**
     * Sets the AbstractMarshaller instance that created this strategy. This happens
     * before parsing and allows the strategy to call back on the AbstractMarshaller
     * in case embedded Objects need to be read.
     *
     * @param marshaller
     */
    void setMarshaller(AbstractMarshaller marshaller);

    /**
     * Called just before parsing starts. Subclasses should use this opportunity to
     * set up internal state as appropriate and clear the result Object.
     */
    void init();

    /**
     * Called once parsing has finished or after an error. Subclasses should
     * clear up any state built during parsing so that the strategy can be
     * reused.
     * <p>
     * <strong>Note:</strong> This is currently not necessary in its present
     * form as we are no longer caching strategies, but it's good housekeeping
     * to have and may return in future.
     */
    void reset();
}
