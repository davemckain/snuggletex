/* $Id: LambdaFilter.java 72 2008-08-12 11:14:40Z dmckain $
 *
 * Copyright (c) 2003 - 2008 University of Edinburgh.
 * All Rights Reserved.
 */
package uk.ac.ed.ph.commons.util;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

/**
 * Simple implementation of the common functional <code>filter</code> operator
 * (in Haskell for example), which filters a List or array according to some
 * boolean condition function.
 * 
 * @param <X> type of Object that this filter works on
 *
 * @author  David McKain
 * @version $Revision: 72 $
 */
public abstract class LambdaFilter<X> {

    /**
     * Subclasses should fill in to indicate whether to accept
     * a given value X in the List or array being filtered.
     *
     * @param x value of X to accept of reject
     * @return true to accept, false to reject.
     */
    public abstract boolean accept(X x);

    /**
     * Applies the map to each element of the given Collection
     * xCollection, returning a List of the same size.
     *
     * @param xCollection
     * @return List containing those elements in xCollection which
     *   were accepted.
     */
    public List<X> apply(Collection<X> xCollection) {
        ArrayList<X> result = new ArrayList<X>(xCollection.size());
        for (X item : xCollection) {
            if (accept(item)) {
                result.add(item);
            }
        }
        return result;
    }

    /**
     * Applies the map to each element of the given array,
     * returning a List of those items which were accepted.
     *
     * @param xArray
     * @return array where each element of <code>xCollection</code>
     *   has had lambda applied to it.
     */
    public List<X> apply(X[] xArray) {
        ArrayList<X> result = new ArrayList<X>(xArray.length);
        for (X item : xArray) {
            if (accept(item)) {
                result.add(item);
            }
        }
        return result;
    }
}
