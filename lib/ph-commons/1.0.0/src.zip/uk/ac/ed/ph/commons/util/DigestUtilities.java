/* $Id:DigestUtilities.java 2824 2008-08-01 15:46:17Z davemckain $
 *
 * Copyright (c) 2003 - 2008 University of Edinburgh.
 * All Rights Reserved
 */
package uk.ac.ed.ph.commons.util;

import static java.lang.System.err;
import static java.lang.System.exit;
import static java.lang.System.out;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

/**
 * This class contains some utility methods for handling digested Strings. This is useful for
 * managing digested passwords and stuff.
 *
 * @author  David McKain
 * @version $Revision:2824 $
 */
public final class DigestUtilities {

    public static char[] HEX_DIGITS = { '0', '1', '2', '3', '4', '5', '6', '7',
                                        '8', '9', 'a', 'b', 'c', 'd', 'e', 'f' };

    /**
     * Digests the given String s using the given digest algorithm, encoding the result as a
     * (lower case) hex String.
     * 
     * @param s String to digest.
     * @param digestAlgorithm digest algorithm to use.
     *
     * @return digest of the given String, encoded as a hex string.
     *
     * @throws NoSuchAlgorithmException if the given digest algorithm doesn't exist.
     */
    public static String computeHexEncodedDigest(String s, String digestAlgorithm) throws NoSuchAlgorithmException {
        MessageDigest md = MessageDigest.getInstance(digestAlgorithm);
        md.update(s.getBytes());
        byte[] bytes = md.digest();
        md.reset();
        
        return hexEncode(bytes);
    }

    /**
     * Trivial helper to encode the given array of bytes as a (lower case) hex String.
     * 
     * @param bytes
     * @return hex String whose length will be 2 * bytes.length
     */
    public static String hexEncode(byte[] bytes) {
        char[] asHex = new char[bytes.length * 2];
        int byteCount, hexCount;
        int b, high, low;
        for (byteCount=0, hexCount=0; byteCount<bytes.length; ) {
            b = bytes[byteCount++] & 0xff;
            high = b >> 4;
            low  = b & 0x0f;
            asHex[hexCount++] = HEX_DIGITS[high];
            asHex[hexCount++] = HEX_DIGITS[low];
        }
        return new String(asHex);
    }
    
    //----------------------------------------------------------------------

    /**
     * Convenience main method that allows a String and digestMethod to be passed on the command
     * line for digesting. This can be quite useful at times.
     * <p>
     * You can also run with the '-i' option to run interactively.
     *
     * @param args
     * @throws IOException 
     */
    public static void main(String[] args) throws IOException {
        String str = null;
        String digestAlgorithm = null;
        if (args.length==1 && args[0].startsWith("-i")) {
            BufferedReader in = new BufferedReader(new InputStreamReader(System.in));
            out.println("Please enter String to digest:");
            out.flush();
            str = in.readLine();
            out.println("Please enter digest algorithm (e.g. sha1):");
            out.flush();
            digestAlgorithm = in.readLine();
        }
        else if (args.length==2) {
            str = args[0];
            digestAlgorithm = args[1];
        }
        else {
            err.println("Please either supply arguments <string> <digestMethod>\n"
                    + "or run interactively with '-i' option");
            exit(1);
        }
        try {
            out.println(computeHexEncodedDigest(str, digestAlgorithm));
        }
        catch (NoSuchAlgorithmException e) {
            err.println("Unknown digest algorithm " + digestAlgorithm);
            exit(1);
        }
    }
}
