/* $Id: HashMapDAOBase.java 58 2008-08-03 19:29:15Z dmckain $
 *
 * Copyright (c) 2003 - 2008 University of Edinburgh.
 * All Rights Reserved
 */
package uk.ac.ed.ph.commons.util;

import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

/**
 * Cheap and nasty base class for creating Data Access Objects based on plain-old {@link HashMap}s.
 * These can be useful in testing/mock situations if the data is essentially <tt>(key,value)</tt>
 * tuples with a simple primary key and no further constraints.
 * <p>
 * Subclasses should override, fill in missing methods and add more friendly public methods.
 * <p>
 * Note that all values are put through {@link #clone(Object)} on load/store to ensure that
 * the data in the Map behaves in a database-like way. Bear that in mind, though!
 * 
 * @param <K> type of primary key to store
 * @param <V> type of value to store
 * @param <E> Exception class to be thrown when an entry exists when it is assumed that it doesn't
 * @param <N> Exception class to be thrown when an entry doesn't exist when it is assumed that it does
 *
 * @author  David McKain
 * @version $Revision: 58 $
 */
public abstract class HashMapDAOBase<K, V, E extends Exception, N extends Exception> {
    
    /** Actual data store */
    private final Map<K,V> dataMap;
    
    public HashMapDAOBase() {
        this.dataMap = new HashMap<K,V>();
    }
    
    protected final V findByKey(K key) {
        ConstraintUtilities.ensureNotNull(key);
        V value = dataMap.get(key);
        return value!=null ? clone(value) : null;
    }
    
    protected final Collection<V> findByKeys(K... keys) {
        Set<V> result = new HashSet<V>();
        for (K key : keys) {
            V user = findByKey(key);
            if (user!=null) {
                result.add(user);
            }
        }
        return result;
    }

    protected final Collection<V> getValues() {
        Set<V> result = new HashSet<V>(dataMap.size());
        for (V user : dataMap.values()) {
            result.add(clone(user));
        }
        return result;
    }

    protected final void create(K key, V value) throws E {
        ConstraintUtilities.ensureNotNull(key);
        ConstraintUtilities.ensureNotNull(value);
        if (dataMap.containsKey(key)) {
            throw createExistsException(key);
        }
        dataMap.put(key, clone(value));
    }

    protected final void delete(K key) throws N {
        ConstraintUtilities.ensureNotNull(key);
        if (!dataMap.containsKey(key)) {
            throw createNotExistsException(key);
        }
        dataMap.remove(key);
    }
    
    protected final void update(K key, V value) throws N {
        ConstraintUtilities.ensureNotNull(key);
        ConstraintUtilities.ensureNotNull(value);
        if (!dataMap.containsKey(key)) {
            throw createNotExistsException(key);
        }
        dataMap.put(key, clone(value));
    }
    
    //------------------------------------------------------
    
    protected abstract E createExistsException(K key);
    
    protected abstract N createNotExistsException(K key);
    
    /**
     * Subclasses should fill in to create a proper clone of the given value, which will never
     * be null.
     */
    protected abstract V clone(V value);
}
