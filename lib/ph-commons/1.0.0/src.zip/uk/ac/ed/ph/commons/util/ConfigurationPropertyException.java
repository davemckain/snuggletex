/* $Id: ConfigurationPropertyException.java 58 2008-08-03 19:29:15Z dmckain $
 *
 * Copyright (c) 2003 - 2008 University of Edinburgh.
 * All Rights Reserved
 */
package uk.ac.ed.ph.commons.util;

/**
 * Simple Exception class used by {@link ConfigurationProperties}
 * to indicate that Properties either cannot be loaded or a required
 * key does not exist.
 * <p>
 * This is a RuntimeException since this is usually a programmer or
 * deployment problem which cannot be fixed.
 *
 * @author  David McKain
 * @version $Revision: 58 $
 */
public class ConfigurationPropertyException extends RuntimeException {

    private static final long serialVersionUID = 140392820398L;

    public ConfigurationPropertyException() {
        super();
    }

    public ConfigurationPropertyException(String message) {
        super(message);
    }

    public ConfigurationPropertyException(String message, Throwable cause) {
        super(message, cause);
    }

    public ConfigurationPropertyException(Throwable cause) {
        super(cause);
    }
}
