/* $Id: SimpleReaderStrategy.java 58 2008-08-03 19:29:15Z dmckain $
 *
 * Copyright (c) 2003 - 2008 University of Edinburgh.
 * All Rights Reserved
 */
package uk.ac.ed.ph.commons.databinding;

import uk.ac.ed.ph.commons.xml.XMLUtilities;

import java.io.StringReader;
import java.io.StringWriter;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;

import javax.xml.transform.OutputKeys;
import javax.xml.transform.Templates;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.sax.SAXTransformerFactory;
import javax.xml.transform.sax.TransformerHandler;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.stream.StreamSource;

import org.xml.sax.Attributes;
import org.xml.sax.ContentHandler;
import org.xml.sax.Locator;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.AttributesImpl;

/**
 * This is a simple implementation of {@link ObjectReaderStrategy} that adapts
 * SAX {@link ContentHandler} events into simpler events that can be more easily handled:
 *
 * <ul>
 *   <li>Text elements</li>
 *   <li>Container elements</li>
 *   <li>Islands of mixed content</li>
 *   <li>Embedded object XML fragments</li>
 * </ul>
 *
 * This covers most common marshalling cases, though there are some limitations as
 * described below.
 *
 * <h2>Example XML</h2>
 *
 * <![CDATA[
 *
 * <ns:root xmlns:ns="urn:blah">
 *   <ns:text>This is a text element</ns:text>
 *   <ns:container id="wendy">
 *     <ns:name>Some name</ns:name>
 *     <ns:value>Some value</ns:value>
 *   </ns:container>
 *   <ns:mixed xmlns="http://www.w3.org/1999/xhtml">
 *     This is some <i>HTML mixed content</i>
 *   </ns:mixed>
 *   <a:embedded-object>
 *     ...
 *   </a:embedded-object>
 * </ns:root>
 *
 * ]]>
 *
 * This example has:
 *
 * <ul>
 *   <li>Container Elements (ns:root, ns:container)</li>
 *   <li>Text Elements (ns:text, ns:name, ns:value)</li>
 *   <li>Mixed Content Elements (ns:mixed)</li>
 *   <li>Embedded Object Fragments/Foreign XML (a:embedded-object)</li>
 * </ul>
 *
 * To read this type of XML, you create a subclass of this abstract class that firstly
 * registers each type of element as above. You MUST register all elements you expect
 * to find - a {@link DataBindingException} will be thrown if you don't.
 * <p>
 * When parsing, the reader converts raw SAX events into more useful information. In particular:
 *
 * <ul>
 *   <li>
 *     You get told about the start and end of a container element via the
 *     {@link #startContainerElement(String, String, Attributes)} and
 *     {@link #endContainerElement(String, String)} callbacks
 *   </li>
 *   <li>
 *     You get told when a text element has finished via the
 *     {@link #textElement(String, String, Attributes, String)} callback.
 *     This gives you the Namespace, local name, Attributes and text content.
 *   </li>
 *   <li>
 *     You get told when a mixed content element has been read in via the
 *     {@link #mixedContent(String, String, Attributes, String)} callback.
 *     You will be told the Namespaces of the delimiting element, its local name,
 *     Attributes and also the inner XML fragment as a UTF-8 String. (E.g. the <ns:mixed>
 *     above would give you the fragment
 *     "This is some <i xmlns="http://www.w3.org/1999/xhtml">HTML mixed content</i>"
 *     (with some whitespace at the start and end).
 *   </li>
 *   <li>
 *     When an embedded object is encountered, the class asks the owning {@link AbstractMarshaller}
 *     to try to read it in and asks you to provide a prototype Object to fill using the
 *     {@link #createEmbeddedObjectPrototype(String, String)} method.
 *     When the Object has been read in, you get told about the object that was read
 *     via the {@link #embeddedObject(Object, String, String)} callback.
 *   </li>
 * </ul>
 *
 * <h2>How to Use</h2>
 *
 * Subclass this (or the convenience subclass {@link DefaultReaderStrategy}) by filling in
 * all of the abstract methods:
 * <ul>
 *   <li>
 *     You must register details about all Elements you expect to find.
 *   </li>
 *   <li>
 *     You should implement {@link #setResult(Object)} and store this Object reference.
 *     (You may also want to clear the state of the Object provided before parsing, though
 *     that can wait until the first callback.)
 *   </li>
 *   <li>
 *   <li>
 *     You should fill in the appropriate callback elements to reconstruct
 *     the Object as required.
 *   </li>
 *   <li>
 *     Override {@link #reset()} to clear up any internal state before and after parsing.
 *   </li>
 * </ul>
 *
 * Note that the Object you have to fill in <strong>MAY ALREADY HAVE BEEN USED</strong> so
 * needs cleared during parsing. You can either do this at {@link #setResult(Object)} or
 * when you handle the outer element.
 * <p>
 * Each Reader class must be serially reusable.
 *
 * <h2>Limitations</h2>
 *
 * <ul>
 *   <li>
 *     The "registration" technique means you cannot have an element's type is defined by
 *     its name. So you cannot have both a text Element and a container Element with the
 *     same name.
 *   </li>
 *   <li>
 *     The design of this class is arguably poor as it adapts the interface too much and is
 *     better done by delegation rather than inheritance. But subclassing works better
 *     with strategy factory registration so I think this is the best option here.
 *   </li>
 * </ul>
 *
 * @see SimpleWriterStrategy
 *
 * @author  David McKain
 * @version $Revision: 58 $
 */
public abstract class SimpleReaderStrategy<E> implements ObjectReaderStrategy<E> {

    //-------------------------------------------------------

    /*
     * Implementation Notes
     *
     * I've decided to split parsing into 4 states, as this makes it easier to
     * describe. The default state is STATE_DEFAULT.
     *
     * In STATE_DEFAULT, when a container element is started or ended, this is
     * reported and parsing continues. Characters are not allowed in this mode
     * as it indicates that the subclass has not registered text elements
     * correctly. All other SAX Events are ignored.
     *
     * in STATE_DEFAULT, when a text element, embedded object element or mixed
     * content element starts, we change state to one of the constants listed
     * below. The current attributes are saved, as is the local name and NS of
     * the element just opened.
     *
     * When in a state other than STATE_DEFAULT, SAX Events will cause different
     * things to happen depending on the state.
     *
     * The state changes back to STATE_DEFAULT when the previously saved element
     * ends. (This is the element that originally caused the mode to change).
     */

    private static final int STATE_DEFAULT = 0;
    private static final int STATE_GATHERING_TEXT = 1;
    private static final int STATE_READING_EMBEDDED_OBJECT = 2;
    private static final int STATE_READING_MIXED_CONTENT = 3;

    /** Current parsing state */
    private int state;

    /** Local name of element marking last transition to non-default state */
    private String lastElementLocalName;

    /** Namespace of element marking last transition to non-default state */
    private String lastElementNamespace;

    /** Attributes of element marking last transition to non-default state */
    private Attributes lastElementAttributes;

    //-------------------------------------------------------

    /** Map of container Elements understood by this reader */
    private ElementMap containerElements;

    /** Map of text Element understood by this reader */
    private ElementMap textElements;

    /** Map of embedded object Elements understood by this reader */
    private ElementMap embeddedObjectElements;

    /** Map of mixed content containers understood by this reader */
    private ElementMap mixedContentContainerElements;

    //-------------------------------------------------------

    /**
     * AbstractMarshaller that created this, required when coping with
     * embedded objects.
     */
    private AbstractMarshaller marshaller;

    /**
     * Text buffer used for accumulating character data, null initially
     * but reused afterwards.
     */
    private StringBuilder textBuffer;
    
    /**
     * Currently in-scope prefix mappings. Used to pass information down to embeddings or
     * mixed content mappings so is only used if such things are registered.
     */
    private Map<String, String> prefixToUriMap;

    /**
     * TransformerHandler that will serialize the XML fragments when gathering mixed content,
     * null if we are not currently gathering mixed content.
     */
    private TransformerHandler mixedContentHandler;

    /**
     * {@link SAXTransformerFactory} used to create serializers for islands of mixed content,
     * initialised when first required.
     */
    private SAXTransformerFactory saxTransformerFactory;
    
    /**
     * {@link Templates} used by mixed content reader to unwrap wrapped up document fragments,
     * initialised when first required.
     */
    private Templates mixedContentUnwrapperXsltTemplate;

    /**
     * Writer that serialized XML fragments will be accumulated in when gathering mixed content.
     * This is null initially but its underlying buffer will be reused afterwards.
     */
    private StringWriter mixedContentWriter;

    /** Embedded object currently being read in (where appropriate) */
    private Object embeddedObject;

    /**
     * Strategy to forward embedded object events to (to enable building embedded objects),
     * null if we are not currently reading an embedded object.
     */
    private ObjectReaderStrategy<?> embeddedObjectReader;

    //-------------------------------------------------------
    // Implementation of ObjectReaderStrategy.

    public final void setMarshaller(AbstractMarshaller marshaller) {
        this.marshaller = marshaller;
    }

    private void resetAccumulatorState() {
        this.prefixToUriMap = null;
        this.textBuffer = null;
        this.saxTransformerFactory = null;
        this.mixedContentUnwrapperXsltTemplate = null;
        this.mixedContentHandler = null;
        this.mixedContentWriter = null;
        this.embeddedObjectReader = null;
        this.embeddedObject = null;
        this.state = STATE_DEFAULT;
    }

    //-------------------------------------------------------
    // SAX Callbacks live here

    public final void init() {
        resetAccumulatorState();
        resetState();
        clearResultObject();

        /* Find out about the elements we'll be reading in */
        this.containerElements = getContainerElements();
        this.textElements = getTextElements();
        this.embeddedObjectElements = getEmbeddedObjectElements();
        this.mixedContentContainerElements = getMixedContentContainerElements();
        
        /* Decide whether we need top record prefix mapping info or not */
        if (embeddedObjectElements!=null || mixedContentContainerElements!=null) {
            this.prefixToUriMap = new HashMap<String, String>();
        }
    }

    public final void reset() {
        resetAccumulatorState();
        resetState();
        setResult(null);
    }

    public void startDocument() {
    }

    public void endDocument() {
    }

    public final void startElement(String uri, String localName, String qName, Attributes attrs) throws SAXException {
        switch (state) {
            case STATE_DEFAULT:
                /* See if we are starting text, embedded object or mixed content */
                if (containerElements!=null && containerElements.contains(uri, localName)) {
                    /* It's a container so let subclass deal as it may require initialisation */
                    startContainerElement(uri, localName, attrs);
                }
                else if (mixedContentContainerElements!=null && mixedContentContainerElements.contains(uri, localName)) {
                    /* Start gathering mixed content */
                    setupMixedContentHandler();
                    changeState(STATE_READING_MIXED_CONTENT, uri, localName, attrs);
                }
                else if (textElements!=null && textElements.contains(uri, localName)) {
                    /* Text element; keep hold of attributes and start gathering text */
                    setupTextGathering();
                    changeState(STATE_GATHERING_TEXT, uri, localName, attrs);
                }
                else if (embeddedObjectElements!=null && embeddedObjectElements.contains(uri, localName)) {
                    /* Start of an embedded object - ask subclass for prototype and read in */
                    setupEmbeddedObjectHandler(uri, localName);
                    embeddedObjectReader.startElement(uri, localName, qName, attrs);
                    changeState(STATE_READING_EMBEDDED_OBJECT, uri, localName, attrs);
                }
                else {
                    throw new DataBindingException("Did not expect element with URI=" + uri
                            + ", localName=" + localName);
                }
                break;

            case STATE_GATHERING_TEXT:
                /* We're supposed to be inside a text element */
                throw new SAXException("Did not expect start of element with URI=" + uri
                        + ", localName=" + localName + " inside a supposed text element");

            case STATE_READING_EMBEDDED_OBJECT:
                /* We're currently reading an embedded object */
                embeddedObjectReader.startElement(uri, localName, qName, attrs);
                break;

            case STATE_READING_MIXED_CONTENT:
                /* We're reading XML island */
                mixedContentHandler.startElement(uri, localName, qName, attrs);
                break;

            default:
                throw new IllegalStateException("Unexpected state " + state);
        }
    }


    public final void endElement(String uri, String localName, String qName) throws SAXException {
        switch (state) {
            case STATE_DEFAULT:
                /* This is just the end of a container element */
                endContainerElement(uri, localName);
                break;

            case STATE_GATHERING_TEXT:
                /* This must be the end of the element contains the text Nodes we've been reading */
                textElement(uri, localName, lastElementAttributes, textBuffer.toString());
                textBuffer.setLength(0);
                changeState(STATE_DEFAULT);
                break;

            case STATE_READING_EMBEDDED_OBJECT:
                embeddedObjectReader.endElement(uri, localName, qName);
                /* See whether we have got to the end of the object */
                if (uri.equals(lastElementNamespace) && localName.equals(lastElementLocalName)) {
                    for (String prefix : prefixToUriMap.keySet()) {
                        embeddedObjectReader.endPrefixMapping(prefix);
                    }
                    embeddedObjectReader.endDocument();
                    embeddedObject(embeddedObject, uri, localName);
                    embeddedObjectReader = null;
                    embeddedObject = null;
                    changeState(STATE_DEFAULT);
                }
                break;

            case STATE_READING_MIXED_CONTENT:
                /* Are we at the end of the mixed content container? */
                if (uri.equals(lastElementNamespace) && localName.equals(lastElementLocalName)) {
                    /* OK then, close the fragment and record what we found */
                    String fragment = clearMixedContentHandler();
                    mixedContent(uri, localName, lastElementAttributes, fragment);
                    changeState(STATE_DEFAULT);
                }
                else {
                    mixedContentHandler.endElement(uri, localName, qName);
                }
                break;

            default:
                throw new IllegalStateException("Unexpected state " + state);
        }
    }
    
    /**
     * Simple XSLT stylesheet for stripping the root element from incoming XML.
     * 
     * @see #setupMixedContentHandler()
     */
    private static final String XML_ROOT_ELEMENT_STRIPPER_XSLT =
        "<transform xmlns='http://www.w3.org/1999/XSL/Transform' version='1.0'>\n"
        + "<template match='/*'><copy-of select='node()'/></template>\n"
        + "</transform>";

    /**
     * Helper method to set up the ContentHandler for gathering mixed content data.
     * <p>
     * The incoming mixed content data will be fired off inside a new fake root element to
     * ensure that its handler gets a proper XML document rather than fragments.
     * (Saxon 8.9 didn't handle raw fragments properly.) We strip the fake root by using a 
     * custom XSLT serializer using {@link #XML_ROOT_ELEMENT_STRIPPER_XSLT}.
     *
     * @throws SAXException
     * 
     * @see #clearMixedContentHandler()
     */
    private void setupMixedContentHandler() throws SAXException {
        if (saxTransformerFactory==null) {
            saxTransformerFactory = marshaller.getXMLFactory().createSAXTransformerFactory();
        }
        try {
            /* Create special serializer that strips out our fake root element */
            if (mixedContentUnwrapperXsltTemplate==null) {
                mixedContentUnwrapperXsltTemplate = saxTransformerFactory.newTemplates(
                        new StreamSource(new StringReader(XML_ROOT_ELEMENT_STRIPPER_XSLT)));
            }
            mixedContentHandler = saxTransformerFactory.newTransformerHandler(mixedContentUnwrapperXsltTemplate);
        }
        catch (TransformerConfigurationException e) {
            throw new DataBindingException("Could not create serializer for mixed content", e);
        }
        /* Set up buffer for accumulating resulting XML */
        if (mixedContentWriter==null) {
            mixedContentWriter = new StringWriter();
        }
        else {
            mixedContentWriter.getBuffer().setLength(0);
        }
        /* Set up transform */
        mixedContentHandler.setResult(new StreamResult(mixedContentWriter));
        mixedContentHandler.getTransformer().setOutputProperty(OutputKeys.OMIT_XML_DECLARATION, "yes");
        
        /* Now fire initial SAX events at handler to start the resulting document, fire off
         * the currently in-scope prefix mappings and create a fake root element.
         */
        mixedContentHandler.startDocument();
        for (Entry<String,String> entry : prefixToUriMap.entrySet()) {
            mixedContentHandler.startPrefixMapping(entry.getKey(), entry.getValue());
        }
        mixedContentHandler.startElement("", "root", "root", XMLUtilities.EMPTY_ATTRIBUTES);
    }

    /**
     * Helper method to finish accumulating mixed content, get the final result and
     * clear the handler for next time.
     *
     * @return UTF-8 XML fragment
     * @throws SAXException
     * 
     * @see #setupMixedContentHandler()
     */
    private String clearMixedContentHandler() throws SAXException {
        /* Shut down the mixed content gathering document in the reverse order we started it in */
        mixedContentHandler.endElement("", "root", "root");
        for (String prefix : prefixToUriMap.keySet()) {
            mixedContentHandler.endPrefixMapping(prefix);
        }
        mixedContentHandler.endDocument();
        mixedContentHandler = null;
        
        /* Now pull out resulting XML */
        StringBuffer xmlFragmentBuffer = mixedContentWriter.getBuffer();
        String fragment = xmlFragmentBuffer.toString();
        xmlFragmentBuffer.setLength(0);
        
        /* Xalan seems to output an XML declaration in some cases, even when asked not to! */
        if (fragment.startsWith("<?xml")) {
            fragment = fragment.substring(fragment.indexOf("?>") + 2);
        }
        return fragment;
    }

    /**
     * Helper method to set up the buffer for gathering text Content.
     */
    private void setupTextGathering() {
        if (textBuffer==null) {
            textBuffer = new StringBuilder();
        }
        else {
            textBuffer.setLength(0);
        }
    }

    /**
     * Helper method to set up the handler for reading embedded Objects.
     *
     * @param uri
     * @param localName
     * @throws SAXException
     */
    private void setupEmbeddedObjectHandler(String uri, String localName) throws SAXException {
        embeddedObject = createEmbeddedObjectPrototype(uri, localName);
        embeddedObjectReader = marshaller.getObjectReaderStrategy(embeddedObject);
        embeddedObjectReader.init();
        embeddedObjectReader.startDocument();
        /* Tell it about what prefixes are in scope */
        for (Entry<String,String> entry : prefixToUriMap.entrySet()) {
            embeddedObjectReader.startPrefixMapping(entry.getKey(), entry.getValue());
        }
    }

    /**
     * Internal method to change the internal parsing state, remembering the URI, local name
     * and Attributes of the element at this point.
     *
     * @param newState new state to change to
     * @param uri
     * @param localName
     * @param attributes
     */
    private void changeState(int newState, String uri, String localName, Attributes attributes) {
        lastElementNamespace = uri;
        lastElementAttributes = new AttributesImpl(attributes); // SAX API says Attributes will be undefined after startElement()
        lastElementLocalName = localName;
        state = newState;
    }

    /**
     * Internal method to change the internal parsing state, forgetting the URI, local name
     * and Attributes of the element at this point.
     *
     * @param newState new state to change to
     */
    private void changeState(int newState) {
        lastElementNamespace = null;
        lastElementAttributes = null;
        lastElementLocalName = null;
        state = newState;
    }

    public final void characters(char[] buffer, int start, int length) throws SAXException {
        switch (state) {
            case STATE_DEFAULT:
                /* (Ignorable whitespace may be reported here if we do not have a DTD so I'll
                 * just allow this).
                 */
                //throw new SAXException("Did not expect text inside container element");
                break;

            case STATE_GATHERING_TEXT:
                /* Gathering text, so add what we've found to the buffer */
                textBuffer.append(buffer, start, length);
                break;

            case STATE_READING_MIXED_CONTENT:
                /* This is part of the mixed content */
                mixedContentHandler.characters(buffer, start, length);
                break;

            case STATE_READING_EMBEDDED_OBJECT:
                /* Pass to embedded object */
                embeddedObjectReader.characters(buffer, start, length);
                break;

            default:
                throw new IllegalStateException("Unexpected state " + state);
        }
    }

    public final void startPrefixMapping(String prefix, String uri) throws SAXException {
        /* Maybe record prefix mappings so that embeddings can be informed of scope when required */
        if (prefixToUriMap!=null) {
            prefixToUriMap.put(prefix, uri);
        }
        /* Now update the current embeddings/mixed content reader, if appropriate */
        if (embeddedObjectReader!=null) {
            embeddedObjectReader.startPrefixMapping(prefix, uri);
        }
        else if (mixedContentHandler!=null) {
            mixedContentHandler.startPrefixMapping(prefix, uri);
        }
    }

    public final void endPrefixMapping(String prefix) throws SAXException {
        if (prefixToUriMap!=null) {
            prefixToUriMap.remove(prefix);
        }
        if (embeddedObjectReader!=null) {
            embeddedObjectReader.endPrefixMapping(prefix);
        }
        else if (mixedContentHandler!=null) {
            mixedContentHandler.endPrefixMapping(prefix);
        }
    }

    public final void ignorableWhitespace(char[] ch,int start,int length) {
    }

    public final void processingInstruction(String target, String data) {
    }

    public final void setDocumentLocator(Locator locator) {
    }

    public final void skippedEntity(String name) {
    }

    //-----------------------------------------------------
    // Subclasses should implement the methods below

    /**
     * Return an ElementMap providing information about all container elements
     * expected in the document, or null if there are no container elements.
     */
    public abstract ElementMap getContainerElements();

    /**
     * Return an ElementMap providing information about all text elements
     * expected in the document, or null if there are no text elements.
     */
    public abstract ElementMap getTextElements();

    /**
     * Return an ElementMap providing information about all elements corresponding
     * to embedded objects that need handled by a different ObjectReaderStrategy,
     * or null if there are no such elements.
     */
    public abstract ElementMap getEmbeddedObjectElements();

    /**
     * Return an ElementMap providing information about the containers of mixed
     * content, or null if there are no such elements.
     */
    public abstract ElementMap getMixedContentContainerElements();

    /**
     * This gets called at the start of parsing. Subclasses must initialise
     * the Object to its initial state or ensure that it will be completely
     * set up during parsing.
     */
    public abstract void setResult(E object);

    /**
     * Called when the start of a container Element is discovered.
     *
     * @param namespaceUri
     * @param localName
     * @param attrs
     * @throws SAXException
     */
    public abstract void startContainerElement(String namespaceUri, String localName, Attributes attrs)
        throws SAXException;

    /**
     * Called when the end of a container Element is discovered.
     * @param namespaceUri
     * @param localName
     * @throws SAXException
     */
    public abstract void endContainerElement(String namespaceUri, String localName)
        throws SAXException;

    /**
     * Called when a text element has been read.
     *
     * @param namespaceUri
     * @param localName
     * @param attrs Attributes that were recorded at the start of the element.
     * @param value String value of the text element
     * @throws SAXException
     */
    public abstract void textElement(String namespaceUri, String localName, Attributes attrs, String value)
        throws SAXException;

    /**
     * Called when an embedded Object is to be read. Subclasses should create the
     * appropriate prototype object for reading.
     *
     * @param namespaceUri
     * @param localName
     */
    public abstract Object createEmbeddedObjectPrototype(String namespaceUri, String localName);

    /**
     * Called when an embedded Object has been read. Subclasses can store the resulting
     * object as required.
     *
     * @param object
     * @param namespaceUri
     * @param localName
     * @throws SAXException
     */
    public abstract void embeddedObject(Object object, String namespaceUri, String localName)
        throws SAXException;

    /**
     * Called when an island of mixed Content has just been read in. This will
     * be a UTF-8 encoded XML fragment. Subclasses can store this as required.
     *
     * @param namespaceUri
     * @param localName
     * @param attrs Attributes that were recorded at the start of the element.
     * @param xmlFragment
     * @throws SAXException
     */
    public abstract void mixedContent(String namespaceUri, String localName, Attributes attrs, String xmlFragment)
        throws SAXException;

    /**
     * Subclasses can fill in to reset any internal parsing state that they
     * will have built up. This is called at the start and end of parsing, or
     * after an error.
     */
    public abstract void resetState();

    /**
     * This is called at the start of parsing. Subclasses can take this opportunity
     * to clear the Result Object to an appropriate state.
     */
    public abstract void clearResultObject();
}
